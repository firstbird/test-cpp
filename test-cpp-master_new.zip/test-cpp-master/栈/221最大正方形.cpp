class Solution {
    private: 
public:
    int maximalSquare(vector<vector<char>>& matrix) {
        int m = matrix.size();
        int n = matrix[0].size();
        vector<int> heights(n, 0);
        int mx = 0;
        for (int i = 0; i < m; ++i) {
            for (int j = 0; j < n; ++j) {
                char c = matrix[i][j];
                if (c == '1') {
                    heights[j] += 1;
                } else {
                    heights[j] = 0;
                }
            }
            mx = std::max(mx, maxArea(heights));
        }
        return mx;
    }

    int maxArea(const vector<int>& nums) {
        const int n = (int)nums.size();
        vector<int> st;
        st.reserve(n + 1);
        st.push_back(-1); // 哨兵，方便统一计算宽度

        int res = 0;
        for (int i = 0; i <= n; ++i) {
            const int cur = (i == n ? 0 : nums[i]); // 末尾哨兵高度 0，触发一次性清栈
            while (st.back() != -1 && cur <= nums[st.back()]) {
                const int h = nums[st.back()];
                st.pop_back();
                const int left = st.back();
                const int w = i - left - 1;          // 以 h 为最矮高度时的最大连续宽度
                const int side = std::min(h, w);     // 正方形边长由高度与宽度共同限制
                res = std::max(res, side * side);
            }
            st.push_back(i);
        }
        return res;
    }

    int maxRectArea(const vector<int>& nums) {
        const int n = (int)nums.size();
        vector<int> st;
        st.reserve(n + 1);
        st.push_back(-1);
        int res = 0;
        for (int i = 0; i <= n; ++i) {
            const int cur = (i == n ? 0 : nums[i]);
            while (st.back() != -1 && cur <= nums[st.back()]) {
                const int h = nums[st.back()];
                st.pop_back();
                const int left = st.back();
                const int w = i - left - 1;
                res = std::max(res, h * w);
            }
            st.push_back(i);
        }
        return res;
    }
};