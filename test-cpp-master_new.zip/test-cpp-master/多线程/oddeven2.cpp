#include <thread>
#include <iostream>
#include <mutex>

class Solution {
public:
    Solution() {
        mtx2.lock();

    };
    void odd_function() {
        int count = 100;
        int i = 1;
        while (i < 100) {
            mtx2.lock();
            std::cout << "奇数线程: " << i << std::endl;
            i += 2;
            mtx1.unlock();
        }
    };
    void even_function() {
        int count = 100;
        int i = 0;
        while (i < 100) {
            mtx1.lock();// 这里锁上后并不能靠自己解锁  
            std::cout << "偶数线程: " << i << std::endl;
            i += 2;
            mtx2.unlock();
        }
    };
private:
    std::mutex mtx1;
    std::mutex mtx2;
};

int main() {
    Solution s;
    std::thread t_odd(&Solution::odd_function, &s);
    std::thread t_even(&Solution::even_function, &s);
    t_even.join();
    t_odd.join();


}