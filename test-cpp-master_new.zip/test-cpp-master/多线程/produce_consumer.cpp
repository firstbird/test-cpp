#include <iostream>
#include <mutex>
#include <queue>
#include <thread>
#include <condition_variable>

template <typename T>
class BoundedQueue {
public:
    BoundedQueue(size_t capacity) : cap(capacity) {

    }

    void enqueue(T ele) {
        std::unique_lock<std::mutex> lck(mtx);
        cv.wait(lck, [this](){
            return que.size() < cap;
        });
        que.push_front(ele);
        lck.unlock();
        cv.notify_one();
    }

    T dequeue() {
        std::unique_lock<std::mutex> lck(mtx);
        cv.wait(lck, [this](){
            return que.size() != 0;
        });
        T res = que.back();
        que.pop_back();
        lck.unlock();
        cv.notify_one();
        return res;
    }

private:
    std::mutex mtx;
    std::condition_variable cv;
    std::deque<T> que;
    size_t cap;
};

template <typename T> 
class UnboundedQueue {
public:
    void enqueue(T elem) {
       std::unique_lock<std::mutex> lock(mtx);
       que.push(elem);
       lock.unlock();
       cv.notify_one();   
    }

    T dequeue() {
       std::unique_lock<std::mutex> lock(mtx);
       cv.wait(lock, [this](){
            return !que.empty();
       });
       T elem = que.front();
       que.pop();
       lock.unlock();
       cv.notify_one();
       return elem;
    }
private:
    std::mutex mtx;
    std::condition_variable cv;
    std::queue<T> que;    

};

void producerFunction(BoundedQueue<int>& queue, int round) {
    for (int i = 0; i < round; ++i) {
        queue.enqueue(i);
        std::this_thread::sleep_for(std::chrono::milliseconds(2));
    }    
}

void consumerFunction(BoundedQueue<int>& queue, int round) {
    for (int i = 0; i < round; ++i) {
        int res = queue.dequeue();
        std::this_thread::sleep_for(std::chrono::milliseconds(2));
        std::cout << "consumer out: " << res << std::endl;
    }    
}

void producerFunction2(UnboundedQueue<int>& queue, int round) {
    for (int i = 0; i < round; ++i) {
        queue.enqueue(i);
        std::this_thread::sleep_for(std::chrono::milliseconds(2));
    }    
}

void consumerFunction2(UnboundedQueue<int>& queue, int round) {
    for (int i = 0; i < round; ++i) {
        int res = queue.dequeue();
        std::this_thread::sleep_for(std::chrono::milliseconds(2));
        std::cout << "consumer out: " << res << std::endl;
    }    
}

int main() {
//    BoundedQueue<int> queue(20);
   UnboundedQueue<int> queue;
   std::thread t1(producerFunction2, std::ref(queue), 50);
   std::thread t2(consumerFunction2, std::ref(queue), 50);
   t1.join();
   t2.join();

}
