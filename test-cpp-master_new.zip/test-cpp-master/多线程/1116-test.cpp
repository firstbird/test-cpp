#include <mutex>
#include <functional>
#include <thread>
#include <iostream>
#include <atomic>
#include <condition_variable>

class ZeroEvenOdd {
private:
    int n;
    std::mutex mtx;
    std::condition_variable cv;
    int cur = 1;
    enum class Turn { Zero, Odd, Even };
    Turn turn = Turn::Zero;

public:
    ZeroEvenOdd(int n) {
        this->n = n;
    }

    // printNumber(x) outputs "x", where x is an integer.
    void zero(std::function<void(int)> printNumber) {
        for (int i = 1; i <= n; ++i) {
            std::unique_lock<std::mutex> lk(mtx);
            cv.wait(lk, [&] { return turn == Turn::Zero; });
            printNumber(0);
            turn = (cur % 2 == 1) ? Turn::Odd : Turn::Even;
            lk.unlock();
            cv.notify_all();
        }
    }

    void odd(std::function<void(int)> printNumber) {
        for (int x = 1; x <= n; x += 2) {
            std::unique_lock<std::mutex> lk(mtx);
            cv.wait(lk, [&] { return turn == Turn::Odd; });
            printNumber(cur);
            ++cur;
            turn = Turn::Zero;
            lk.unlock();
            cv.notify_all();
        }
    }

    void even(std::function<void(int)> printNumber) {
        for (int x = 2; x <= n; x += 2) {
            std::unique_lock<std::mutex> lk(mtx);
            cv.wait(lk, [&] { return turn == Turn::Even; });
            printNumber(cur);
            ++cur;
            turn = Turn::Zero;
            lk.unlock();
            cv.notify_all();
        }
    }
};

int main() {
    ZeroEvenOdd foo(1);

    std::thread t1(&ZeroEvenOdd::zero, &foo, [](int num){
        std::cout << std::to_string(num) << std::endl;
    });
    std::thread t2(&ZeroEvenOdd::even, &foo, [](int num){
        std::cout << std::to_string(num) << std::endl;
    });
    std::thread t3(&ZeroEvenOdd::odd, &foo, [](int num){
        std::cout << std::to_string(num) << std::endl;
    });

    t1.join();
    t2.join();
    t3.join();
}