#include <functional>
#include <thread>
#include <iostream>
#include <mutex>
#include <condition_variable>

// 三顺序打印
class Foo {
public:
    Foo() = default;
    void first(std::function<void()> printFirst) {
        printFirst();
        {
            std::lock_guard<std::mutex> lk(mtx);
            step = 1;
        }
        cv.notify_all();
    }
    void second(std::function<void()> printSecond) {
        std::unique_lock<std::mutex> lk(mtx);
        cv.wait(lk, [&] { return step == 1; });
        
        printSecond();
        step = 2;
        lk.unlock();
        cv.notify_all();
    }
    void third(std::function<void()> printThird) {
        std::unique_lock<std::mutex> lk(mtx);
        cv.wait(lk, [&] { return step == 2; });
        printThird();
    }
private:
    std::mutex mtx;
    std::condition_variable cv;
    int step = 0; // 0: none, 1: first done, 2: second done
};

int main() {
    Foo foo;
    std::thread t1(&Foo::first, &foo, [](){
        std::cout << "first" << std::endl;
    });

    std::thread t2(&Foo::second, &foo, [](){
        std::cout << "second" << std::endl;
    });

    std::thread t3(&Foo::third, &foo, [](){
        std::cout << "third" << std::endl;
    });

    t1.join();
    t2.join();
    t3.join();
}