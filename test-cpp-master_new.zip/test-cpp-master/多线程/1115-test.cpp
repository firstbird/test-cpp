#include <thread>
#include <iostream>
#include <functional>
#include <mutex>
#include <condition_variable>

class FooBar {
public:
    FooBar(int n) {
        this->n = n;
    }
    ~FooBar() {

    }
    void foo(std::function<void()> printFoo) {
        for (int i = 0; i < n; ++i) {
            std::unique_lock<std::mutex> lk(mtx);
            cv.wait(lk, [&] { return foo_turn; });
            printFoo();
            foo_turn = false;
            lk.unlock();
            cv.notify_one();
        }
    }
    void bar(std::function<void()> printBar) {
        for (int i = 0; i < n; ++i) {
            std::unique_lock<std::mutex> lk(mtx);
            cv.wait(lk, [&] { return !foo_turn; });
            printBar();
            foo_turn = true;
            lk.unlock();
            cv.notify_one();
        }
    }
private:
    int n;
    std::mutex mtx;
    std::condition_variable cv;
    bool foo_turn = true;
};

int main() {
    FooBar foobar(20);

    std::thread t1(&FooBar::foo, &foobar, [](){
        std::cout << "foo" << std::endl;
    });
    std::thread t2(&FooBar::bar, &foobar, [](){
        std::cout << "bar" << std::endl;
    });

    t1.join();
    t2.join();
}