#include <thread>
#include <iostream>
#include <mutex>
#include <condition_variable>

int main() {
    std::mutex mtx;
    std::condition_variable cv;
    bool even_turn = true; // 先打印偶数 0

    std::thread t1([&] {
        for (int i = 0; i < 100; i += 2) {
            std::unique_lock<std::mutex> lk(mtx);
            cv.wait(lk, [&] { return even_turn; });
            std::cout << "偶数线程: " << i << std::endl;
            even_turn = false;
            lk.unlock();
            cv.notify_one();
        }
    });

    std::thread t2([&] {
        for (int i = 1; i < 100; i += 2) {
            std::unique_lock<std::mutex> lk(mtx);
            cv.wait(lk, [&] { return !even_turn; });
            std::cout << "奇数线程: " << i << std::endl;
            even_turn = true;
            lk.unlock();
            cv.notify_one();
        }
    });

    t1.join();
    t2.join();
}