# vector 初始化异常分析

## 问题代码

```cpp
// 注释中的写法
vector<vector<int>> res;
for (int i = 0; i <= n; i++) {
    res.push_back(vector<int>());
}
```

## 异常原因分析

### 问题1：循环条件错误 `i <= n`

**错误：** `i <= n` 会创建 **n+1** 个 vector

**正确：** `i < n` 应该创建 **n** 个 vector

**示例：** `n = 3`

```cpp
// 错误写法：i <= n
for (int i = 0; i <= 3; i++) {
    res.push_back(vector<int>());
}
// 创建了 4 个 vector：res[0], res[1], res[2], res[3]
// 但应该是 3 个：res[0], res[1], res[2]

// 后续访问 res[3] 会越界（如果只分配了 n 个）
```

### 问题2：vector 未初始化大小

**错误写法：**
```cpp
res.push_back(vector<int>());  // 创建空的 vector<int>
```

**问题：** 创建的 `vector<int>` 是**空的**，没有预分配大小

**影响：**
```cpp
// 后续访问
res[0][0] = 1;  // ❌ 异常！res[0] 是空的，无法访问 res[0][0]
```

### 问题3：与当前代码的对比

**当前代码（正确）：**
```cpp
vector<vector<int>> res(n, vector<int>(n));
// 创建 n 个 vector<int>，每个 vector<int> 大小为 n，初始化为 0
```

**注释代码（错误）：**
```cpp
vector<vector<int>> res;
for (int i = 0; i <= n; i++) {  // ❌ 应该是 i < n
    res.push_back(vector<int>());  // ❌ 创建空的 vector
}
// 结果：res.size() = n+1，但每个 res[i] 都是空的
```

## 详细对比

### 当前代码（正确）

```cpp
vector<vector<int>> res(n, vector<int>(n));
```

**执行结果：**
```cpp
// n = 3
res.size() = 3
res[0].size() = 3  // [0, 0, 0]
res[1].size() = 3  // [0, 0, 0]
res[2].size() = 3  // [0, 0, 0]

// 可以安全访问
res[0][0] = 1;  // ✅ 正常
res[2][2] = 9;  // ✅ 正常
```

### 注释代码（错误）

```cpp
vector<vector<int>> res;
for (int i = 0; i <= n; i++) {
    res.push_back(vector<int>());
}
```

**执行结果：**
```cpp
// n = 3
res.size() = 4  // ❌ 错误！应该是 3
res[0].size() = 0  // ❌ 空的！
res[1].size() = 0  // ❌ 空的！
res[2].size() = 0  // ❌ 空的！
res[3].size() = 0  // ❌ 多余的！

// 访问会异常
res[0][0] = 1;  // ❌ 异常！res[0] 是空的，无法访问索引 0
```

## 异常场景

### 场景1：访问空 vector

```cpp
vector<vector<int>> res;
for (int i = 0; i <= 3; i++) {
    res.push_back(vector<int>());
}
// res.size() = 4
// res[0].size() = 0（空的）

// 尝试访问
res[0][0] = 1;  // ❌ 异常！
// vector::_M_range_check: __n (which is 0) >= this->size() (which is 0)
```

### 场景2：循环条件错误导致越界

```cpp
vector<vector<int>> res;
for (int i = 0; i <= n; i++) {  // 创建 n+1 个
    res.push_back(vector<int>());
}

// 如果后续代码假设 res.size() == n
for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
        res[i][j] = ...;  // 可能访问 res[n]，但逻辑上不应该
    }
}
```

## 正确的修复方式

### 方式1：修复循环条件和初始化大小

```cpp
vector<vector<int>> res;
for (int i = 0; i < n; i++) {  // ✅ 修复：i < n
    res.push_back(vector<int>(n));  // ✅ 修复：初始化大小为 n
}
```

### 方式2：使用构造函数（推荐，当前代码）

```cpp
vector<vector<int>> res(n, vector<int>(n));
// 一行代码，简洁高效
```

### 方式3：使用 resize

```cpp
vector<vector<int>> res;
res.resize(n);
for (int i = 0; i < n; i++) {
    res[i].resize(n);
}
```

## 代码对比表

| 写法 | res.size() | res[i].size() | 能否访问 res[i][j] | 正确性 |
|------|-----------|---------------|-------------------|--------|
| **当前代码**<br>`vector<vector<int>> res(n, vector<int>(n));` | n | n | ✅ | ✅ 正确 |
| **注释代码**<br>`for (i <= n) push_back(vector<int>())` | n+1 | 0 | ❌ | ❌ 错误 |
| **修复1**<br>`for (i < n) push_back(vector<int>(n))` | n | n | ✅ | ✅ 正确 |
| **修复2**<br>`resize + resize` | n | n | ✅ | ✅ 正确 |

## 实际测试

### 测试代码

```cpp
#include <vector>
#include <iostream>
using namespace std;

int main() {
    int n = 3;
    
    // 当前代码（正确）
    vector<vector<int>> res1(n, vector<int>(n));
    cout << "res1.size() = " << res1.size() << endl;
    cout << "res1[0].size() = " << res1[0].size() << endl;
    res1[0][0] = 1;  // ✅ 正常
    cout << "res1[0][0] = " << res1[0][0] << endl;
    
    // 注释代码（错误）
    vector<vector<int>> res2;
    for (int i = 0; i <= n; i++) {  // ❌ i <= n
        res2.push_back(vector<int>());  // ❌ 空的 vector
    }
    cout << "\nres2.size() = " << res2.size() << endl;
    cout << "res2[0].size() = " << res2[0].size() << endl;
    // res2[0][0] = 1;  // ❌ 异常！
    
    return 0;
}
```

**输出：**
```
res1.size() = 3
res1[0].size() = 3
res1[0][0] = 1

res2.size() = 4        // ❌ 错误！应该是 3
res2[0].size() = 0     // ❌ 错误！应该是 3
// 如果执行 res2[0][0] = 1，会抛出异常
```

## 总结

### 注释代码的问题

1. ❌ **循环条件错误**：`i <= n` 应该改为 `i < n`
   - 导致创建 n+1 个 vector 而不是 n 个

2. ❌ **vector 未初始化大小**：`vector<int>()` 创建的是空 vector
   - 导致无法访问 `res[i][j]`
   - 会抛出 `vector::_M_range_check` 异常

### 正确的写法

```cpp
// 方式1：使用构造函数（推荐）
vector<vector<int>> res(n, vector<int>(n));

// 方式2：修复循环和初始化
vector<vector<int>> res;
for (int i = 0; i < n; i++) {  // ✅ i < n
    res.push_back(vector<int>(n));  // ✅ 初始化大小为 n
}
```

### 关键点

- ✅ **循环条件**：`i < n` 而不是 `i <= n`
- ✅ **初始化大小**：`vector<int>(n)` 而不是 `vector<int>()`
- ✅ **推荐使用构造函数**：`vector<vector<int>> res(n, vector<int>(n))`

这就是为什么注释中的写法会有异常的原因！🎯

