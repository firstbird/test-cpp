#include <vector>
#include <set>
#include <algorithm>
using namespace std;

class Solution {
public:

//128. 最长连续序列
    int longestConsecutive(vector<int>& nums) {
	    set<int> s;
	    for (auto num : nums) {
		    s.insert(num);
	    }
	    int res = 0;
	    for (auto key : s) {
			//只对左端点处理，右边和中间的点，在下面的循环中会处理
		    if (s.count(key - 1) == 0){
			    int cur = key;
				// while(s.count(cur) !=0))
			    while (s.count(cur) != 0)
			    {
				    cur++;
			    }
			    res = max(res, cur - key);
		    }
	    }
	    return res;
    }
};