#include <string>
#include <vector>
using namespace std;
//567. 字符串的排列
class Solution {
    public:
        bool checkInclusion(string s1, string s2) {
            int n = s1.length(), m = s2.length();
            if (n > m) {
                return false;
            }
            vector<int> cnt1(26), cnt2(26);
            for (int i = 0; i < n; ++i) {
                ++cnt1[s1[i] - 'a'];
                ++cnt2[s2[i] - 'a'];
            }
            if (cnt1 == cnt2) {
                return true;
            }
            // 从n开始遍历s2，因为s1的长度为n，所以s2的起点为n
            for (int i = n; i < m; ++i) {
                ++cnt2[s2[i] - 'a'];
                --cnt2[s2[i - n] - 'a'];
                if (cnt1 == cnt2) {
                    return true;
                }
            }
            return false;
        }
    };