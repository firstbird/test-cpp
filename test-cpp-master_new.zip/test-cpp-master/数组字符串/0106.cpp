#include <string>
#include <vector>
using namespace std;

class Solution {
public:
    string compressString(string S) {
	    string res = "";
	    int count = 0;
	    int n = S.length();
	    char pre = 0;
	    for (int i = 0; i < n; i++) {
		    if (pre != S[i]) {
				if (pre != 0) {
				res += pre;
				res += to_string(count);
				}
				count = 1;
				pre = S[i];
		    } else {
			    count++;
		    }
	    }
            res += pre;
	    res += to_string(count);
	    return res.size() < n ? res : S;
    }
	int compress(vector<char>& chars) {
	    int n = chars.size();
	    if (n <= 1) return n;
	    
	    int write = 0;  // 写入位置
	    int read = 0;   // 读取位置
	    
	    while (read < n) {
	        // char currentChar = chars[read];
	        // int count = 0;
	        
	        // // 统计连续相同字符的数量
	        // while (read < n && chars[read] == currentChar) {
	        //     count++;
	        //     read++;
	        // }
			int count = 1;
            while (read+1 < n && chars[read] == chars[read+1]) {
                read++;
                count++;
            }
	        // 写入字符
	        // chars[write++] = currentChar;
			chars[write++] = chars[read];
	        
	        // 如果计数大于1，写入数字
	        if (count > 1) {
	            string countStr = to_string(count);
	            for (char c : countStr) {
	                chars[write++] = c;
	            }
	        }
	    }
	    
	    return write;  // 返回压缩后的长度
	}
};