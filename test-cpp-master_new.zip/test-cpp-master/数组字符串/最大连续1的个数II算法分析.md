# 最大连续1的个数II算法分析

## 问题描述

**LeetCode 487: 最大连续1的个数II**

给定一个二进制数组 `nums`，如果最多可以翻转一个 `0`，则返回数组中连续 `1` 的最大个数。

## 完整代码

```cpp
int findMaxConsecutiveOnes(vector<int>& nums) {
    int n = nums.size();
    int left = 0;
    int max = 0;
    nums.resize(8);
    // 要注意状态尽量少
    int zeroIndex = -1;
    for (int right = 0; right < n; right++) {
        if (nums[right] == 1) {    
            continue;    
        }
        // meet 0 more than once
        if (zeroIndex != -1) {
            max = std::max(max, right - left);
            //cout << "max: " << max << " right: " << right << " left: " << left << " zeroIndex: " << zeroIndex << endl;
            left = zeroIndex + 1;
            // 要注意每个分支每个变量的变化
            zeroIndex = right;
        } else {
            zeroIndex = right;
        }
    }	
    max = std::max(max, n - left);
    //cout << "end max: " << max << " n: " << n << " left: " << left << endl;
    return max;
}
```

## 算法思路

### 核心思想：滑动窗口 + 状态跟踪

**关键点：**
- 使用滑动窗口维护一个最多包含一个0的连续1的区间
- 记录遇到的第一个0的位置（`zeroIndex`）
- 当遇到第二个0时，更新窗口左边界

### 算法步骤

1. **初始化**：`left = 0`, `zeroIndex = -1`（表示还没遇到0）
2. **遍历数组**：使用 `right` 作为右边界
3. **遇到1**：继续扩展窗口
4. **遇到0**：
   - 如果这是第一个0：记录位置，继续
   - 如果这是第二个0：更新窗口，将 `left` 移动到第一个0之后

## 详细执行流程

### 示例1：`nums = [1,0,1,1,0,1,1,1]`

```
初始：left=0, zeroIndex=-1, max=0

right=0: nums[0]=1
  continue，窗口=[1]

right=1: nums[1]=0
  zeroIndex=-1，这是第一个0
  zeroIndex=1，窗口=[1,0]

right=2: nums[2]=1
  continue，窗口=[1,0,1]

right=3: nums[3]=1
  continue，窗口=[1,0,1,1]

right=4: nums[4]=0
  zeroIndex=1 != -1，这是第二个0
  max = max(0, 4-0) = 4
  left = 1+1 = 2，窗口左边界移动到位置2
  zeroIndex = 4，窗口=[1,1,0]

right=5: nums[5]=1
  continue，窗口=[1,1,0,1]

right=6: nums[6]=1
  continue，窗口=[1,1,0,1,1]

right=7: nums[7]=1
  continue，窗口=[1,1,0,1,1,1]

循环结束：
  max = max(4, 8-2) = max(4, 6) = 6

结果：6（翻转位置4的0，得到 [1,0,1,1,1,1,1,1]）
```

### 示例2：`nums = [1,1,0,1,0,1]`

```
初始：left=0, zeroIndex=-1, max=0

right=0: nums[0]=1, 窗口=[1]
right=1: nums[1]=1, 窗口=[1,1]
right=2: nums[2]=0, zeroIndex=2, 窗口=[1,1,0]
right=3: nums[3]=1, 窗口=[1,1,0,1]
right=4: nums[4]=0
  zeroIndex=2 != -1，第二个0
  max = max(0, 4-0) = 4
  left = 2+1 = 3, zeroIndex=4, 窗口=[1,0]
right=5: nums[5]=1, 窗口=[1,0,1]

循环结束：
  max = max(4, 6-3) = max(4, 3) = 4

结果：4（翻转位置2的0，得到 [1,1,1,1,0,1]）
```

## 关键变量说明

### zeroIndex

**作用：** 记录当前窗口中遇到的第一个0的位置

**状态变化：**
- `-1`：还没遇到0
- `>= 0`：遇到第一个0的位置

**更新时机：**
- 遇到第一个0：`zeroIndex = right`
- 遇到第二个0：`left = zeroIndex + 1`, `zeroIndex = right`

### left

**作用：** 滑动窗口的左边界

**更新时机：**
- 遇到第二个0时，移动到第一个0之后

### max

**作用：** 记录最大连续1的长度

**更新时机：**
- 遇到第二个0时：`max = max(max, right - left)`
- 循环结束后：`max = max(max, n - left)`

## 算法正确性分析

### 为什么遇到第二个0时要更新窗口？

```
当前窗口：[1,1,0,1,1,0]
          |     |     |
         left  zero  right

如果继续扩展窗口，会包含两个0，不符合"最多翻转一个0"的条件。

解决方案：
1. 记录当前窗口长度：right - left = 5
2. 移动 left 到第一个0之后：left = zeroIndex + 1
3. 更新 zeroIndex 为第二个0的位置
4. 新窗口：[1,1,0]
            |     |
          left  zero
```

### 为什么最后还要更新 max？

```cpp
max = std::max(max, n - left);
```

**原因：** 循环结束时，可能还有最后一个窗口没有计算

**示例：**
```
nums = [1,1,0,1,1,1]
处理完所有元素后：
  left = 2（第一个0之后）
  最后一个窗口：[1,1,1]，长度 = 6-2 = 4
  需要更新 max
```

## 代码问题分析

### 问题1：无用的代码

```cpp
nums.resize(8);  // ❌ 这行代码会修改输入数组，不应该存在
```

**问题：** 这行代码会改变输入数组的大小，可能导致：
- 数组被截断（如果 n < 8）
- 数组被扩展（如果 n > 8），新增元素值为0

**修复：** 删除这行代码

### 问题2：变量命名

```cpp
int max = 0;  // ❌ max 是标准库函数名，可能冲突
```

**修复：** 使用 `maxLen` 或 `result`

## 优化后的代码

```cpp
int findMaxConsecutiveOnes(vector<int>& nums) {
    int n = nums.size();
    int left = 0;
    int maxLen = 0;
    int zeroIndex = -1;  // 记录当前窗口中第一个0的位置
    
    for (int right = 0; right < n; right++) {
        if (nums[right] == 1) {
            continue;  // 遇到1，继续扩展窗口
        }
        
        // 遇到0
        if (zeroIndex != -1) {
            // 这是第二个0，更新窗口
            maxLen = std::max(maxLen, right - left);
            left = zeroIndex + 1;  // 左边界移动到第一个0之后
            zeroIndex = right;      // 更新为新的第一个0
        } else {
            // 这是第一个0，记录位置
            zeroIndex = right;
        }
    }
    
    // 处理最后一个窗口
    maxLen = std::max(maxLen, n - left);
    
    return maxLen;
}
```

## 算法复杂度

### 时间复杂度

- **O(n)**：只遍历数组一次
- 每个元素最多访问一次

### 空间复杂度

- **O(1)**：只使用几个变量
- 不需要额外的数据结构

## 算法特点

### 优点

1. ✅ **高效**：O(n) 时间复杂度，O(1) 空间复杂度
2. ✅ **一次遍历**：不需要多次扫描
3. ✅ **状态简单**：只需要记录一个0的位置

### 关键技巧

1. **滑动窗口**：维护最多包含一个0的区间
2. **状态跟踪**：用 `zeroIndex` 记录第一个0的位置
3. **边界处理**：循环结束后更新最后一个窗口

## 与其他方法的对比

### 方法1：暴力法

```cpp
// 对每个位置，尝试翻转，计算最大长度
// 时间复杂度：O(n²)
```

### 方法2：动态规划

```cpp
// dp[i][0] = 以i结尾，没有翻转0的最大长度
// dp[i][1] = 以i结尾，翻转了一个0的最大长度
// 时间复杂度：O(n)，空间复杂度：O(n)
```

### 方法3：滑动窗口（当前方法）

```cpp
// 时间复杂度：O(n)，空间复杂度：O(1)
// 最优解
```

## 总结

### 算法核心

1. **滑动窗口**：维护最多包含一个0的连续区间
2. **状态跟踪**：用 `zeroIndex` 记录第一个0的位置
3. **窗口更新**：遇到第二个0时，移动左边界

### 关键点

- ✅ **zeroIndex = -1**：表示还没遇到0
- ✅ **遇到第一个0**：记录位置，继续扩展
- ✅ **遇到第二个0**：更新窗口，移动左边界
- ✅ **循环结束**：更新最后一个窗口

### 记忆要点

**"最多一个0的滑动窗口，遇到第二个0就移动左边界"**

这就是最大连续1的个数II的算法！🎯

