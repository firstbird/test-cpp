# 为什么需要 max(left, map[s[i]] + 1)？

## 问题代码

```cpp
if (map.find(s[i]) != map.end()) {
    left = max(left, map[s[i]] + 1);  // 为什么要取 max？
}
```

## 核心原因：防止 left 回退

### 关键点

使用 `max(left, map[s[i]] + 1)` 的目的是**确保 `left` 只能向右移动，不能回退**。

如果只写 `left = map[s[i]] + 1`，当遇到**之前窗口外的重复字符**时，`left` 可能会回退，导致窗口包含重复字符。

## 详细分析

### 场景1：不使用 max（错误）

```cpp
// ❌ 错误写法
if (map.find(s[i]) != map.end()) {
    left = map[s[i]] + 1;  // 没有 max，可能回退
}
```

**问题示例：** `s = "abba"`

```
初始：left = 0, map = {}

i=0, s[0]='a':
  map中没有'a'
  map['a'] = 0
  left = 0, 窗口=[a], res=1

i=1, s[1]='b':
  map中没有'b'
  map['b'] = 1
  left = 0, 窗口=[ab], res=2

i=2, s[2]='b':
  map中有'b'，位置1
  left = map['b'] + 1 = 1 + 1 = 2  ✅ 正确
  map['b'] = 2
  left = 2, 窗口=[b], res=2

i=3, s[3]='a':
  map中有'a'，位置0
  left = map['a'] + 1 = 0 + 1 = 1  ❌ 错误！left 从 2 回退到 1
  map['a'] = 3
  left = 1, 窗口=[ba]  ❌ 错误！包含了重复的 'b'（位置2）
  res = max(2, 3-1+1) = 3  ❌ 错误！窗口[ba]实际上包含重复字符
```

**问题：** `left` 从 2 回退到 1，导致窗口 `[ba]` 包含了位置2的 `'b'`，而位置1也有 `'b'`，但位置1的 `'b'` 已经在窗口外了。实际上窗口应该只包含 `[a]`。

### 场景2：使用 max（正确）

```cpp
// ✅ 正确写法
if (map.find(s[i]) != map.end()) {
    left = max(left, map[s[i]] + 1);  // 使用 max，防止回退
}
```

**同样示例：** `s = "abba"`

```
初始：left = 0, map = {}

i=0, s[0]='a':
  map中没有'a'
  map['a'] = 0
  left = 0, 窗口=[a], res=1

i=1, s[1]='b':
  map中没有'b'
  map['b'] = 1
  left = 0, 窗口=[ab], res=2

i=2, s[2]='b':
  map中有'b'，位置1
  left = max(0, 1+1) = max(0, 2) = 2  ✅ 正确
  map['b'] = 2
  left = 2, 窗口=[b], res=2

i=3, s[3]='a':
  map中有'a'，位置0
  left = max(2, 0+1) = max(2, 1) = 2  ✅ 正确！left 不会回退
  map['a'] = 3
  left = 2, 窗口=[a]  ✅ 正确！不包含重复字符
  res = max(2, 3-2+1) = 2  ✅ 正确
```

**结果：** `left` 保持为 2，不会回退，窗口 `[a]` 正确，不包含重复字符。

## 更多示例

### 示例1：`s = "abcba"`

**不使用 max：**
```
i=0: 'a' -> map['a']=0, left=0, 窗口=[a]
i=1: 'b' -> map['b']=1, left=0, 窗口=[ab]
i=2: 'c' -> map['c']=2, left=0, 窗口=[abc]
i=3: 'b' -> map中有'b'，位置1
     left = 1+1 = 2, 窗口=[cb]
i=4: 'a' -> map中有'a'，位置0
     left = 0+1 = 1  ❌ 回退！窗口=[cba] 包含重复的'b'
```

**使用 max：**
```
i=0: 'a' -> map['a']=0, left=0, 窗口=[a]
i=1: 'b' -> map['b']=1, left=0, 窗口=[ab]
i=2: 'c' -> map['c']=2, left=0, 窗口=[abc]
i=3: 'b' -> map中有'b'，位置1
     left = max(0, 1+1) = 2, 窗口=[cb]
i=4: 'a' -> map中有'a'，位置0
     left = max(2, 0+1) = 2  ✅ 不回退！窗口=[ba]
```

### 示例2：`s = "tmmzuxt"`

**不使用 max：**
```
i=0: 't' -> map['t']=0, left=0, 窗口=[t]
i=1: 'm' -> map['m']=1, left=0, 窗口=[tm]
i=2: 'm' -> map中有'm'，位置1
     left = 1+1 = 2, 窗口=[m]
i=3: 'z' -> map['z']=3, left=2, 窗口=[mz]
i=4: 'u' -> map['u']=4, left=2, 窗口=[mzu]
i=5: 'x' -> map['x']=5, left=2, 窗口=[mzux]
i=6: 't' -> map中有't'，位置0
     left = 0+1 = 1  ❌ 回退！窗口=[mmzuxt] 包含重复的'm'
```

**使用 max：**
```
i=0: 't' -> map['t']=0, left=0, 窗口=[t]
i=1: 'm' -> map['m']=1, left=0, 窗口=[tm]
i=2: 'm' -> map中有'm'，位置1
     left = max(0, 1+1) = 2, 窗口=[m]
i=3: 'z' -> map['z']=3, left=2, 窗口=[mz]
i=4: 'u' -> map['u']=4, left=2, 窗口=[mzu]
i=5: 'x' -> map['x']=5, left=2, 窗口=[mzux]
i=6: 't' -> map中有't'，位置0
     left = max(2, 0+1) = 2  ✅ 不回退！窗口=[mzuxt]
```

## 为什么会出现回退？

### 原因分析

当遇到重复字符时：
- `map[s[i]]` 存储的是该字符**上一次出现的位置**
- 如果上一次出现的位置在**当前窗口之外**（即 `map[s[i]] < left`），那么：
  - 这个字符在当前窗口中已经不存在了
  - 不应该因为它在窗口外出现过就回退 `left`
  - 应该保持 `left` 不变

### 数学关系

```
如果 map[s[i]] < left：
  - 说明字符 s[i] 上一次出现在当前窗口之外
  - 当前窗口 [left, i] 中不包含这个字符
  - 不应该回退 left
  - 应该保持 left 不变

如果 map[s[i]] >= left：
  - 说明字符 s[i] 上一次出现在当前窗口之内
  - 当前窗口 [left, i] 中包含这个字符
  - 需要移动 left 到 map[s[i]] + 1
```

### 使用 max 的逻辑

```cpp
left = max(left, map[s[i]] + 1);
```

- 如果 `map[s[i]] + 1 < left`：`max` 返回 `left`，保持不变 ✅
- 如果 `map[s[i]] + 1 >= left`：`max` 返回 `map[s[i]] + 1`，向右移动 ✅

## 可视化对比

### 不使用 max（错误）

```
s = "abba"
    0123

i=0: [a]        left=0
i=1: [ab]       left=0
i=2: [b]        left=2  (遇到重复的'b')
i=3: [ba]       left=1  ❌ 回退！窗口包含重复字符
```

### 使用 max（正确）

```
s = "abba"
    0123

i=0: [a]        left=0
i=1: [ab]       left=0
i=2: [b]        left=2  (遇到重复的'b')
i=3: [a]        left=2  ✅ 不回退！窗口正确
```

## 总结

### 为什么需要 max？

1. **防止 left 回退**：确保滑动窗口的左边界只能向右移动
2. **处理窗口外的重复字符**：如果重复字符上一次出现在窗口外，不应该回退 left
3. **保证窗口正确性**：确保窗口内不包含重复字符

### 关键要点

- ✅ **使用 `max(left, map[s[i]] + 1)`**：防止回退
- ❌ **不使用 `left = map[s[i]] + 1`**：可能回退，导致错误

### 记忆要点

**`left` 只能向右移动，不能回退！**

这就是为什么需要 `max` 的根本原因！🎯

