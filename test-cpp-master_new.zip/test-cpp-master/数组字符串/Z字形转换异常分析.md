# Z字形转换异常分析

## 问题代码

```cpp
string convert(string s, int numRows) {
    vector<vector<char>> rows;
    for (int i = 0; i < numRows; ++i) {
        rows.push_back(vector<char>());
    }	
    int curRow = 0;
    int dir = -1;
    for (char c : s) {
        rows[curRow].push_back(c);  // 第16行：可能越界
        if (curRow == 0 || curRow == numRows - 1) {  // 第17行
            dir = -dir;
        }
        curRow += dir;
    }
    // ...
}
```

## 异常原因分析

### 问题1：numRows == 0（最可能的原因）

**场景：** 当 `numRows = 0` 时

```cpp
vector<vector<char>> rows;
for (int i = 0; i < 0; ++i) {  // 循环不执行
    rows.push_back(vector<char>());
}
// rows 是空的，size() = 0

int curRow = 0;
for (char c : s) {
    rows[curRow].push_back(c);  // ❌ 异常！访问 rows[0]，但 rows 是空的
    // 抛出 std::out_of_range 或段错误
}
```

**错误信息：**
- `vector::_M_range_check: __n (which is 0) >= this->size() (which is 0)`
- 或段错误（Segmentation fault）

### 问题2：numRows < 0

**场景：** 当 `numRows < 0` 时

```cpp
for (int i = 0; i < -1; ++i) {  // 循环不执行（i < -1 永远为false）
    rows.push_back(vector<char>());
}
// rows 是空的

rows[curRow].push_back(c);  // ❌ 异常！访问越界
```

### 问题3：numRows == 1 时的逻辑问题

**场景：** 当 `numRows = 1` 时

```cpp
for (int i = 0; i < 1; ++i) {
    rows.push_back(vector<char>());
}
// rows.size() = 1，rows[0] 存在

int curRow = 0;
int dir = -1;
for (char c : s) {
    rows[0].push_back(c);  // ✅ 可以访问
    if (curRow == 0 || curRow == 1 - 1) {  // 0 == 0 || 0 == 0，都是true
        dir = -dir;  // dir 从 -1 变成 1，然后又变成 -1...
    }
    curRow += dir;  // curRow = 0 + 1 = 1，然后 1 + (-1) = 0，循环
    // 但 curRow 可能变成 1，访问 rows[1] 会越界！
}
```

**问题：** 当 `numRows = 1` 时：
- `curRow` 初始为 0
- `dir` 初始为 -1
- 第一次：`curRow == 0`，`dir` 变成 1
- `curRow += dir` → `curRow = 0 + 1 = 1`
- 第二次循环：访问 `rows[1]` ❌ 越界！

## 修复方案

### 方案1：添加边界检查（推荐）

```cpp
string convert(string s, int numRows) {
    // 边界情况处理
    if (numRows <= 0) {
        return "";  // 或返回 s
    }
    if (numRows == 1) {
        return s;  // 只有一行，直接返回
    }
    
    vector<vector<char>> rows;
    for (int i = 0; i < numRows; ++i) {
        rows.push_back(vector<char>());
    }
    
    int curRow = 0;
    int dir = -1;  // 初始方向向下，但第一次会翻转成向上
    
    for (char c : s) {
        rows[curRow].push_back(c);
        if (curRow == 0 || curRow == numRows - 1) {
            dir = -dir;
        }
        curRow += dir;
    }
    
    string res;
    for (auto row : rows) {
        for (auto value : row) {
            res.push_back(value);
        }
    }
    return res;
}
```

### 方案2：修正初始方向

```cpp
string convert(string s, int numRows) {
    if (numRows <= 0) return "";
    if (numRows == 1) return s;
    
    vector<vector<char>> rows(numRows);
    int curRow = 0;
    int dir = 1;  // ✅ 初始方向向下（正数）
    
    for (char c : s) {
        rows[curRow].push_back(c);
        if (curRow == 0 || curRow == numRows - 1) {
            dir = -dir;
        }
        curRow += dir;
    }
    
    string res;
    for (const auto& row : rows) {
        for (char c : row) {
            res += c;
        }
    }
    return res;
}
```

### 方案3：使用更安全的访问方式

```cpp
string convert(string s, int numRows) {
    if (numRows <= 0) return "";
    if (numRows == 1) return s;
    
    vector<vector<char>> rows(numRows);
    int curRow = 0;
    int dir = 1;
    
    for (char c : s) {
        // 添加边界检查
        if (curRow >= 0 && curRow < numRows) {
            rows[curRow].push_back(c);
        }
        
        if (curRow == 0 || curRow == numRows - 1) {
            dir = -dir;
        }
        curRow += dir;
    }
    
    string res;
    for (const auto& row : rows) {
        res.append(row.begin(), row.end());
    }
    return res;
}
```

## 测试用例

### 会触发异常的测试用例

```cpp
// 测试用例1：numRows = 0
convert("PAYPALISHIRING", 0);  // ❌ 异常：访问 rows[0]，但 rows 是空的

// 测试用例2：numRows < 0
convert("PAYPALISHIRING", -1);  // ❌ 异常：访问越界

// 测试用例3：numRows = 1（如果初始方向是-1）
convert("ABC", 1);  // ❌ 可能异常：curRow 可能变成 1
```

### 正常工作的测试用例

```cpp
// 测试用例4：正常情况
convert("PAYPALISHIRING", 3);
// 预期输出："PAHNAPLSIIGYIR"

// 测试用例5：numRows = 2
convert("ABCD", 2);
// 预期输出："ACBD"
```

## 执行流程分析（numRows = 1, dir = -1）

```
初始：curRow = 0, dir = -1, rows.size() = 1

第1个字符 'A':
  rows[0].push_back('A');  // ✅ 正常
  curRow == 0，dir = -(-1) = 1
  curRow = 0 + 1 = 1  ❌ 问题！
  
第2个字符 'B':
  rows[1].push_back('B');  // ❌ 异常！rows[1] 不存在
```

## 修复后的正确流程（numRows = 1, dir = 1）

```
初始：curRow = 0, dir = 1, rows.size() = 1

第1个字符 'A':
  rows[0].push_back('A');  // ✅ 正常
  curRow == 0，dir = -1
  curRow = 0 + (-1) = -1  ❌ 还是有问题！
```

**更好的修复：** 当 `numRows == 1` 时直接返回

```cpp
if (numRows == 1) {
    return s;  // 只有一行，不需要Z字形排列
}
```

## 完整修复代码

```cpp
string convert(string s, int numRows) {
    // 边界情况处理
    if (numRows <= 0) {
        return "";
    }
    if (numRows == 1) {
        return s;  // 只有一行，直接返回原字符串
    }
    
    vector<vector<char>> rows(numRows);
    int curRow = 0;
    int dir = 1;  // 初始方向向下
    
    for (char c : s) {
        rows[curRow].push_back(c);
        
        // 到达边界时改变方向
        if (curRow == 0 || curRow == numRows - 1) {
            dir = -dir;
        }
        
        curRow += dir;
    }
    
    // 拼接结果
    string res;
    for (const auto& row : rows) {
        res.append(row.begin(), row.end());
    }
    
    return res;
}
```

## 总结

### 异常原因

1. **numRows == 0**：`rows` 是空的，访问 `rows[0]` 越界
2. **numRows < 0**：`rows` 是空的，访问越界
3. **numRows == 1 且 dir = -1**：`curRow` 可能变成 1，访问 `rows[1]` 越界

### 修复要点

1. ✅ **添加边界检查**：处理 `numRows <= 0` 的情况
2. ✅ **特殊处理 numRows == 1**：直接返回原字符串
3. ✅ **修正初始方向**：`dir` 应该初始化为 `1`（向下），或者特殊处理

### 关键问题

**第16行 `rows[curRow].push_back(c)` 会异常，因为：**
- 当 `numRows == 0` 时，`rows` 是空的
- 当 `numRows == 1` 且初始 `dir = -1` 时，`curRow` 可能越界

**修复方法：添加边界检查和特殊处理！** 🎯

