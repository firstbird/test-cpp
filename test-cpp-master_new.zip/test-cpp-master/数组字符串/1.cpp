#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <algorithm>
#include <deque>
//LCR 179. 查找总价格为目标值的两个商品
using namespace std;
class Solution {
public:
    vector<int> twoSum(vector<int>& nums, int target) {
	    unordered_map<int, int> map;
	    // unordered_set<int, int> set;
	    // deque<int> que;
	    vector<int>::iterator it = nums.begin();

		// for (auto num : nums) {
		// 	map[num] = static_cast<int>(it - nums.begin());
		// }
		for (auto it = nums.begin(); it < nums.end(); ++it) {
			int num = *it;
			auto other = map.find(target -num);
			if (other != map.end()) {
				return {other->second, static_cast<int>(it-nums.begin())};
			}
			map[num] = it - nums.begin();
		}
	    // for (; it < nums.end(); it++) {
		//     int num = *it;
		//     auto other = map.find(target - num);
		//     if (other != map.end()) {
		// 	    return {other->second, static_cast<int>(it - nums.begin())};
		//     }
		//     map[num] = static_cast<int>(it - nums.begin()); 
	    // }

	    return {};
	    
    }
};