#include <iostream>
#include <string>
#include <utility>
using namespace std;

/**
 * 完美转发 (Perfect Forwarding) 示例
 * 使用通用引用和std::forward实现参数的高效传递
 */

class Widget {
public:
    Widget() {
        cout << "Widget default constructor" << endl;
    }
    
    Widget(const Widget& other) {
        cout << "Widget copy constructor" << endl;
    }
    
    Widget(Widget&& other) noexcept {
        cout << "Widget move constructor" << endl;
    }
    
    Widget& operator=(const Widget& other) {
        cout << "Widget copy assignment" << endl;
        return *this;
    }
    
    Widget& operator=(Widget&& other) noexcept {
        cout << "Widget move assignment" << endl;
        return *this;
    }
};

// 1. 不完美的转发（值传递）
void process1(Widget w) {
    // 总是会调用拷贝构造函数
}

// 2. 不完美的转发（左值引用）
void process2(Widget& w) {
    // 只能接受左值
}

// 3. 不完美的转发（右值引用）
void process3(Widget&& w) {
    // 只能接受右值，但w本身是左值
}

// 4. 完美转发：使用通用引用和std::forward
template<typename T>
void process4(T&& param) {
    // T&& 是通用引用（Universal Reference）
    // 当传入左值时，T被推导为Widget&，T&&为Widget&
    // 当传入右值时，T被推导为Widget，T&&为Widget&&
    
    // 使用std::forward保持值类别
    Widget w(std::forward<T>(param));
}

// 5. 工厂函数示例
template<typename T, typename... Args>
unique_ptr<T> make_unique_helper(Args&&... args) {
    return unique_ptr<T>(new T(std::forward<Args>(args)...));
}

// 6. 包装器示例
template<typename Func, typename... Args>
auto wrapper(Func&& func, Args&&... args) 
    -> decltype(func(std::forward<Args>(args)...)) {
    cout << "Before function call" << endl;
    auto result = func(std::forward<Args>(args)...);
    cout << "After function call" << endl;
    return result;
}

// 7. 实际应用：emplace_back的实现原理
template<typename T>
class Vector {
private:
    T* data_;
    size_t size_;
    size_t capacity_;
    
public:
    template<typename... Args>
    void emplace_back(Args&&... args) {
        // 使用完美转发直接构造，避免拷贝
        if (size_ >= capacity_) {
            // 扩容逻辑...
        }
        new (data_ + size_) T(std::forward<Args>(args)...);
        size_++;
    }
};

// 测试函数
int add(int a, int b) {
    return a + b;
}

int main() {
    cout << "=== Perfect Forwarding Demo ===" << endl;
    
    Widget w1;
    Widget w2;
    
    cout << "\n--- process1 (value) ---" << endl;
    process1(w1);           // 拷贝构造
    process1(Widget());     // 拷贝构造（先移动构造临时对象）
    
    cout << "\n--- process4 (perfect forwarding) ---" << endl;
    process4(w1);          // 拷贝构造（传入左值）
    process4(Widget());    // 移动构造（传入右值）
    process4(move(w2));    // 移动构造（传入右值）
    
    cout << "\n--- wrapper function ---" << endl;
    int result = wrapper(add, 3, 4);
    cout << "Result: " << result << endl;
    
    return 0;
}

