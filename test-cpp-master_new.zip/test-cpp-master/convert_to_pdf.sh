#!/bin/bash
# Convert Markdown to PDF using macOS tools

cd "$(dirname "$0")"

# Try using pandoc if available
if command -v pandoc &> /dev/null; then
    pandoc 简历_精简.md -o 简历_马振立.pdf --pdf-engine=xelatex -V mainfont="PingFang SC" 2>&1
    if [ $? -eq 0 ]; then
        echo "使用pandoc成功转换为PDF"
        exit 0
    fi
fi

# Try using Python with markdown and weasyprint
python3 << 'PYTHON_SCRIPT'
import sys
import os

try:
    import markdown
    from weasyprint import HTML, CSS
except ImportError:
    print("错误: 需要安装 markdown 和 weasyprint 库")
    print("请运行: pip3 install markdown weasyprint")
    sys.exit(1)

# Read markdown file
with open('简历_精简.md', 'r', encoding='utf-8') as f:
    md_content = f.read()

# Convert markdown to HTML
html_content = markdown.markdown(md_content, extensions=['tables', 'fenced_code'])

# Add CSS styling
html_with_style = f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        @page {{
            size: A4;
            margin: 2cm;
        }}
        body {{
            font-family: "PingFang SC", "Microsoft YaHei", "SimSun", Arial, sans-serif;
            line-height: 1.6;
            font-size: 12pt;
        }}
        h1 {{ color: #333; border-bottom: 2px solid #333; padding-bottom: 10px; font-size: 24pt; }}
        h2 {{ color: #555; margin-top: 30px; border-bottom: 1px solid #ddd; padding-bottom: 5px; font-size: 18pt; }}
        h3 {{ color: #666; margin-top: 20px; font-size: 14pt; }}
        h4 {{ color: #777; font-size: 12pt; }}
        table {{ border-collapse: collapse; width: 100%; margin: 20px 0; }}
        th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
        th {{ background-color: #f2f2f2; }}
        ul, ol {{ margin: 10px 0; padding-left: 30px; }}
        code {{ background-color: #f4f4f4; padding: 2px 4px; border-radius: 3px; }}
        hr {{ border: none; border-top: 1px solid #ddd; margin: 20px 0; }}
    </style>
</head>
<body>
    {html_content}
</body>
</html>
"""

# Convert HTML to PDF
HTML(string=html_with_style).write_pdf('简历_new.pdf')
print("成功转换为PDF")
PYTHON_SCRIPT

if [ $? -eq 0 ]; then
    echo "使用Python成功转换为PDF"
    exit 0
fi

echo "转换失败，请安装pandoc或Python的markdown和weasyprint库"
exit 1

