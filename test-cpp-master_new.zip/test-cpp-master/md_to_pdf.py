#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Markdown to PDF converter
"""
import sys
import os

try:
    import markdown
    from weasyprint import HTML, CSS
except ImportError:
    print("需要安装 markdown 和 weasyprint 库")
    print("请运行: pip3 install markdown weasyprint")
    sys.exit(1)

def markdown_to_pdf(md_file, pdf_file):
    """Convert markdown file to PDF"""
    # Read markdown file
    with open(md_file, 'r', encoding='utf-8') as f:
        md_content = f.read()
    
    # Convert markdown to HTML
    html_content = markdown.markdown(md_content, extensions=['tables', 'fenced_code'])
    
    # Add CSS styling
    html_with_style = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <style>
            body {{
                font-family: "PingFang SC", "Microsoft YaHei", "SimSun", Arial, sans-serif;
                line-height: 1.6;
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
            }}
            h1 {{
                color: #333;
                border-bottom: 2px solid #333;
                padding-bottom: 10px;
            }}
            h2 {{
                color: #555;
                margin-top: 30px;
                border-bottom: 1px solid #ddd;
                padding-bottom: 5px;
            }}
            h3 {{
                color: #666;
                margin-top: 20px;
            }}
            h4 {{
                color: #777;
            }}
            table {{
                border-collapse: collapse;
                width: 100%;
                margin: 20px 0;
            }}
            th, td {{
                border: 1px solid #ddd;
                padding: 8px;
                text-align: left;
            }}
            th {{
                background-color: #f2f2f2;
            }}
            ul, ol {{
                margin: 10px 0;
                padding-left: 30px;
            }}
            code {{
                background-color: #f4f4f4;
                padding: 2px 4px;
                border-radius: 3px;
            }}
            hr {{
                border: none;
                border-top: 1px solid #ddd;
                margin: 20px 0;
            }}
        </style>
    </head>
    <body>
        {html_content}
    </body>
    </html>
    """
    
    # Convert HTML to PDF
    HTML(string=html_with_style).write_pdf(pdf_file)
    print(f"成功将 {md_file} 转换为 {pdf_file}")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("用法: python3 md_to_pdf.py <input.md> <output.pdf>")
        sys.exit(1)
    
    md_file = sys.argv[1]
    pdf_file = sys.argv[2]
    
    if not os.path.exists(md_file):
        print(f"错误: 文件 {md_file} 不存在")
        sys.exit(1)
    
    markdown_to_pdf(md_file, pdf_file)

