# Android/Linux 中 DMA-BUF Heap 使用说明

## 概述

DMA-BUF Heap 是内核提供的一种**用户态分配 DMA 缓冲区**的机制，替代了旧的 ION。用户态通过打开 `/dev/dma_heap/<heap_name>` 设备并下发 `DMA_HEAP_IOCTL_ALLOC` ioctl，即可获得一个 dma-buf 的 fd，用于零拷贝共享（GPU、Display、Camera 等）。

- **用户态**：open heap 设备 → ioctl 分配 → 得到 fd → 可 mmap 或把 fd 传给其他进程/组件。
- **内核态**：实现 `dma_heap_ops`，在 `allocate` 里分配内存并 `dma_buf_export` 导出为 dma-buf，再通过 `dma_heap_add` 注册到框架。

---

## 用户态与内核态：头文件与依赖

### 用户态

| 类型 | 内容 |
|------|------|
| **头文件** | `<stdint.h>`（`uint64_t`/`uint32_t`）、`<stdio.h>`、`<stdlib.h>`、`<string.h>`、`<fcntl.h>`（`O_RDWR`/`O_CLOEXEC`）、`<unistd.h>`（`open`/`close`/`read`/`write`）、`<sys/ioctl.h>`（`ioctl`/`_IOWR`）、`<sys/mman.h>`（`mmap`/`munmap`） |
| **可选** | 若在 AOSP/内核树中编译，可直接 `#include <linux/dma-heap.h>` 使用 UAPI 的 `dma_heap_allocation_data` 与 `DMA_HEAP_IOCTL_ALLOC`，否则需在代码中自建与 UAPI 一致的结构体和 ioctl 宏（见 `dma_heap_userspace_example.c`） |
| **库** | 仅需标准 C 库（libc），无需额外链接库；编译时不必加 `-l` |

### 内核态

| 类型 | 内容 |
|------|------|
| **头文件** | `<linux/dma-heap.h>`（`dma_heap_ops`、`dma_heap_add`、`dma_heap_export_info`）、`<linux/dma-buf.h>`（`dma_buf`、`dma_buf_ops`、`dma_buf_export`、`dma_buf_export_info`）、`<linux/scatterlist.h>`（`sg_table`/`sg_alloc_table`/`sg_set_page`）、`<linux/slab.h>`（`kzalloc`/`kfree`）、`<linux/mm.h>`（`alloc_page`/`__free_page`/`PAGE_*`）；按实现还需 `<linux/module.h>`、`<linux/err.h>` 等 |
| **库/依赖** | 作为内核模块或内置代码参与内核编译，不单独“链接库”；依赖内核配置中启用 `CONFIG_DMABUF_HEAPS`（及对应 heap 实现） |

---

## 一、用户态使用

### 1.1 接口与数据结构（UAPI）

- 设备节点：`/dev/dma_heap/<name>`，例如 `/dev/dma_heap/system`、`/dev/dma_heap/linux,cma`（或平台 CMA 节点名）。
- ioctl：`DMA_HEAP_IOCTL_ALLOC`，传入/传出结构体如下（与 `include/uapi/linux/dma-heap.h` 一致）：

```c
struct dma_heap_allocation_data {
    __u64 len;        // 要分配的字节数（会对齐到页）
    __u32 fd;         // 输出：分配得到的 dma-buf 的 fd
    __u32 fd_flags;   // 创建 fd 时的标志，如 O_CLOEXEC | O_RDWR
    __u64 heap_flags; // 目前未用，填 0
};

#define DMA_HEAP_IOC_MAGIC  'H'
#define DMA_HEAP_IOCTL_ALLOC  _IOWR(DMA_HEAP_IOC_MAGIC, 0x0, struct dma_heap_allocation_data)
```

- `fd_flags` 合法值为 `O_CLOEXEC` 与 `O_RDONLY`/`O_WRONLY`/`O_RDWR` 的组合。

### 1.2 基本流程

1. 打开目标 heap：`open("/dev/dma_heap/system", O_RDWR)`。
2. 填充 `dma_heap_allocation_data`：设置 `len`、`fd_flags`（如 `O_CLOEXEC | O_RDWR`），`heap_flags = 0`。
3. 调用 `ioctl(heap_fd, DMA_HEAP_IOCTL_ALLOC, &data)`。
4. 成功后 `data.fd` 即为 dma-buf 的 fd，可用于：
   - `mmap` 映射到用户空间读写；
   - 通过 Binder/Unix socket 等传给其他进程或框架（如 SurfaceFlinger、Camera HAL）。

### 1.3 代码示例

见同目录 **`dma_heap_userspace_example.c`**，编译与运行方式见文件内注释（需能访问 `/dev/dma_heap/system`，如 root 或相应 sepolicy 权限）。

---

## 二、内核态使用（实现一个 Heap）

### 2.1 框架流程

1. 用户态对 heap 设备执行 `DMA_HEAP_IOCTL_ALLOC`。
2. 内核 `dma_heap_buffer_alloc()` 会按页对齐长度，并调用该 heap 注册的 `ops->allocate()`。
3. 在 `allocate()` 中需要：
   - 分配物理/虚拟内存（如 `alloc_pages`、CMA）；
   - 构造 `sg_table` 等，通过 `dma_buf_export()` 导出为 `struct dma_buf *`；
   - 返回该 `dma_buf`，框架会再通过 `dma_buf_fd()` 得到 fd 填回用户态。

### 2.2 关键结构与 API

- **`struct dma_heap_ops`**（`include/linux/dma-heap.h`）  
  - `struct dma_buf *(*allocate)(struct dma_heap *heap, unsigned long len, unsigned long fd_flags, unsigned long heap_flags);`

- **注册 heap**  
  - 填充 `struct dma_heap_export_info`：`name`、`ops`、`priv`。  
  - 调用 `dma_heap_add()`，框架会创建设备节点 `/dev/dma_heap/<name>`。

- **导出 dma-buf**  
  - 实现 `struct dma_buf_ops`（`attach`、`detach`、`map_dma_buf`、`mmap` 等）。  
  - 使用 `dma_buf_export()` 或 `DEFINE_DMA_BUF_EXPORT_INFO` + `dma_buf_export()` 得到 `struct dma_buf *`。

### 2.3 代码示例

见同目录 **`dma_heap_kernel_example.c`**，为简化版“自定义 heap”实现思路（基于 `alloc_pages` + `sg_table` + `dma_buf_export`），需放入内核源码树（如 `drivers/dma-buf/heaps/`）并配置 Kconfig/Makefile 后编译为模块或内置。实际工程中可参考 `drivers/dma-buf/heaps/system_heap.c` 与内核文档。

---

## 三、Android 相关说明

- 从 Android 12（GKI 2.0）起，DMA-BUF Heaps 取代 ION；设备节点与 ioctl 与主线一致。
- 用户态库：`libdmabufheap`（`system/memory/libdmabufheap`）对应用层封装了 open + ioctl，可参考其 `BufferAllocator`。
- 内核侧：常见 heap 由 GKI 或厂商内核提供（如 `system`、CMA、安全/保护 heap），自定义 heap 需在内核模块或 SoC 代码中实现并调用 `dma_heap_add()`。

---

## 四、本目录文件

| 文件 | 说明 |
|------|------|
| `dma_heap_usage.md` | 本文档：用户态/内核态使用说明 |
| `dma_heap_userspace_example.c` | 用户态：open + ioctl 分配 + mmap 示例 |
| `dma_heap_kernel_example.c` | 内核态：最小化 heap 实现示例（需入内核树编译） |
