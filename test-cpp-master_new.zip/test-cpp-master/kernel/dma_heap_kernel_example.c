/*
 * DMA-BUF Heap 内核态实现示例（简化版）
 *
 * 演示如何实现一个自定义 heap：在 allocate() 里分配内存并导出为 dma_buf，
 * 通过 dma_heap_add() 注册后，用户态即可通过 /dev/dma_heap/<name> 分配。
 *
 * 使用方式：
 *   - 将本文件放入内核源码树，例如 drivers/dma-buf/heaps/，
 *   - 去掉 #if 0 / #endif，按当前内核版本补全头文件与 API（如 dma_heap_export_info 等），
 *   - 在 Kconfig / Makefile 中增加对应项后编译为模块或内置。
 *
 * 实际工程请参考：drivers/dma-buf/heaps/system_heap.c
 * 以及 Documentation/userspace-api/dma-buf-heaps.rst
 */

/* 以下为示意性代码结构，具体 API 以当前内核版本为准；去掉 #if 0 并补齐 API 后可参与内核编译 */
#if 0

#include <linux/dma-heap.h>
#include <linux/dma-buf.h>
#include <linux/scatterlist.h>
#include <linux/slab.h>
#include <linux/mm.h>

/* ---------- 1. 每个 buffer 的私有数据（页指针、sg_table 等） ---------- */
struct my_heap_buffer {
	struct sg_table *table;
	void *vaddr;
	size_t len;
	int page_count;
	struct page **pages;
};

/* ---------- 2. dma_buf 操作：attach/detach/map/unmap/release/mmap ---------- */
static int my_heap_dma_buf_attach(struct dma_buf *dmabuf, struct dma_buf_attachment *attach)
{
	/* 可选：记录 attachment，用于 map_dma_buf 时做 cache 同步等 */
	return 0;
}

static void my_heap_dma_buf_detach(struct dma_buf *dmabuf, struct dma_buf_attachment *attach)
{
}

static struct sg_table *my_heap_map_dma_buf(struct dma_buf_attachment *attach,
					    enum dma_data_direction direction)
{
	struct my_heap_buffer *buf = attach->dmabuf->priv;
	struct sg_table *table = buf->table;
	/* 通常直接返回 heap 内部的 sg_table（或复制一份），供 DMA 映射使用 */
	return table;
}

static void my_heap_unmap_dma_buf(struct dma_buf_attachment *attach,
				  struct sg_table *table, enum dma_data_direction direction)
{
}

static int my_heap_mmap(struct dma_buf *dmabuf, struct vm_area_struct *vma)
{
	struct my_heap_buffer *buf = dmabuf->priv;
	/* 将 buf->pages 映射到 vma，例如 vm_map_pages() */
	return 0;
}

static void my_heap_dma_buf_release(struct dma_buf *dmabuf)
{
	struct my_heap_buffer *buf = dmabuf->priv;
	/* 释放 sg_table、pages、vaddr 等 */
	kfree(buf);
}

static const struct dma_buf_ops my_heap_buf_ops = {
	.attach      = my_heap_dma_buf_attach,
	.detach      = my_heap_dma_buf_detach,
	.map_dma_buf = my_heap_map_dma_buf,
	.unmap_dma_buf = my_heap_unmap_dma_buf,
	.release     = my_heap_dma_buf_release,
	.mmap        = my_heap_mmap,
};

/* ---------- 3. heap 的 allocate 回调：分配内存并导出为 dma_buf ---------- */
static struct dma_buf *my_heap_allocate(struct dma_heap *heap,
					unsigned long len,
					unsigned long fd_flags,
					unsigned long heap_flags)
{
	struct my_heap_buffer *buf;
	struct dma_buf *dmabuf;
	struct dma_buf_export_info exp_info = { 0 };
	struct sg_table *table;
	struct scatterlist *sg;
	int i, ret;
	size_t page_count = PAGE_ALIGN(len) >> PAGE_SHIFT;

	buf = kzalloc(sizeof(*buf), GFP_KERNEL);
	if (!buf)
		return ERR_PTR(-ENOMEM);

	buf->len = len;
	buf->page_count = page_count;
	buf->pages = kcalloc(page_count, sizeof(struct page *), GFP_KERNEL);
	if (!buf->pages) {
		ret = -ENOMEM;
		goto err_buf;
	}

	/* 分配页（示例：普通页，实际可用 CMA、uncached 等） */
	for (i = 0; i < page_count; i++) {
		buf->pages[i] = alloc_page(GFP_KERNEL | __GFP_ZERO);
		if (!buf->pages[i])
			goto err_pages;
	}

	/* 构造 sg_table 供 DMA 映射和导出使用 */
	table = kzalloc(sizeof(*table), GFP_KERNEL);
	if (!table)
		goto err_pages;
	ret = sg_alloc_table(table, page_count, GFP_KERNEL);
	if (ret)
		goto err_table;
	for_each_sgtable_sg(table, sg, i)
		sg_set_page(sg, buf->pages[i], PAGE_SIZE, 0);
	buf->table = table;

	/* 导出为 dma_buf */
	exp_info.ops  = &my_heap_buf_ops;
	exp_info.size = len;
	exp_info.priv = buf;
	exp_info.flags = fd_flags;
	dmabuf = dma_buf_export(&exp_info);
	if (IS_ERR(dmabuf)) {
		ret = PTR_ERR(dmabuf);
		goto err_export;
	}
	return dmabuf;

err_export:
	sg_free_table(table);
err_table:
	kfree(table);
err_pages:
	for (i = 0; i < page_count && buf->pages[i]; i++)
		__free_page(buf->pages[i]);
	kfree(buf->pages);
err_buf:
	kfree(buf);
	return ERR_PTR(ret);
}

static struct dma_heap_ops my_heap_ops = {
	.allocate = my_heap_allocate,
};

/* ---------- 4. 注册 heap（init 时调用，unregister 在 exit 时） ---------- */
static struct dma_heap *my_heap;

static int __init my_heap_init(void)
{
	struct dma_heap_export_info exp_info = {
		.name = "my_example_heap",
		.ops  = &my_heap_ops,
		.priv = NULL,
	};
	my_heap = dma_heap_add(&exp_info);
	if (IS_ERR(my_heap))
		return PTR_ERR(my_heap);
	return 0;
}

static void __exit my_heap_exit(void)
{
	dma_heap_put(my_heap);
}

module_init(my_heap_init);
module_exit(my_heap_exit);
MODULE_LICENSE("GPL");

#endif
