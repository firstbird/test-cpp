/*
 * DMA-BUF Heap 用户态使用示例（Android/Linux）
 *
 * 流程：打开 /dev/dma_heap/<name> → ioctl(DMA_HEAP_IOCTL_ALLOC) → 得到 dma-buf fd → 可选 mmap
 *
 * 编译（Android NDK 或 Linux）:
 *   gcc -o dma_heap_userspace_example dma_heap_userspace_example.c
 * 运行需能访问 /dev/dma_heap/system（root 或相应 sepolicy）。
 */

#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/mman.h>

/* 与 UAPI include/uapi/linux/dma-heap.h 一致 */
struct dma_heap_allocation_data {
	uint64_t len;
	uint32_t fd;
	uint32_t fd_flags;
	uint64_t heap_flags;
};

#define DMA_HEAP_IOC_MAGIC  'H'
#define DMA_HEAP_IOCTL_ALLOC  _IOWR(DMA_HEAP_IOC_MAGIC, 0x0, struct dma_heap_allocation_data)

#define HEAP_DEVICE  "/dev/dma_heap/system"
#define ALLOC_SIZE   (256 * 1024)   /* 256KB */

int main(void)
{
	int heap_fd = -1;
	struct dma_heap_allocation_data data = { 0 };
	void *ptr = NULL;

	/* 1. 打开 heap 设备 */
	heap_fd = open(HEAP_DEVICE, O_RDWR);
	if (heap_fd < 0) {
		perror("open " HEAP_DEVICE);
		return 1;
	}

	/* 2. 填充分配参数 */
	data.len       = ALLOC_SIZE;
	data.fd_flags  = O_CLOEXEC | O_RDWR;
	data.heap_flags = 0;

	/* 3. 分配，得到 dma-buf 的 fd */
	if (ioctl(heap_fd, DMA_HEAP_IOCTL_ALLOC, &data) < 0) {
		perror("ioctl DMA_HEAP_IOCTL_ALLOC");
		close(heap_fd);
		return 1;
	}

	printf("allocated dma-buf fd = %u, len = %llu\n", (unsigned int)data.fd, (unsigned long long)data.len);

	/* 4. 可选：mmap 到用户空间读写 */
	ptr = mmap(NULL, data.len, PROT_READ | PROT_WRITE, MAP_SHARED, data.fd, 0);
	if (ptr == MAP_FAILED) {
		perror("mmap dma-buf");
		close(data.fd);
		close(heap_fd);
		return 1;
	}

	/* 示例：写一点数据 */
	memset(ptr, 0xAB, 4096);
	printf("mmap ok, wrote 4K at %p\n", ptr);

	munmap(ptr, data.len);
	close(data.fd);
	close(heap_fd);
	return 0;
}
