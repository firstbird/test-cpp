#include <string>
#include <unordered_map>
#include <climits>
using namespace std;

/**
 * LeetCode 76: 最小覆盖子串
 * 给你一个字符串 s 、一个字符串 t 。返回 s 中涵盖 t 所有字符的最小子串。
 * 如果 s 中不存在涵盖 t 所有字符的子串，则返回空字符串 "" 。
 */
class Solution {
public:
// 计数/覆盖型约束
//while (valid == need.size()) {   // 已经“覆盖”所有需要的字符
// 更新最优答案（最短区间）
// 左移 left，把 s[left] 移出 window，更新 window[d]、valid;
// }
//条件类型：window 中各字符计数 都 >= need（完全覆盖）。
// 模版特点：
// 核心变量：need（需求计数）、window（窗口计数）、valid（当前有多少种字符已经满足）。
// 外层扩、内层 while 收：和 209 类似，但判断的是“所有种类都满足”（valid == need.size()），不是数值和。
// minWindow2 本质也是相同思想，只是用 map[ch] 统计“还差多少”，count 统计“还差多少种”。
    string minWindow(string s, string t) {
        unordered_map<char, int> need, window;
        
        // 统计t中每个字符需要的次数
        for (char c : t) {
            need[c]++;
        }
        
        int left = 0, right = 0;
        int valid = 0; // 窗口中满足need条件的字符个数
        int start = 0, len = INT_MAX;
        
        while (right < s.size()) {
            // 扩大窗口
            char c = s[right];
            right++;
            
            // 进行窗口内数据的一系列更新
            if (need.count(c)) {
                window[c]++;
                if (window[c] == need[c]) {
                    valid++;
                }
            }
            
            // 判断左侧窗口是否要收缩
            while (valid == need.size()) {
                // 更新最小覆盖子串
                if (right - left < len) {
                    start = left;
                    len = right - left;
                }
                
                // 缩小窗口
                char d = s[left];
                left++;
                
                // 进行窗口内数据的一系列更新
                if (need.count(d)) {
                    if (window[d] == need[d]) {
                        valid--;
                    }
                    window[d]--;
                }
            }
        }
        
        return len == INT_MAX ? "" : s.substr(start, len);
    }

    string minWindow2(string s, string t) {
        unordered_map<char, int> map;  // 记录t中每个字符还需要多少次
        for (char ch : t) {
            map[ch]++;
        }
        int n = s.length();
        int left = 0;
        int count = map.size();  // 还需要多少个不同的字符
        int minWindow = n + 1;
        int start = 0;  // 最小窗口的起始位置
        
        for (int right = 0; right < n; right++) {
            // 如果s[right]不在t中，跳过
            if (map.find(s[right]) == map.end()) {
                continue;
            }
            
            // 减少需要的次数
            map[s[right]]--;
            
            // 如果这个字符已经满足需求（次数为0）
            if (map[s[right]] == 0) {
                count--;  // 需要的不同字符数减1
            
                // 当所有字符都满足需求时，尝试缩小窗口
                while (count == 0) {
                    // 更新最小窗口
                    if (right - left + 1 < minWindow) {
                        minWindow = right - left + 1;
                        start = left;
                    }
                    
                    // 缩小窗口：left右移
                    char d = s[left];
                    left++;
                    
                    // 如果移除的字符在t中，需要恢复计数
                    if (map.find(d) != map.end()) {
                        map[d]++;
                        if (map[d] > 0) {  // 如果需要的次数大于0，说明不满足了
                            count++;
                        }
                    }
                }
            }
        }
        
        return minWindow == n + 1 ? "" : s.substr(start, minWindow);
    }
};

