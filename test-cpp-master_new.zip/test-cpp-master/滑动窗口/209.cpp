int minSubArrayLen(int target, vector<int>& nums) {
    int left = 0;
    int right = 0;
    int n = nums.size();
    int sum = 0;
    int res = n + 1;
    while (right < n) {
        sum += nums[right];

        while (left <= right && sum >= target) {
            res = min(res, right - left +1);
            sum -= nums[left];  
            left++;
        }
        right++;

    }
    return res == n + 1 ? 0 : res;
}