#include <string>
#include <unordered_map>
using namespace std;

/**
 * LeetCode 567: 字符串的排列
 * 给你两个字符串 s1 和 s2 ，写一个函数来判断 s2 是否包含 s1 的排列。
 * 换句话说，s1 的排列之一是 s2 的 子串 。
 */
class Solution {
public:
    bool checkInclusion(string s1, string s2) {
        unordered_map<char, int> need, window;
        
        for (char c : s1) {
            need[c]++;
        }
        
        int left = 0, right = 0;
        int valid = 0;
        
        while (right < s2.size()) {
            char c = s2[right];
            right++;
            
            if (need.count(c)) {
                window[c]++;
                if (window[c] == need[c]) {
                    valid++;
                }
            }
            
            // 窗口大小固定为s1的长度
            // 
// 右移 right，更新 window & valid;while (right - left >= s1.size()) {   // 固定窗口大小    if (valid == need.size()) return true;    左移 left，更新 window & valid;}
    // 条件类型：窗口大小固定为 len(s1)，并且窗口计数 == 需求计数。
    // 模版特点：
    // 同样有 need/window/valid；
    // 但窗口必须是固定长度：right - left >= len(s1) 时就必须收缩一次（不管满不满足条件），因此用的是“固定大小窗口 + 计数匹配”的模版。
            while (right - left >= s1.size()) {
                if (valid == need.size()) {
                    return true;
                }
                
                char d = s2[left];
                left++;
                
                if (need.count(d)) {
                    if (window[d] == need[d]) {
                        valid--;
                    }
                    window[d]--;
                }
            }
        }
        
        return false;
    }
};

