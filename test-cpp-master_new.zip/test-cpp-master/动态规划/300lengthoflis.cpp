
#include <string>
#include <vector>
#include <unordered_map>
using namespace std;

class Solution {
public:
    int lengthOfLIS(vector<int>& nums) {
	    int n = nums.size();
	    vector<int> dp(n, 1);
	    int res = 1;
	    dp[0] = 1;
		// 和139一样，拆分输入数据，外层是i，内层是j
	    for (int i = 1; i < n; ++i) {
		    dp[i] = 1;

			// i前面找一个小于i的值，更新dp[i]
		    for (int j = 0; j < i; ++j) {
			    if (nums[i] > nums[j]) {
				    dp[i] = max(dp[i], dp[j] + 1);
			    }
		    }
		    res = max(dp[i], res);
	    }
	    return res;
    }
};