#include <vector>
#include <numeric>
using namespace std;

/**
 * LeetCode 494: 目标和
 * 给数组中的数添加+或-，使得和等于target，求方案数。
 * 
 * 转换为0-1背包问题：
 * 设正数和为P，负数和为N
 * P - N = target
 * P + N = sum
 * => P = (target + sum) / 2
 * 
 * 问题转化为：从数组中选数，和为P的方案数
 */
class Solution {
public:
    int findTargetSumWays(vector<int>& nums, int target) {
        int sum = accumulate(nums.begin(), nums.end(), 0);
        
        // 方法1：求正数和P = (target + sum) / 2
        int diff = sum + target;
        if (diff < 0 || diff % 2 != 0) {
            return 0;
        }
        
        int pos = diff / 2;  // 正数和P = (sum + target) / 2
        
        // dp[j]: 前i个物品，和为j的方案数
        vector<int> dp(pos + 1, 0);
        dp[0] = 1;  // 和为0有1种方案（不选任何物品）
        
        for (int num : nums) {
            // 从后往前遍历，避免重复使用（0-1背包特征）
            for (int j = pos; j >= num; j--) {
                dp[j] += dp[j - num];
                // 方案数 = 不选num的方案数 + 选num的方案数
            }
        }
        
        return dp[pos];
        
        // 方法2：求负数和N = (sum - target) / 2（等价方法）
        // int diff = sum - target;
        // if (diff < 0 || diff % 2 != 0) return 0;
        // int neg = diff / 2;
        // ... 求dp[neg]，结果相同
    }
};

