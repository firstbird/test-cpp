#include <string>
#include <vector>
#include <unordered_set>
using namespace std;

/**
 * LeetCode 139: 单词拆分
 * 给定字符串s和单词字典wordDict，判断s是否可以被拆分成字典中的单词。
 * 
 * 完全背包问题：
 * - 物品：字典中的单词（可以使用多次）
 * - 容量：字符串的位置
 * - 价值：能否拆分（布尔值）
 */

class Solution {
public:
    // 方式1：容量在外层（当前写法，可以提前break）
    bool wordBreak(string s, vector<string>& wordDict) {
        int n = s.size();
        vector<bool> dp(n + 1, false);
        dp[0] = true;  // 空字符串可以拆分
        
        // 外层：字符串位置（容量）
		// 这种是非标准的完全背包，物品不是天然的，是根据输入数据拆分的，和300一样
        for (int i = 1; i <= n; i++) {
            // 内层：字典单词（物品）
            for (auto& word : wordDict) {
                if (i >= word.size()) {
                    string sub = s.substr(i - word.size(), word.size());
                    if (sub == word && dp[i - word.size()]) {
                        dp[i] = true;
                        break;  // 找到一个匹配就可以
                    }
                }
            }
        }
        return dp[n];
    }
    
    // 方式2：物品在外层（也可以，符合标准完全背包模板）
    bool wordBreak2(string s, vector<string>& wordDict) {
        int n = s.size();
        vector<bool> dp(n + 1, false);
        dp[0] = true;
        
        // 外层：字典单词（物品）
        for (auto& word : wordDict) {
            // 内层：字符串位置（容量），从前往后遍历
            for (int i = word.size(); i <= n; i++) {
                string sub = s.substr(i - word.size(), word.size());
                if (sub == word && dp[i - word.size()]) {
                    dp[i] = true;  // 或运算，可以累积
                }
            }
        }
        return dp[n];
    }
};