#include <vector>
using namespace std;

/**
 * LeetCode 518: 零钱兑换II
 * 用硬币凑成amount的方案数。
 * 
 * 完全背包问题：
 * - 每种硬币可以使用无限次
 * - 从前往后遍历，允许重复使用
 */
class Solution {
public:
    int change(int amount, vector<int>& coins) {
        // dp[j]: 凑成金额j的方案数
        vector<int> dp(amount + 1, 0);
        dp[0] = 1;  // 金额0有1种方案（不选任何硬币）
        
        //关键原因
// 从后往前遍历时，dp[j-nums[i]] 是旧值
// 因为 j-nums[i] < j，而我们从大到小遍历
// 所以 dp[j-nums[i]] 还没被更新，是上一轮的值
// 从前往后遍历时，dp[j-nums[i]] 可能是新值
// 因为 j-nums[i] < j，而我们从前往后遍历
// 所以 dp[j-nums[i]] 已经被更新过了，是当前轮的值
// 0-1背包要求使用旧值（上一轮的值）
// 这样才能保证每个物品只被使用一次

        for (int coin : coins) {
            // 【从前往后遍历，允许】重复使用（完全背包特征）
            for (int j = coin; j <= amount; j++) {
                dp[j] += dp[j - coin];
                // 方案数 = 不选coin的方案数 + 选coin的方案数
            }
        }
        
        return dp[amount];
    }
};

