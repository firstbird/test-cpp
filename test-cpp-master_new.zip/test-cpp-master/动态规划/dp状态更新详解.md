# dp[j] = dp[j] || dp[j-nums[i]] 详解

## 问题

```cpp
dp[j] = dp[j] || dp[j - nums[i]];
//      ↑        ↑
//      为什么dp[j]的计算依赖dp[j]自己？
```

## 关键理解：等号左边 vs 等号右边

### 等号右边 = 旧值（更新前）
### 等号左边 = 新值（更新后）

```cpp
dp[j] = dp[j] || dp[j - nums[i]];
// ↑           ↑
// 新值        旧值（更新前的值）
```

## 详细解释

### 1. 等号右边的 `dp[j]` 是旧值

**在赋值之前，`dp[j]` 保存的是上一轮循环的值：**

```cpp
// 假设当前是第i轮循环（处理第i个物品）
for (int j = target; j >= nums[i]; j--) {
    // 此时 dp[j] 的值 = 上一轮（i-1轮）循环后的值
    // 即：dp[j] = dp[i-1][j]（二维DP的表示）
    
    dp[j] = dp[j] || dp[j - nums[i]];
    //      ↑
    //      这是旧值，表示"不选第i个物品"的情况
}
```

### 2. 等号左边的 `dp[j]` 是新值

**赋值之后，`dp[j]` 保存的是当前轮循环的值：**

```cpp
dp[j] = dp[j] || dp[j - nums[i]];
// ↑
// 这是新值，表示"处理完第i个物品后"的状态
// 即：dp[j] = dp[i][j]（二维DP的表示）
```

## 等价于二维DP

### 二维DP的状态转移

```cpp
// 二维DP版本
dp[i][j] = dp[i-1][j] || dp[i-1][j-nums[i]];
//          ↑            ↑
//          不选第i个    选第i个
```

### 一维DP的状态转移

```cpp
// 一维DP版本（空间优化）
dp[j] = dp[j] || dp[j - nums[i]];
//      ↑        ↑
//      旧值      旧值
//      (dp[i-1][j])  (dp[i-1][j-nums[i]])
```

**对应关系：**
- 等号右边的 `dp[j]` = `dp[i-1][j]`（不选第i个物品）
- 等号右边的 `dp[j-nums[i]]` = `dp[i-1][j-nums[i]]`（选第i个物品）
- 等号左边的 `dp[j]` = `dp[i][j]`（更新后的状态）

## 完整示例

### 示例：416题 - 分割等和子集

**输入：** `nums = [1, 5, 11, 5]`, `target = 11`

**初始状态：**
```
dp[0] = true   (容量0可以装满)
dp[1..11] = false
```

**第1轮循环（i=0，处理nums[0]=1）：**

```cpp
// 从后往前遍历
j=11: dp[11] = dp[11] || dp[10]
      //      false || false = false
      //      旧值: false（上一轮的值）
      
j=10: dp[10] = dp[10] || dp[9]
      //      false || false = false
      
...

j=1:  dp[1] = dp[1] || dp[0]
      //    false || true = true  ✅
      //    旧值: false（上一轮的值）
      //    dp[0] = true（初始值）

// 第1轮结束后：
// dp[0] = true, dp[1] = true, dp[2..11] = false
```

**第2轮循环（i=1，处理nums[1]=5）：**

```cpp
j=11: dp[11] = dp[11] || dp[6]
      //      false || false = false
      //      旧值: false（第1轮后的值）
      
j=10: dp[10] = dp[10] || dp[5]
      //      false || false = false
      
j=6:  dp[6] = dp[6] || dp[1]
      //    false || true = true  ✅
      //    旧值: false（第1轮后的值）
      //    dp[1] = true（第1轮后的值）
      
j=5:  dp[5] = dp[5] || dp[0]
      //    false || true = true  ✅
      //    旧值: false（第1轮后的值）
      //    dp[0] = true（初始值）

j=1:  dp[1] = dp[1] || dp[-4]  // 跳过（j < nums[1]）

// 第2轮结束后：
// dp[0] = true, dp[1] = true, dp[5] = true, dp[6] = true, 其他 = false
```

## 为什么从后往前遍历？

### 关键：保证使用的是旧值

**从后往前遍历（正确）：**

```cpp
for (int j = target; j >= nums[i]; j--) {
    dp[j] = dp[j] || dp[j - nums[i]];
    //      ↑        ↑
    //      旧值     旧值（因为j-nums[i] < j，还没更新）
}
```

**为什么 `dp[j-nums[i]]` 也是旧值？**

因为 `j-nums[i] < j`，而我们从后往前遍历：
- 先更新 `dp[j]`
- 后更新 `dp[j-nums[i]]`
- 所以更新 `dp[j]` 时，`dp[j-nums[i]]` 还是旧值 ✅

**从前往后遍历（错误）：**

```cpp
for (int j = nums[i]; j <= target; j++) {
    dp[j] = dp[j] || dp[j - nums[i]];
    //      ↑        ↑
    //      旧值     新值（可能已经更新了！）❌
}
```

**为什么错误？**

因为 `j-nums[i] < j`，而我们从前往后遍历：
- 先更新 `dp[j-nums[i]]`
- 后更新 `dp[j]`
- 所以更新 `dp[j]` 时，`dp[j-nums[i]]` 已经是新值 ❌
- 这会导致重复使用同一物品（完全背包的行为）

## 可视化理解

### 状态更新过程

```
初始状态（第0轮）:
dp = [true, false, false, false, false, false, ...]
     dp[0] dp[1]  dp[2]  dp[3]  dp[4]  dp[5]

第1轮循环（i=0，nums[0]=1）:
从后往前遍历 j = 11, 10, ..., 1

j=1时:
  旧值: dp[1] = false（第0轮的值）
  旧值: dp[0] = true（第0轮的值）
  新值: dp[1] = false || true = true
  
更新后:
dp = [true, true, false, false, false, false, ...]
     dp[0] dp[1]  dp[2]  dp[3]  dp[4]  dp[5]
     ↑旧值  ↑新值
```

### 内存视角

```cpp
// 内存中的dp数组（一维）
dp[0]  dp[1]  dp[2]  ...  dp[j-nums[i]]  ...  dp[j]  ...  dp[target]
  ↓      ↓      ↓              ↓                  ↓
旧值   旧值   旧值           旧值               旧值

// 执行 dp[j] = dp[j] || dp[j-nums[i]] 后
dp[0]  dp[1]  dp[2]  ...  dp[j-nums[i]]  ...  dp[j]  ...  dp[target]
  ↓      ↓      ↓              ↓                  ↓
旧值   旧值   旧值           旧值               新值（更新）
```

## 等价写法（更清晰）

### 写法1：当前写法（简洁）

```cpp
dp[j] = dp[j] || dp[j - nums[i]];
```

### 写法2：显式使用旧值（更清晰）

```cpp
bool oldValue = dp[j];  // 保存旧值
bool canSelect = (j >= nums[i]) ? dp[j - nums[i]] : false;
dp[j] = oldValue || canSelect;
```

### 写法3：二维DP（最直观）

```cpp
vector<vector<bool>> dp(n + 1, vector<bool>(target + 1, false));
dp[0][0] = true;

for (int i = 1; i <= n; i++) {
    for (int j = 0; j <= target; j++) {
        dp[i][j] = dp[i-1][j];  // 不选
        if (j >= nums[i-1]) {
            dp[i][j] = dp[i][j] || dp[i-1][j - nums[i-1]];  // 选
        }
    }
}
```

## 总结

### 回答你的问题

**Q: 为什么 `dp[j]` 的计算依赖 `dp[j]` 自己？**

**A: 因为等号右边是旧值，等号左边是新值！**

```cpp
dp[j] = dp[j] || dp[j - nums[i]];
// ↑           ↑
// 新值        旧值（更新前的值）
```

### 关键点

1. **等号右边的 `dp[j]`** = 旧值 = `dp[i-1][j]`（不选第i个物品）
2. **等号右边的 `dp[j-nums[i]]`** = 旧值 = `dp[i-1][j-nums[i]]`（选第i个物品）
3. **等号左边的 `dp[j]`** = 新值 = `dp[i][j]`（更新后的状态）
4. **从后往前遍历** 保证使用的是旧值

### 记忆要点

- **等号右边 = 旧值（更新前）**
- **等号左边 = 新值（更新后）**
- **从后往前遍历 = 保证使用旧值**

这就是状态更新的本质！🎯

