#include <vector>
#include <algorithm>
#include <climits>
using namespace std;

/**
 * LeetCode 322: 零钱兑换
 * 用最少的硬币数凑成amount。
 * 
 * 完全背包问题：
 * - 每种硬币可以使用无限次
 * - 从前往后遍历，允许重复使用
 */
class Solution {
public:
    int coinChange(vector<int>& coins, int amount) {
        // dp[j]: 凑成金额j所需的最少硬币数
        vector<int> dp(amount + 1, amount + 1);
        dp[0] = 0;  // 金额0需要0个硬币
        
        for (int coin : coins) {
            // 从前往后遍历，允许重复使用（完全背包特征）
            for (int j = coin; j <= amount; j++) {
                dp[j] = min(dp[j], dp[j - coin] + 1);
                // 不选coin        选coin（可以用多次）
            }
        }
        
        return dp[amount] > amount ? -1 : dp[amount];
    }
};

