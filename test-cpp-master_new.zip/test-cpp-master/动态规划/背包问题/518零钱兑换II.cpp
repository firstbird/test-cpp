#include <vector>
using namespace std;

/**
 * LeetCode 518: 零钱兑换II
 * 用硬币凑成amount的方案数。
 * 
 * 完全背包问题：
 * - 每种硬币可以使用无限次
 * - 从前往后遍历，允许重复使用
 */
class Solution {
public:
    int change(int amount, vector<int>& coins) {
        // dp[j]: 凑成金额j的方案数
        vector<int> dp(amount + 1, 0);
        dp[0] = 1;  // 金额0有1种方案（不选任何硬币）
        
        for (int coin : coins) {
            // 从前往后遍历，允许重复使用（完全背包特征）
            for (int j = coin; j <= amount; j++) {
                dp[j] += dp[j - coin];
                // 方案数 = 不选coin的方案数 + 选coin的方案数
            }
        }
        
        return dp[amount];
    }
};

