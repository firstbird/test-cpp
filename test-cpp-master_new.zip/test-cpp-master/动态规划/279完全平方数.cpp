#include <vector>
#include <algorithm>
#include <climits>
#include <cmath>
using namespace std;

/**
 * LeetCode 279: 完全平方数
 * 找到和为n的完全平方数的最少数量。
 * 
 * 完全背包问题：
 * - 物品：1, 4, 9, 16, ... (完全平方数)
 * - 每种平方数可以使用无限次
 * - 从前往后遍历
 */
class Solution {
public:
    int numSquares(int n) {
        // dp[j]: 和为j所需的最少完全平方数
        vector<int> dp(n + 1, INT_MAX);
        dp[0] = 0;  // 和为0需要0个完全平方数
        
        // 遍历所有可能的完全平方数
        for (int i = 1; i * i <= n; i++) {
            int square = i * i;
            // 从前往后遍历，允许重复使用（完全背包特征）
            for (int j = square; j <= n; j++) {
                if (dp[j - square] != INT_MAX) {
                    dp[j] = min(dp[j], dp[j - square] + 1);
                }
            }
        }
        
        return dp[n];
    }
};

