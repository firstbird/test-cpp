#include <string>
#include <vector>
#include <iostream>
using namespace std;

//5. 最长回文子串
class Solution {
public:
    string longestPalindrome(string s) {
	    int n = s.size();
	    vector<vector<bool>> dp(n, vector<bool>(n + 1, false));
	    for (int i = 0; i < n; ++i) {
		    dp[i][1] = true;
	    }
		//从i开始选择，j个字符是否是回文
	    int maxLen = 1;  // 初始化：至少有一个字符
	    int start = 0;   // 初始化：从位置0开始
	    
	    for (int j = 2; j <= n; ++j) {
		    for (int i = 0; i + j <= n; ++i) {
			    if (j > 2) {
				    dp[i][j] = dp[i + 1][j - 2] && s[i] == s[i + j - 1];
			    } else {
				    dp[i][j] = (s[i] == s[i + j - 1]);
			    }
			    
			    // 在计算dp的同时记录最长回文
			    if (dp[i][j] && j > maxLen) {
				    maxLen = j;
				    start = i;
			    }
		    }
	    }
	    return s.substr(start, maxLen);
    }
};

int main()
{
	Solution s;
	cout <<s.longestPalindrome("abbacc") << endl; // Call myMax for int

	return 0;
}