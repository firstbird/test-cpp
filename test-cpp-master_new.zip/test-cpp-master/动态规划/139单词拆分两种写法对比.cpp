#include <string>
#include <vector>
#include <unordered_set>
using namespace std;

/**
 * LeetCode 139: 单词拆分
 * 给定字符串s和单词字典wordDict，判断s是否可以被拆分成字典中的单词。
 */

class Solution {
public:
    // 方式1：容量在外层（标准写法）
    bool wordBreak1(string s, vector<string>& wordDict) {
        int n = s.size();
        vector<bool> dp(n + 1, false);
        dp[0] = true;  // 空字符串可以拆分
        
        // 外层：字符串位置（容量）
        for (int i = 1; i <= n; i++) {
            // 内层：字典单词（物品）
            for (auto& word : wordDict) {
                if (i >= word.size()) {
                    string sub = s.substr(i - word.size(), word.size());
                    if (sub == word && dp[i - word.size()]) {
                        dp[i] = true;
                        break;  // 找到一个匹配就可以
                    }
                }
            }
        }
        return dp[n];
    }
    
    // 方式2：物品在外层（也可以，但需要注意）
    bool wordBreak2(string s, vector<string>& wordDict) {
        int n = s.size();
        vector<bool> dp(n + 1, false);
        dp[0] = true;  // 空字符串可以拆分
        
        // 外层：字典单词（物品）
        for (auto& word : wordDict) {
            // 内层：字符串位置（容量），从前往后遍历
            for (int i = word.size(); i <= n; i++) {
                // 检查s[i-word.size()...i]是否匹配word
                string sub = s.substr(i - word.size(), word.size());
                if (sub == word && dp[i - word.size()]) {
                    dp[i] = true;  // 或运算，可以累积
                }
            }
        }
        return dp[n];
    }
    
    // 方式2修正：物品在外层（正确的写法）
    bool wordBreak3(string s, vector<string>& wordDict) {
        int n = s.size();
        vector<bool> dp(n + 1, false);
        dp[0] = true;
        
        // 外层：字典单词（物品）
        for (auto& word : wordDict) {
            int len = word.size();
            // 内层：字符串位置（容量），从前往后遍历
            for (int i = len; i <= n; i++) {
                // ✅ 正确：先检查匹配，再检查dp
                string sub = s.substr(i - len, len);
                if (sub == word && dp[i - len]) {
                    dp[i] = true;
                }
            }
        }
        return dp[n];
    }
};

/**
 * 两种方式对比：
 * 
 * 方式1（容量在外层）：
 * - 对于每个位置i，尝试所有word
 * - 找到一个匹配就可以break
 * - 更直观：从前往后处理字符串
 * 
 * 方式2（物品在外层）：
 * - 对于每个word，尝试所有位置i
 * - 不能break（需要处理所有位置）
 * - 更符合标准完全背包模板
 * 
 * 两种方式在逻辑上等价，但：
 * - 方式1可能更高效（可以提前break）
 * - 方式2更符合标准完全背包模板
 */

