class Solution {
public:
    int maxSubArray(vector<int>& nums) {
	    int n = nums.size();
	    if (n == 0) return 0;
	    int dp[n];
	    dp[0] = nums[0];
	    int max = dp[0];
	    for (int i = 1; i < n; i++) {
		    dp[i] = std::max(nums[i], dp[i - 1] + nums[i]); 
		    max = std::max(max, dp[i]);
	    }
	    return max;
    }

	int maxSubArray2(vector<int>& nums) {
        
        int n = nums.size();
        if (n == 1) {
            return nums[0];
        }
        int preSum = 0;
        int preSumMin = 0;
        int max = INT_MIN; //INT_MIN
        for (int i = 0; i < n; i++) {
            preSumMin = min(preSumMin, preSum);
            preSum += nums[i];
            max = std::max(max, preSum - preSumMin);
        }
        max = std::max(max, preSum - preSumMin);
        return max;
    }
};