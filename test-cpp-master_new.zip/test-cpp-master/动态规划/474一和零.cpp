#include <vector>
#include <string>
#include <algorithm>
using namespace std;

/**
 * LeetCode 474: 一和零
 * 找到最大子集的大小，使得子集中最多有m个0和n个1。
 * 
 * 二维0-1背包问题：
 * - 容量有两个维度：0的个数和1的个数
 * - 物品：每个字符串
 * - 价值：每个字符串的价值都是1（计数）
 */
class Solution {
public:
    int findMaxForm(vector<string>& strs, int m, int n) {
        // dp[i][j]: 最多i个0和j个1时，最大子集大小
        vector<vector<int>> dp(m + 1, vector<int>(n + 1, 0));
        
        for (const string& str : strs) {
            // 统计当前字符串的0和1的个数
            int zeros = 0, ones = 0;
            for (char c : str) {
                if (c == '0') zeros++;
                else ones++;
            }
            
            // 从后往前遍历，避免重复使用（0-1背包特征）
            for (int i = m; i >= zeros; i--) {
                for (int j = n; j >= ones; j--) {
                    dp[i][j] = max(dp[i][j], dp[i - zeros][j - ones] + 1);
                    // 不选当前字符串    选当前字符串
                }
            }
        }
        
        return dp[m][n];
    }
};

