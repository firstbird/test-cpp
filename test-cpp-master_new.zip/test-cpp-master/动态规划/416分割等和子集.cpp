#include <vector>
#include <numeric>
using namespace std;

/**
 * LeetCode 416: 分割等和子集
 * 判断数组是否可以被分割成两个子集，使得两个子集的元素和相等。
 * 
 * 转换为0-1背包问题：
 * - 容量：sum / 2
 * - 物品：数组中的每个数
 * - 价值：等于重量（只关心能否装满）
 */
class Solution {
public:
    bool canPartition(vector<int>& nums) {
        int sum = accumulate(nums.begin(), nums.end(), 0);
        
        // 如果和是奇数，无法分割
        if (sum % 2 != 0) {
            return false;
        }
        
        int target = sum / 2;
        int n = nums.size();
        
        // 一维DP：dp[j]表示能否用当前已处理的物品装满容量j
        // 这是二维DP的空间优化版本：
        // 二维DP: dp[i][j] = 前i个物品，容量j
        // 一维DP: dp[j] = 容量j（i在外层循环中隐式处理）
        vector<bool> dp(target + 1, false);
        dp[0] = true;  // 容量0总是可以装满（不选任何物品）
        
        for (int i = 0; i < n; i++) {  // i是物品索引（隐式的维度）
            // 从后往前遍历，避免重复使用（0-1背包特征）
            for (int j = target; j >= nums[i]; j--) {  // j是容量
                // dp[j] = dp[j] || dp[j - nums[i]]
                // 等价于二维DP: dp[i][j] = dp[i-1][j] || dp[i-1][j-nums[i]]
                dp[j] = dp[j] || dp[j - nums[i]];
                // 不选nums[i]    选nums[i]
            }
        }
        
        return dp[target];
    }
};

