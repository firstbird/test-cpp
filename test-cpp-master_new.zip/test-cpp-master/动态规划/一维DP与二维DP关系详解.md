# 一维DP与二维DP关系详解

## 问题

在背包问题的代码中，我们使用了一维DP：
```cpp
vector<bool> dp(target + 1, false);
for (int i = 0; i < n; i++) {
    for (int j = target; j >= nums[i]; j--) {
        dp[j] = dp[j] || dp[j - nums[i]];
    }
}
```

但是注释中提到了"前i个物品"，而代码中只有`dp[j]`，没有显式的`i`维度。这是怎么回事？

## 答案：空间优化

### 一维DP是二维DP的空间优化版本

**二维DP的原始定义：**
```cpp
// dp[i][j]: 前i个物品，容量为j时的状态
vector<vector<bool>> dp(n + 1, vector<bool>(target + 1, false));
dp[0][0] = true;

for (int i = 1; i <= n; i++) {
    for (int j = 0; j <= target; j++) {
        dp[i][j] = dp[i-1][j] || dp[i-1][j-nums[i-1]];
    }
}
```

**一维DP的空间优化：**
```cpp
// dp[j]: 容量为j时的状态（i在外层循环中隐式处理）
vector<bool> dp(target + 1, false);
dp[0] = true;

for (int i = 0; i < n; i++) {  // i是隐式的维度
    for (int j = target; j >= nums[i]; j--) {
        dp[j] = dp[j] || dp[j - nums[i]];
    }
}
```

## 关键理解

### 1. i是隐式的

在一维DP中，**i维度并没有消失，而是通过外层循环隐式处理**：

```cpp
for (int i = 0; i < n; i++) {  // ← 这里的i就是隐式的维度
    for (int j = target; j >= nums[i]; j--) {
        dp[j] = ...;  // 这里的dp[j]实际上对应dp[i][j]
    }
}
```

**对应关系：**
- 外层循环的`i` = 二维DP的`i`（物品索引）
- `dp[j]` = 二维DP的`dp[i][j]`（当前处理到第i个物品时，容量j的状态）

### 2. 为什么可以优化？

**观察二维DP的状态转移：**
```cpp
dp[i][j] = dp[i-1][j] || dp[i-1][j-nums[i-1]]
```

**关键发现：**
- `dp[i][j]`只依赖于`dp[i-1][...]`（上一行的值）
- 不需要保存所有行的值，只需要保存上一行的值
- 可以用一维数组滚动更新

### 3. 从后往前遍历的原因

**0-1背包必须从后往前：**

```cpp
// 错误：从前往后（会重复使用）
for (int j = nums[i]; j <= target; j++) {
    dp[j] = dp[j] || dp[j - nums[i]];
    // 此时dp[j-nums[i]]可能是当前轮更新的值！
}

// 正确：从后往前（使用上一轮的值）
for (int j = target; j >= nums[i]; j--) {
    dp[j] = dp[j] || dp[j - nums[i]];
    // 此时dp[j-nums[i]]一定是上一轮的值
}
```

**为什么？**

假设`nums[i] = 3`，`target = 5`：

```
从前往后遍历（错误）：
  j=3: dp[3] = dp[3] || dp[0]  ← dp[0]是初始值
  j=4: dp[4] = dp[4] || dp[1]  ← dp[1]是初始值
  j=5: dp[5] = dp[5] || dp[2]  ← dp[2]是初始值
  j=6: dp[6] = dp[6] || dp[3]  ← dp[3]是当前轮更新的值！❌

从后往前遍历（正确）：
  j=5: dp[5] = dp[5] || dp[2]  ← dp[2]是上一轮的值 ✅
  j=4: dp[4] = dp[4] || dp[1]  ← dp[1]是上一轮的值 ✅
  j=3: dp[3] = dp[3] || dp[0]  ← dp[0]是初始值 ✅
```

## 完整对比

### 二维DP版本（416题）

```cpp
bool canPartition(vector<int>& nums) {
    int sum = accumulate(nums.begin(), nums.end(), 0);
    if (sum % 2 != 0) return false;
    
    int target = sum / 2;
    int n = nums.size();
    
    // 二维DP: dp[i][j] = 前i个物品，容量j
    vector<vector<bool>> dp(n + 1, vector<bool>(target + 1, false));
    dp[0][0] = true;
    
    for (int i = 1; i <= n; i++) {
        for (int j = 0; j <= target; j++) {
            // 不选第i个物品
            dp[i][j] = dp[i-1][j];
            // 选第i个物品
            if (j >= nums[i-1]) {
                dp[i][j] = dp[i][j] || dp[i-1][j - nums[i-1]];
            }
        }
    }
    
    return dp[n][target];
}
```

### 一维DP版本（空间优化）

```cpp
bool canPartition(vector<int>& nums) {
    int sum = accumulate(nums.begin(), nums.end(), 0);
    if (sum % 2 != 0) return false;
    
    int target = sum / 2;
    int n = nums.size();
    
    // 一维DP: dp[j] = 容量j（i在外层循环中隐式处理）
    vector<bool> dp(target + 1, false);
    dp[0] = true;
    
    for (int i = 0; i < n; i++) {  // i是隐式的维度
        for (int j = target; j >= nums[i]; j--) {  // 从后往前
            // dp[j] = dp[j] || dp[j - nums[i]]
            // 等价于: dp[i][j] = dp[i-1][j] || dp[i-1][j-nums[i]]
            dp[j] = dp[j] || dp[j - nums[i]];
        }
    }
    
    return dp[target];
}
```

## 状态对应关系

### 二维DP → 一维DP

| 二维DP | 一维DP | 说明 |
|--------|--------|------|
| `dp[0][j]` | `dp[j]`（初始值） | 没有物品时的状态 |
| `dp[1][j]` | `dp[j]`（第1轮循环后） | 处理第1个物品后的状态 |
| `dp[2][j]` | `dp[j]`（第2轮循环后） | 处理第2个物品后的状态 |
| `dp[i][j]` | `dp[j]`（第i轮循环后） | 处理第i个物品后的状态 |

### 关键点

**在一维DP中：**
- **外层循环的`i`** = 二维DP的`i`（当前处理的物品索引）
- **`dp[j]`在循环开始时** = 二维DP的`dp[i-1][j]`（上一轮的状态）
- **`dp[j]`在循环结束后** = 二维DP的`dp[i][j]`（当前轮的状态）

## 完全背包的区别

### 完全背包：从前往后

```cpp
// 完全背包：从前往后遍历
for (int coin : coins) {
    for (int j = coin; j <= amount; j++) {  // 从前往后
        dp[j] = min(dp[j], dp[j - coin] + 1);
        // 等价于: dp[i][j] = min(dp[i-1][j], dp[i][j-coin] + 1)
        // 注意：dp[i][j-coin]是当前轮的值（因为可以重复使用）
    }
}
```

**为什么从前往后？**
- 完全背包允许重复使用
- `dp[j-coin]`可以是当前轮更新的值
- 从前往后遍历，`dp[j-coin]`在`dp[j]`之前更新，正好是当前轮的值

## 总结

### 回答你的问题

**Q: 这个dp是一维的，哪有i，j？**

**A: i是隐式的！**

- **`i`在外层循环中**：`for (int i = 0; i < n; i++)`
- **`j`在内层循环中**：`for (int j = target; j >= nums[i]; j--)`
- **`dp[j]`实际上对应`dp[i][j]`**：当前处理到第i个物品时，容量j的状态

### 记忆要点

1. **一维DP = 二维DP的空间优化**
2. **i维度在外层循环中隐式处理**
3. **0-1背包：从后往前遍历**（使用上一轮的值）
4. **完全背包：从前往后遍历**（允许使用当前轮的值）

### 理解技巧

**把一维DP想象成二维DP的滚动数组：**
```
第0轮（初始）: dp[j] = dp[0][j]
第1轮（i=0）:  dp[j] = dp[1][j]  ← 用dp[0][j]更新
第2轮（i=1）:  dp[j] = dp[2][j]  ← 用dp[1][j]更新
...
第i轮:        dp[j] = dp[i][j]  ← 用dp[i-1][j]更新
```

这就是一维DP和二维DP的关系！🎯

