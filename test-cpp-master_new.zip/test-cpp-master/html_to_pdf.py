#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HTML to PDF converter using weasyprint
"""
import sys
import os

try:
    from weasyprint import HTML, CSS
except ImportError:
    print("错误: 需要安装 weasyprint 库")
    print("请运行: pip3 install weasyprint")
    sys.exit(1)

def html_to_pdf(html_file, pdf_file):
    """Convert HTML file to PDF"""
    # Read HTML file
    with open(html_file, 'r', encoding='utf-8') as f:
        html_content = f.read()
    
    # Add page styling
    css = CSS(string='''
        @page {
            size: A4;
            margin: 2cm;
        }
        body {
            font-family: "PingFang SC", "Microsoft YaHei", "SimSun", Arial, sans-serif;
            line-height: 1.6;
            font-size: 11pt;
        }
        h1 {
            color: #333;
            border-bottom: 2px solid #333;
            padding-bottom: 10px;
            font-size: 20pt;
            margin-top: 0;
        }
        h2 {
            color: #555;
            margin-top: 20px;
            border-bottom: 1px solid #ddd;
            padding-bottom: 5px;
            font-size: 16pt;
        }
        h3 {
            color: #666;
            margin-top: 15px;
            font-size: 13pt;
        }
        h4 {
            color: #777;
            font-size: 11pt;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            margin: 15px 0;
            font-size: 10pt;
            display: table;
        }
        tr {
            display: table-row;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 6px;
            text-align: left;
            vertical-align: middle;
            display: table-cell;
        }
        td[valign="center"], td[style*="vertical-align: middle"] {
            vertical-align: middle !important;
        }
        td[valign="top"], td[style*="vertical-align: top"] {
            vertical-align: top !important;
        }
        td[valign="bottom"], td[style*="vertical-align: bottom"] {
            vertical-align: bottom !important;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        ul, ol {
            margin: 8px 0;
            padding-left: 25px;
        }
        li {
            margin: 3px 0;
        }
        hr {
            border: none;
            border-top: 1px solid #ddd;
            margin: 15px 0;
        }
        p {
            margin: 8px 0;
        }
    ''')
    
    # Convert HTML to PDF
    HTML(string=html_content).write_pdf(pdf_file, stylesheets=[css])
    print(f"成功将 {html_file} 转换为 {pdf_file}")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("用法: python3 html_to_pdf.py <input.html> <output.pdf>")
        sys.exit(1)
    
    html_file = sys.argv[1]
    pdf_file = sys.argv[2]
    
    if not os.path.exists(html_file):
        print(f"错误: 文件 {html_file} 不存在")
        sys.exit(1)
    
    try:
        html_to_pdf(html_file, pdf_file)
    except Exception as e:
        print(f"错误: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

