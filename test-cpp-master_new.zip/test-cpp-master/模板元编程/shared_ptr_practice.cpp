#include <mutex>
#include <iostream>

template <typename T>
class SP {
public:
    SP(): _mtx(nullptr), _obj(nullptr), _refCount(nullptr) {}
    SP(T* obj) {
        if (obj) {
            _obj = obj;
            _refCount = new size_t(1);
            _mtx = new std::mutex();
        }
    }
    ~SP() {
        release();
    }
    SP(const SP& input) {
        _obj = input._obj;
        _mtx = input._mtx;
        _refCount = input._refCount;

        if (_refCount) {
            std::lock_guard<std::mutex> lck(*_mtx);
            (*_refCount)++;
        }
    }

    SP(SP&& input) {
        _obj = input._obj;
        _mtx = input._mtx;
        _refCount = input._refCount;

        input._obj = nullptr;
        input._mtx = nullptr;
        input._refCount = nullptr;
    }


    SP& operator=(const SP& input) {
        if (this == &input) {
            return *this;
        }
        release();
        _obj = input._obj;
        _mtx = input._mtx;
        _refCount = input._refCount;
        if (_refCount) {
            std::lock_guard<std::mutex> lck(*_mtx);
            (*_refCount)++;
        }
        return *this;
    }

    SP& operator=(SP&& input) {
        if (this == &input) {
            return *this;
        }
        release();
        _obj = input._obj;
        _mtx = input._mtx;
        _refCount = input._refCount;
        input._obj = nullptr;
        input._mtx = nullptr;
        input._refCount = nullptr;
        return *this;
    }

    T& operator*() {
        if (!_obj) {
            throw std::runtime_error("nullptr");
        }
        return *_obj;
    }

    T* operator->() {
        return _obj;
    }

    T* get() {
        return _obj;
    }

    bool is_empty() {
        return _obj == nullptr;
    }

    size_t use_count() {
        if (!_refCount) {
            throw std::runtime_error("nullptr");
        }
        std::lock_guard<std::mutex> lck(*_mtx);
        return *_refCount; 
    }    

private:
    void release() {
        if (_refCount) {
            std::lock_guard<std::mutex> lck(*_mtx);
            if (*_refCount > 0) {
                (*_refCount)--;
            }
            if (*_refCount == 0) {
                delete _obj;
                delete _mtx;
                delete _refCount;
            }
        }
        _obj = nullptr;
        _mtx = nullptr;
        _refCount = nullptr;
    }

    std::mutex* _mtx;
    size_t* _refCount;
    T* _obj;
};

int main() {
    // 普通构造
    SP<int> sp1(new int(2));
    std::cout << "test1: "<<sp1.use_count() << std::endl;

    // 拷贝构造
    SP<int> sp2 = sp1;
    std::cout << "test2-1: "<< sp1.use_count() << std::endl;
    std::cout << "test2-2: "<< sp2.use_count() << std::endl;

    // 移动构造
    SP<int> sp3 = std::move(sp2);
    std::cout << "test3-1: "<< sp3.use_count() << std::endl;

    // 拷贝赋值 
    SP<int> sp4(new int(4));
    sp4 = sp3;
    std::cout << "test4-1: "<< sp4.use_count() << std::endl;

    SP<int> sp5(new int(5));
    sp5 = std::move(sp4); 
    std::cout << "test5-1: "<< sp5.use_count() << std::endl;
}
