#include <iostream>
#include <mutex>  // 用于线程安全的引用计数操作
#include <utility> // 用于std::move

// 模板实现简易shared_ptr
template <typename T>
class SharedPtr {
public:
    // 1. 空构造函数
    SharedPtr() : _ptr(nullptr), _ref_count(nullptr), _mtx(nullptr) {}

    // 2. 普通指针构造函数
    // 你想了解 C++ 中explicit关键字的使用场景和核心作用，这是 C++ 中避免隐式类型转换陷阱的关键语法，尤其在类的构造函数和转换运算符中常用。
// 先明确核心作用
// explicit关键字的核心目的是禁止编译器进行隐式的类型转换，只允许显式的类型转换（手动写转换代码），从而避免意外的隐式转换导致的逻辑错误或性能问题。

// 智能指针就是用来保存裸指针的
    explicit SharedPtr(T* ptr) : _ptr(ptr) {
        // 为引用计数和互斥锁分配内存（多个SharedPtr共享）
        if (_ptr) {
            _ref_count = new size_t(1);
            _mtx = new std::mutex();
        } else {
            _ref_count = nullptr;
            _mtx = nullptr;
        }
    }

    // 3. 拷贝构造函数（核心：增加引用计数）
    SharedPtr(const SharedPtr& other) {
        // 共享对方的资源
        _ptr = other._ptr;
        _ref_count = other._ref_count;
        _mtx = other._mtx;

        // 线程安全地增加引用计数
        if (_ref_count) {
            std::lock_guard<std::mutex> lock(*_mtx);
            (*_ref_count)++;
        }
    }

    // 4. 移动构造函数（核心：转移所有权，不增加计数）
    SharedPtr(SharedPtr&& other) noexcept {
        // 接管对方的资源
        _ptr = other._ptr;
        _ref_count = other._ref_count;
        _mtx = other._mtx;

        // 将对方置空，避免析构时释放资源
        other._ptr = nullptr;
        other._ref_count = nullptr;
        other._mtx = nullptr;
    }

    // 5. 拷贝赋值运算符
    SharedPtr& operator=(const SharedPtr& other) {
        // 防止自赋值
        if (this == &other) {
            return *this;
        }

        // 第一步：释放当前持有的资源（计数-1，为0则销毁）
        release();

        // 第二步：共享对方的资源，计数+1
        _ptr = other._ptr;
        _ref_count = other._ref_count;
        _mtx = other._mtx;
        if (_ref_count) {
            std::lock_guard<std::mutex> lock(*_mtx);
            (*_ref_count)++;
        }

        return *this;
    }

    // 6. 移动赋值运算符
    SharedPtr& operator=(SharedPtr&& other) noexcept {
        // 防止自赋值
        if (this == &other) {
            return *this;
        }

        // 释放当前资源
        release();

        // 接管对方资源
        _ptr = other._ptr;
        _ref_count = other._ref_count;
        _mtx = other._mtx;

        // 对方置空
        other._ptr = nullptr;
        other._ref_count = nullptr;
        other._mtx = nullptr;

        return *this;
    }

    // 7. 析构函数（核心：释放资源）
    ~SharedPtr() {
        release();
    }

    // 8. 解引用运算符（*）
    T& operator*() const {
        if (!_ptr) {
            throw std::runtime_error("SharedPtr: dereference null pointer");
        }
        return *_ptr;
    }

    // 9. 成员访问运算符（->）
    T* operator->() const {
        if (!_ptr) {
            throw std::runtime_error("SharedPtr: access member of null pointer");
        }
        return _ptr;
    }

    // 10. 获取原始指针
    T* get() const {
        return _ptr;
    }

    // 11. 获取当前引用计数
    size_t use_count() const {
        if (!_ref_count) {
            return 0;
        }
        std::lock_guard<std::mutex> lock(*_mtx);
        return *_ref_count;
    }

    // 12. 判断是否为空
    explicit operator bool() const {
        return _ptr != nullptr;
    }

private:
    // 核心：释放当前资源（计数-1，为0则销毁）
    void release() {
        if (_ref_count) {
            std::lock_guard<std::mutex> lock(*_mtx);
            (*_ref_count)--;
            // 引用计数为0时，销毁资源和计数/锁
            if (*_ref_count == 0) {
                delete _ptr;        // 释放管理的资源
                delete _ref_count;  // 释放计数
                delete _mtx;        // 释放互斥锁
            }
        }
        // 置空当前指针
        _ptr = nullptr;
        _ref_count = nullptr;
        _mtx = nullptr;
    }

    T* _ptr;               // 指向管理的资源
    size_t* _ref_count;    // 共享的引用计数（堆内存，多个SharedPtr共享）
    std::mutex* _mtx;      // 线程安全的互斥锁（保护引用计数操作）
};

// 3. std::forward 的工作原理
// std::forward 是一个条件转换函数：它根据模板参数 T 的类型，将参数转换为【相应的引用类型】。

// 如果 T 是左值引用类型，std::forward<T>(arg) 返回【左值引用】（即 arg 作为左值）。

// 如果 T 是右值引用类型或非引用类型，std::forward<T>(arg) 返回【右值引用】 （即 arg 作为右值）。
// 辅助函数：创建SharedPtr（类似std::make_shared）

// template <typename T>
// void wrapper(T&& arg) {
    // process(std::forward<T>(arg)); // 自动选拷贝/移动
// }


template <typename T, typename... Args>
SharedPtr<T> make_shared(Args&&... args) {
    return SharedPtr<T>(new T(std::forward<Args>(args)...));
}

template <typename T> 
void wrapper(T&& arg) {
    process(std::forward<T>(arg));
}



// 测试代码
int main() {
    // 测试1：基本构造和引用计数
    SharedPtr<int> p1(new int(10));
    std::cout << "p1 use count: " << p1.use_count() << std::endl; // 输出1
    std::cout << "*p1: " << *p1 << std::endl; // 输出10

    // 测试2：拷贝构造
    SharedPtr<int> p2 = p1;
    std::cout << "p1 use count after copy: " << p1.use_count() << std::endl; // 输出2
    std::cout << "p2 use count: " << p2.use_count() << std::endl; // 输出2

    // 测试3：移动构造
    SharedPtr<int> p3 = std::move(p2);
    std::cout << "p2 use count after move: " << p2.use_count() << std::endl; // 输出0
    std::cout << "p3 use count: " << p3.use_count() << std::endl; // 输出2

    // 测试4：make_shared
    SharedPtr<std::string> p4 = make_shared<std::string>("hello shared_ptr");
    std::cout << "*p4: " << *p4 << std::endl; // 输出hello shared_ptr

    // 测试5：空指针判断
    SharedPtr<int> p5;
    if (!p5) {
        std::cout << "p5 is null" << std::endl;
    }

    return 0;
}