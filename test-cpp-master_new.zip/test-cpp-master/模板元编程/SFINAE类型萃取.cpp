#include <iostream>
#include <type_traits>
#include <vector>
#include <list>
using namespace std;

/**
 * SFINAE (Substitution Failure Is Not An Error) 示例
 * 类型萃取和模板特化
 */

// 1. 检查类型是否有size()方法
template<typename T>
class has_size_method {
private:
    template<typename U>
    static auto test(int) -> decltype(std::declval<U>().size(), std::true_type{});
    
    template<typename>
    static std::false_type test(...);
    
public:
    static constexpr bool value = decltype(test<T>(0))::value;
};

// 2. 检查类型是否可迭代
template<typename T>
class is_iterable {
private:
    template<typename U>
    static auto test(int) -> decltype(
        std::begin(std::declval<U&>()) != std::end(std::declval<U&>()),
        ++std::declval<decltype(std::begin(std::declval<U&>()))&>(),
        *std::begin(std::declval<U&>()),
        std::true_type{}
    );
    
    template<typename>
    static std::false_type test(...);
    
public:
    static constexpr bool value = decltype(test<T>(0))::value;
};

// 3. 使用SFINAE的函数重载
template<typename T>
typename enable_if<has_size_method<T>::value, void>::type
print_size(const T& container) {
    cout << "Container size: " << container.size() << endl;
}

template<typename T>
typename enable_if<!has_size_method<T>::value, void>::type
print_size(const T&) {
    cout << "Type does not have size() method" << endl;
}

// 4. 类型萃取：移除引用和const
template<typename T>
struct remove_cvref {
    using type = remove_cv_t<remove_reference_t<T>>;
};

template<typename T>
using remove_cvref_t = typename remove_cvref<T>::type;

// 5. 检查是否为指针类型
template<typename T>
struct is_pointer_helper : false_type {};

template<typename T>
struct is_pointer_helper<T*> : true_type {};

template<typename T>
struct is_pointer : is_pointer_helper<remove_cvref_t<T>> {};

// 6. 使用concepts (C++20) 的等价实现（注释形式）
/*
template<typename T>
concept HasSize = requires(T t) {
    t.size();
};

template<HasSize T>
void print_size_cpp20(const T& container) {
    cout << "Container size: " << container.size() << endl;
}
*/

int main() {
    vector<int> vec = {1, 2, 3};
    list<int> lst = {4, 5, 6};
    int arr[] = {7, 8, 9};
    int num = 10;
    
    cout << "=== SFINAE Type Traits ===" << endl;
    
    cout << "\nhas_size_method:" << endl;
    cout << "vector<int>: " << has_size_method<vector<int>>::value << endl;
    cout << "list<int>: " << has_size_method<list<int>>::value << endl;
    cout << "int: " << has_size_method<int>::value << endl;
    
    cout << "\nis_iterable:" << endl;
    cout << "vector<int>: " << is_iterable<vector<int>>::value << endl;
    cout << "int[]: " << is_iterable<decltype(arr)>::value << endl;
    cout << "int: " << is_iterable<int>::value << endl;
    
    cout << "\nprint_size function:" << endl;
    print_size(vec);
    print_size(lst);
    print_size(num);
    
    cout << "\nis_pointer:" << endl;
    cout << "int*: " << is_pointer<int*>::value << endl;
    cout << "const int*: " << is_pointer<const int*>::value << endl;
    cout << "int: " << is_pointer<int>::value << endl;
    
    return 0;
}

