#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Simple Markdown to PDF converter using reportlab
"""
import sys
import os
import re
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

# Try to register Chinese fonts
try:
    # Try common Chinese fonts on macOS
    font_paths = [
        '/System/Library/Fonts/PingFang.ttc',
        '/System/Library/Fonts/STHeiti Light.ttc',
        '/System/Library/Fonts/Helvetica.ttc',
    ]
    chinese_font_registered = False
    for font_path in font_paths:
        if os.path.exists(font_path):
            try:
                pdfmetrics.registerFont(TTFont('ChineseFont', font_path))
                chinese_font_registered = True
                break
            except:
                continue
except:
    chinese_font_registered = False

def parse_markdown(md_content):
    """Simple markdown parser"""
    lines = md_content.split('\n')
    elements = []
    current_list = []
    in_table = False
    table_data = []
    table_headers = []
    
    for line in lines:
        line = line.strip()
        
        # Headers
        if line.startswith('# '):
            elements.append(('h1', line[2:]))
        elif line.startswith('## '):
            elements.append(('h2', line[3:]))
        elif line.startswith('### '):
            elements.append(('h3', line[4:]))
        elif line.startswith('#### '):
            elements.append(('h4', line[5:]))
        # Horizontal rule
        elif line.startswith('---'):
            elements.append(('hr',))
        # Table
        elif '|' in line and not line.startswith('|---'):
            if not in_table:
                in_table = True
                table_data = []
            cells = [cell.strip() for cell in line.split('|')[1:-1]]
            if not table_headers:
                table_headers = cells
            else:
                table_data.append(cells)
        elif in_table and '|' not in line:
            if table_data:
                elements.append(('table', table_headers, table_data))
                table_headers = []
                table_data = []
            in_table = False
        # List items
        elif line.startswith('- '):
            current_list.append(line[2:])
        # Regular paragraph
        elif line:
            if current_list:
                elements.append(('ul', current_list))
                current_list = []
            elements.append(('p', line))
        # Empty line
        else:
            if current_list:
                elements.append(('ul', current_list))
                current_list = []
    
    if current_list:
        elements.append(('ul', current_list))
    if table_data:
        elements.append(('table', table_headers, table_data))
    
    return elements

def markdown_to_pdf(md_file, pdf_file):
    """Convert markdown file to PDF"""
    # Read markdown file
    with open(md_file, 'r', encoding='utf-8') as f:
        md_content = f.read()
    
    # Parse markdown
    elements = parse_markdown(md_content)
    
    # Create PDF
    doc = SimpleDocTemplate(pdf_file, pagesize=A4,
                           rightMargin=72, leftMargin=72,
                           topMargin=72, bottomMargin=18)
    
    # Styles
    styles = getSampleStyleSheet()
    
    # Custom styles
    if chinese_font_registered:
        h1_style = ParagraphStyle('CustomH1', parent=styles['Heading1'],
                                 fontName='ChineseFont', fontSize=24, spaceAfter=12)
        h2_style = ParagraphStyle('CustomH2', parent=styles['Heading2'],
                                 fontName='ChineseFont', fontSize=18, spaceAfter=10)
        h3_style = ParagraphStyle('CustomH3', parent=styles['Heading3'],
                                 fontName='ChineseFont', fontSize=14, spaceAfter=8)
        h4_style = ParagraphStyle('CustomH4', parent=styles['Heading4'],
                                 fontName='ChineseFont', fontSize=12, spaceAfter=6)
        p_style = ParagraphStyle('CustomP', parent=styles['Normal'],
                                fontName='ChineseFont', fontSize=10, spaceAfter=6)
    else:
        h1_style = styles['Heading1']
        h2_style = styles['Heading2']
        h3_style = styles['Heading3']
        h4_style = styles['Heading4']
        p_style = styles['Normal']
    
    # Build story
    story = []
    
    for elem_type, *args in elements:
        if elem_type == 'h1':
            story.append(Paragraph(args[0], h1_style))
            story.append(Spacer(1, 0.2*inch))
        elif elem_type == 'h2':
            story.append(Spacer(1, 0.1*inch))
            story.append(Paragraph(args[0], h2_style))
            story.append(Spacer(1, 0.1*inch))
        elif elem_type == 'h3':
            story.append(Spacer(1, 0.05*inch))
            story.append(Paragraph(args[0], h3_style))
            story.append(Spacer(1, 0.05*inch))
        elif elem_type == 'h4':
            story.append(Paragraph(args[0], h4_style))
            story.append(Spacer(1, 0.03*inch))
        elif elem_type == 'p':
            # Handle bold text
            text = args[0].replace('**', '<b>').replace('**', '</b>')
            text = text.replace('*', '<i>').replace('*', '</i>')
            story.append(Paragraph(text, p_style))
        elif elem_type == 'ul':
            for item in args[0]:
                # Handle bold text
                item_text = item.replace('**', '<b>').replace('**', '</b>')
                story.append(Paragraph('• ' + item_text, p_style))
            story.append(Spacer(1, 0.05*inch))
        elif elem_type == 'table':
            headers, data = args[0], args[1]
            table_data = [headers] + data
            table = Table(table_data)
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            story.append(table)
            story.append(Spacer(1, 0.1*inch))
        elif elem_type == 'hr':
            story.append(Spacer(1, 0.1*inch))
    
    # Build PDF
    doc.build(story)
    print(f"成功将 {md_file} 转换为 {pdf_file}")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("用法: python3 md_to_pdf_simple.py <input.md> <output.pdf>")
        sys.exit(1)
    
    md_file = sys.argv[1]
    pdf_file = sys.argv[2]
    
    if not os.path.exists(md_file):
        print(f"错误: 文件 {md_file} 不存在")
        sys.exit(1)
    
    try:
        markdown_to_pdf(md_file, pdf_file)
    except ImportError as e:
        print(f"错误: 需要安装 reportlab 库")
        print("请运行: pip3 install reportlab")
        sys.exit(1)
    except Exception as e:
        print(f"错误: {e}")
        sys.exit(1)

