#include <vector>
#include <algorithm>
using namespace std;

/**
 * LeetCode 307: 区域和检索 - 数组可修改
 * 给你一个数组 nums ，请你完成两类查询。
 * 1. 更新数组下标对应的值
 * 2. 查询数组中 [left, right] 范围内元素的总和
 * 
 * 使用线段树实现，支持O(log n)的更新和查询
 */
class SegmentTree {
private:
    vector<int> tree_;
    int n_;
    
    void build(const vector<int>& nums, int node, int start, int end) {
        if (start == end) {
            tree_[node] = nums[start];
        } else {
            int mid = (start + end) / 2;
            int leftNode = 2 * node + 1;
            int rightNode = 2 * node + 2;
            
            build(nums, leftNode, start, mid);
            build(nums, rightNode, mid + 1, end);
            
            tree_[node] = tree_[leftNode] + tree_[rightNode];
        }
    }
    
    void update(int node, int start, int end, int index, int val) {
        if (start == end) {
            tree_[node] = val;
        } else {
            int mid = (start + end) / 2;
            int leftNode = 2 * node + 1;
            int rightNode = 2 * node + 2;
            
            if (index <= mid) {
                update(leftNode, start, mid, index, val);
            } else {
                update(rightNode, mid + 1, end, index, val);
            }
            
            tree_[node] = tree_[leftNode] + tree_[rightNode];
        }
    }
    
    int query(int node, int start, int end, int left, int right) {
        if (right < start || left > end) {
            return 0;
        }
        
        if (left <= start && end <= right) {
            return tree_[node];
        }
        
        int mid = (start + end) / 2;
        int leftNode = 2 * node + 1;
        int rightNode = 2 * node + 2;
        
        return query(leftNode, start, mid, left, right) +
               query(rightNode, mid + 1, end, left, right);
    }
    
public:
    SegmentTree(const vector<int>& nums) : n_(nums.size()) {
        tree_.resize(4 * n_);
        build(nums, 0, 0, n_ - 1);
    }
    
    void update(int index, int val) {
        update(0, 0, n_ - 1, index, val);
    }
    
    int sumRange(int left, int right) {
        return query(0, 0, n_ - 1, left, right);
    }
};

class NumArray {
private:
    SegmentTree segTree_;
    
public:
    NumArray(vector<int>& nums) : segTree_(nums) {}
    
    void update(int index, int val) {
        segTree_.update(index, val);
    }
    
    int sumRange(int left, int right) {
        return segTree_.sumRange(left, right);
    }
};

