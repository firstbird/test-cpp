<div style="text-align: center;">
<div style="font-size: 18pt; font-weight: bold;">Zhenli Ma</div>
<div style="margin-top: 10px;">+86 188 1784 6273 丨mzlzjhz@163.com 丨Shanghai, China</div>
</div>

**Target Role**: (Sr/Staff) C++ Software Engineer, Infotainment

## **Professional Experience**

### **Xiaomi Group**

**Low-level System Development | Xiaomi XRING**  
*Nov 2023 – Present*

- **Secure & Protected `dma-heap`**: Implemented secure/protected `dma-heap` based on the `dma-buf` framework for ISP and DRM use cases; optimized memory allocation with a CMA pool.
- **Display memory optimization**: Designed a dedicated `dma-heap` for DRM display and ISP scenarios; optimized contiguous physical memory allocation paths via CMA to reduce display framebuffer allocation latency. Led performance initiatives around DMA-BUF and cache, resolving GPU/NPU memory-related bottlenecks and improving rendering/display efficiency.
- **Memory governance service**: Designed and developed a system-level memory management/governance service and integrated it with HyperOS. Built tailored memory policies for high-frame-rate scenarios (camera, gaming) to ensure display pipeline allocations and reduce frame drops/stutters under memory pressure.
- **Secure memory project (Owner)**: Owned end-to-end secure memory solution design and delivery. Deployed security services in TEE to provide controlled memory access for secure media applications, enabling security isolation for multimedia pipelines.

### **Banma Network Technology Co., Ltd.**

**AliOS In-Vehicle OS Development | Banma Zhixing**  
*Mar 2022 – Sep 2023*

- **Graphics rendering service**: Developed backend Render Server; implemented cloud rendering for IDE preview based on OpenGL ES.
- **IVI system services**: Built a mode management service to coordinate multi-modal state management and switching within the in-vehicle system.
- **Innovation features**: Delivered eye-tracking control, dynamic desktop and other features leveraging AliOS capabilities, involving image recognition and real-time rendering.

### **Huawei Technologies Co., Ltd.**

**System UI Components Development | Huawei Consumer BG**  
*Aug 2019 – Feb 2022*

- **In-house graphics system**: Contributed to HarmonyOS core graphics stack (SurfaceFlinger/HWUI) development and optimization; deep experience in View drawing pipeline and rendering flow. Served as **Owner** of list components, addressing cross-device consistency and performance (phone/tablet/watch) and supporting major apps such as JD and Weibo.
- **Android UI components**: Developed EMUI framework/SDK UI components and animations to enhance system-level interaction experience.

**Network Services Development | Packet Core Network**  
*Aug 2015 – Jun 2019*

- **5G microservices platform components**: Built distributed network service control components on Docker using Golang and the Actor model; responsible for distributed service lifecycle management.
- **NFV load balancer**: Implemented an NFV load balancer; delivered packet forwarding control and traffic scheduling strategies.

---

## **Skills**

- **Languages**: Proficient in C++, Java; experience in HarmonyOS, Android, and in-vehicle OS development
- **Graphics**: OpenGL ES; graphics/rendering development experience
- **Android**: Android Framework, UI component development
- **Kernel/Systems**: Linux kernel development; `dma-buf` and memory management
- **English**: CET-6

---

## **Education**

| School | Dates | Major | Degree |
| --- | --- | --- | --- |
| Tongji University | Sep 2012 – Jun 2015 | Software Engineering | M.S. |
| Anhui Jianzhu University | Sep 2008 – Jun 2012 | Automation | B.S. |

