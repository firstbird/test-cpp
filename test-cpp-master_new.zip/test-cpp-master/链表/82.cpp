#include <iostream>
#include <vector>
#include <algorithm>
#include <unordered_map>
#include <set>
#include <queue>
#include <stack>
#include <string>
#include <map>
#include <unordered_set>
#include <unordered_map>
/**
 * Definition for singly-linked list.
 * struct ListNode {
 *     int val;
 *     ListNode *next;
 *     ListNode() : val(0), next(nullptr) {}
 *     ListNode(int x) : val(x), next(nullptr) {}
 *     ListNode(int x, ListNode *next) : val(x), next(next) {}
 * };
 */
struct ListNode {
    int val;
    ListNode *next;
    ListNode() : val(0), next(nullptr) {}
    ListNode(int x) : val(x), next(nullptr) {}
    ListNode(int x, ListNode *next) : val(x), next(next) {}
};
class Solution {
    public:
        ListNode* deleteDuplicates(ListNode* head) {
            if(head==nullptr||head->next==nullptr) return head;
            ListNode* dummy=new ListNode(0);
            dummy->next=head;
            // pre是可信链表的末尾节点
            ListNode* pre=dummy;
            ListNode* p=head;
            while(p!=nullptr&&p->next!=nullptr){
                if(p->val==p->next->val){
                    // p一直跟下一个比较，不相等时停止
                    while(p!=nullptr&&p->next!=nullptr&&p->val==p->next->val) {
                        p=p->next;
                    }
                    // 【暂时】连接新的p，下次还是遇到新的重复还是可以改的
                    pre->next=p->next;
                    p=p->next;
                }
                else {
                    pre=p;
                    p=p->next;
                }
            }
            return dummy->next;
        }
    };