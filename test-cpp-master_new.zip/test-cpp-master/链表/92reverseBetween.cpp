#include <vector>
#include <algorithm>

class Solution {
public:
 struct ListNode {
     int val;
     ListNode *next;
     ListNode() : val(0), next(nullptr) {}
     ListNode(int x) : val(x), next(nullptr) {}
     ListNode(int x, ListNode *next) : val(x), next(next) {}
 };
    ListNode* reverseBetween(ListNode* head, int left, int right) {
	    ListNode dummy;
	    dummy.next = head;
	    ListNode *p = &dummy;
	    ListNode *pre;
	    ListNode *post;
	    ListNode *rightNode;
	    ListNode *leftNode;
	    int lc = left - 1; // 表示前一个节点的步数
	    while (lc > 0) {// 这个表示从dummy走lc步到达left的前一个节点
		    p = p->next;
		    --lc;
	    }
	    pre = p;
	    int rc = right - left + 1;
	    while (rc > 0) {
		    p = p->next;
		    --rc;
	    }
		// 先得到pre：从dummy走left -1步 
		// pre -> leftNode 
		// p == rightNode -> post
	    leftNode = pre->next;
	    rightNode = p; // 从pre走rc步就是right node
	    post = rightNode->next;

	    pre->next = nullptr; // 切割
	    rightNode->next = nullptr; // 切割

	    reverseMid(leftNode); // 反转中间部分

	    pre->next = rightNode; // 连接反转后的第一个节点
	    leftNode->next = post; // 连接后续节点
	    return dummy.next;
    }
	void reverseMid(ListNode* head) {
		ListNode* p = head;
		ListNode *pre = nullptr;
		while (p != nullptr)
		{
			ListNode *next = p->next;// 先保存next
			p->next = pre;
			pre = p;
			p = next;
		}
		
	}

	ListNode* reverseBetween2(ListNode* head, int left, int right) {
        if (!head || left == right) return head;  // 边界情况
        
        ListNode dummy(0);  // ✓ 栈对象，自动管理内存
        dummy.next = head;
        
        ListNode* pre = nullptr;
        ListNode* p = head;
        ListNode* first = nullptr;
        ListNode* second = nullptr;
        std::vector<ListNode*> numbers;
        
        int pos = 1;
        while (p) {
            if (pos >= left && pos <= right) {  // ✓ 统一处理区间
                numbers.push_back(p);  // ✓ 使用push_back
                if (pos == left) {
                    first = pre ? pre : &dummy;
                }
                if (pos == right) {
                    second = p->next;
                    break;  // ✓ 找到right后立即退出
                }
            }
            pre = p;
            p = p->next;
            pos++;
        }
        
        // 反转vector
        std::reverse(numbers.begin(), numbers.end());
        
        // 连接节点
        first->next = numbers[0];
        for (int i = 0; i < numbers.size() - 1; i++) {
            numbers[i]->next = numbers[i + 1];
        }
        numbers.back()->next = second;
        
        return dummy.next;
    }
private:

};