 struct ListNode {
      int val;
      ListNode *next;
      ListNode() : val(0), next(nullptr) {}
      ListNode(int x) : val(x), next(nullptr) {}
      ListNode(int x, ListNode *next) : val(x), next(next) {}
};

class Solution {
public:
    ListNode* addTwoNumbers(ListNode* l1, ListNode* l2) {
	    ListNode dummy(0);
	    ListNode *p1 = l1;
	    ListNode *p2 = l2;
	    ListNode *p = &dummy;
	    int carry = 0;
	    while (p1 != nullptr || p2 != nullptr)
	    {
		    int v1 = p1 != nullptr ? p1->val : 0;
		    int v2 = p2 != nullptr ? p2->val : 0;
		    int val = (v1 + v2 + carry) % 10;
		    carry = (v1 + v2 + carry) / 10;
		    p->next = new ListNode(val);
		    p = p->next;
		    if (p1 != nullptr)
			    p1 = p1->next;
		    if (p2 != nullptr)
			    p2 = p2->next;
	    }
	    if (carry != 0) {
		    p->next = new ListNode(carry);
	    }
	    return dummy.next;
    }

    // 另一种实现：先同时遍历两个链表，再分别遍历剩余的单独链表
    ListNode* addTwoNumbers2(ListNode* l1, ListNode* l2) {
        ListNode dummy(0);
        ListNode* p = &dummy;
        ListNode* p1 = l1;
        ListNode* p2 = l2;
        int carry = 0;

        // 1. 两个链表都不为空时，同时遍历
        while (p1 != nullptr && p2 != nullptr) {
            int sum = p1->val + p2->val + carry;
            int val = sum % 10;
            carry = sum / 10;

            p->next = new ListNode(val);
            p = p->next;

            p1 = p1->next;
            p2 = p2->next;
        }

        // 2. 只剩下 l1 的部分
        while (p1 != nullptr) {
            int sum = p1->val + carry;
            int val = sum % 10;
            carry = sum / 10;

            p->next = new ListNode(val);
            p = p->next;

            p1 = p1->next;
        }

        // 3. 只剩下 l2 的部分
        while (p2 != nullptr) {
            int sum = p2->val + carry;
            int val = sum % 10;
            carry = sum / 10;

            p->next = new ListNode(val);
            p = p->next;

            p2 = p2->next;
        }

        // 4. 最后还有进位
        if (carry != 0) {
            p->next = new ListNode(carry);
        }

        return dummy.next;
    }
};