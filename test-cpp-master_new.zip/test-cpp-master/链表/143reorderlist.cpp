
#include <unordered_map>

using namespace std;
class Solution {
public:
 struct ListNode {
     int val;
      ListNode *next;
      ListNode() : val(0), next(nullptr) {}
      ListNode(int x) : val(x), next(nullptr) {}
      ListNode(int x, ListNode *next) : val(x), next(next) {}
 };

    unordered_map<ListNode *, ListNode *> map;

    void reorderList(ListNode *head)
    {
	    if (head == nullptr)
		    return;
	    ListNode *p = head;
	    ListNode *pre = nullptr;
	    int count = 0;
	    while (p != nullptr) {
	            map[p] = pre;
		    pre = p;
		    p = p->next;
		    count++;
	    }
	    count /= 2;
	    p = head;
	    ListNode* q = pre;
	    while (count > 0)
	    {
		    ListNode* next = p->next;
		    p->next = q;
		    q->next = next;
		    q = map[q];
            p = next;
		    count--;
	    }
        if (p != nullptr) {
            p->next = nullptr;
        }
	    return;
    }

private:
    static ListNode* reverseList(ListNode* head) {
        ListNode* prev = nullptr;
        while (head != nullptr) {
            ListNode* next = head->next;
            head->next = prev;
            prev = head;
            head = next;
        }
        return prev;
    }

public:
    // 新增实现：O(1) 额外空间（找中点 + 反转后半段 + 交替合并）
    void reorderListO1(ListNode* head) {
        if (head == nullptr || head->next == nullptr) {
            return;
        }

        // 1) 找中点（slow 停在前半段尾）
        ListNode* slow = head;
        ListNode* fast = head;
        while (fast->next != nullptr && fast->next->next != nullptr) {
            slow = slow->next;
            fast = fast->next->next;
        }

        // 2) 反转后半段
        ListNode* second = slow->next;
        slow->next = nullptr;
        second = reverseList(second);

        // 3) 交替合并
        // ListNode* first = head;
		ListNode* p1 = head;
        ListNode* p2 = second;
        while (p2 != nullptr) {
			ListNode* next1 = p1->next;
			ListNode* next2 = p2->next;
			p1->next = p2;
			p2->next = next1;
			p1 = next1;
			p2 = next2;
            // ListNode* t1 = first->next;
            // ListNode* t2 = second->next;

            // first->next = second;
            // second->next = t1;

            // first = t1;
            // second = t2;
        }
    }
};