# priority_queue 详解：大顶堆 vs 小顶堆

## 问题

1. `priority_queue<int>` 默认是大顶堆吗？
2. 小顶堆怎么写？

## 答案

### 1. 默认是大顶堆

```cpp
priority_queue<int> queue;  // 默认是大顶堆（最大元素在顶部）
```

**默认行为：**
- 使用 `less<int>` 比较器
- 最大元素在顶部（`top()` 返回最大值）
- 等价于：`priority_queue<int, vector<int>, less<int>>`

### 2. 小顶堆的写法

```cpp
priority_queue<int, vector<int>, greater<int>> queue;  // 小顶堆（最小元素在顶部）
```

## 详细说明

### 二叉堆实现原理（底层是数组堆）

`std::priority_queue` 的核心思想是：用一个支持随机访问的底层容器（默认 `vector`）存储元素，然后把它当作**完全二叉树**来维护堆序性质。

以 `vector<T> heap` 下标从 `0` 开始表示完全二叉树：

- 父节点：`parent = (i - 1) / 2`
- 左孩子：`left = 2 * i + 1`
- 右孩子：`right = 2 * i + 2`

维护堆序的两种基本操作：

1. `push(x)`：
   - 把 `x` 追加到数组末尾（此时堆序可能被破坏）
   - 通过“上滤 siftUp”不断与父节点比较并交换，直到满足堆序
2. `pop()`：
   - 用最后一个元素替换堆顶（此时堆序可能被破坏）
   - 通过“下滤 siftDown”不断与更优先的孩子比较并交换，直到满足堆序

复杂度：
- `top()`：O(1)（直接访问堆顶 `heap[0]`）
- `push/pop()`：O(logN)（上滤/下滤最多走树高）

堆序不变量（由比较器 `Compare` 决定）：
- 设父节点为 `p`、子节点为 `c`，始终满足：`!Compare(heap[p], heap[c])`
- 以默认 `Compare=less` 为例，就是保证最大堆性质：`heap[p] >= heap[c]`

极简伪代码（以 `Compare=less` 的“最大堆”为直观理解）：
```text
siftUp(i):
  while i > 0:
    p = (i - 1) / 2
    if heap[p] >= heap[i]: break
    swap(heap[p], heap[i])
    i = p

siftDown(i):
  while 有孩子:
    选择更优先级的孩子 best
    if heap[i] >= heap[best]: break
    swap(heap[i], heap[best])
    i = best
```

> 说明：`priority_queue` 只保证“堆顶最好”，不保证数组整体有序。

### priority_queue 的模板参数

```cpp
template<
    class T,                                    // 元素类型
    class Container = vector<T>,                // 底层容器（默认vector）
    class Compare = less<typename Container::value_type>  // 比较器（默认less，大顶堆）
>
class priority_queue;
```

### 大顶堆（默认）

```cpp
// 方式1：使用默认参数（大顶堆）
priority_queue<int> maxHeap;

// 方式2：显式指定（大顶堆）
priority_queue<int, vector<int>, less<int>> maxHeap;

// 使用示例
maxHeap.push(3);
maxHeap.push(1);
maxHeap.push(4);
maxHeap.push(2);

cout << maxHeap.top();  // 输出：4（最大值）
```

### 小顶堆

```cpp
// 小顶堆：使用 greater<int> 比较器
priority_queue<int, vector<int>, greater<int>> minHeap;

// 使用示例
minHeap.push(3);
minHeap.push(1);
minHeap.push(4);
minHeap.push(2);

cout << minHeap.top();  // 输出：1（最小值）
```

## 比较器说明

### less<T>（大顶堆）

```cpp
less<int>  // 比较函数：a < b
// 如果 a < b，返回 true
// 大顶堆：较大的元素优先级更高（在顶部）
```

### greater<T>（小顶堆）

```cpp
greater<int>  // 比较函数：a > b
// 如果 a > b，返回 true
// 小顶堆：较小的元素优先级更高（在顶部）
```

## 完整示例

### 示例1：大顶堆

```cpp
#include <queue>
#include <iostream>
using namespace std;

int main() {
    // 大顶堆（默认）
    priority_queue<int> maxHeap;
    
    maxHeap.push(3);
    maxHeap.push(1);
    maxHeap.push(4);
    maxHeap.push(2);
    
    while (!maxHeap.empty()) {
        cout << maxHeap.top() << " ";  // 4 3 2 1
        maxHeap.pop();
    }
    return 0;
}
```

### 示例2：小顶堆

```cpp
#include <queue>
#include <iostream>
using namespace std;

int main() {
    // 小顶堆
    priority_queue<int, vector<int>, greater<int>> minHeap;
    
    minHeap.push(3);
    minHeap.push(1);
    minHeap.push(4);
    minHeap.push(2);
    
    while (!minHeap.empty()) {
        cout << minHeap.top() << " ";  // 1 2 3 4
        minHeap.pop();
    }
    return 0;
}
```

## 在40题中的应用

### 当前代码（大顶堆）

```cpp
priority_queue<int> queue;  // 大顶堆
for (int i = 0; i < arr.size(); i++) {
    queue.push(arr[i]);
    if (queue.size() > k) {
        queue.pop();  // 弹出最大值
    }
}
// 最后堆中保留最小的k个数
```

**为什么用大顶堆？**
- 维护 k 个最小元素
- 当堆大小超过 k 时，弹出最大值
- 最后堆中保留的就是最小的 k 个数

### 如果用小顶堆（不推荐）

```cpp
priority_queue<int, vector<int>, greater<int>> queue;  // 小顶堆
// 这样不行！因为我们需要弹出最大值，而不是最小值
```

**为什么不行？**
- 小顶堆的顶部是最小值
- 我们需要弹出最大值来保持堆大小为 k
- 所以必须用大顶堆

## 常见应用场景

### 大顶堆（默认）

1. **找最大的k个数**
   ```cpp
   priority_queue<int> maxHeap;  // 大顶堆
   ```

2. **维护最小的k个数**（如40题）
   ```cpp
   priority_queue<int> maxHeap;  // 大顶堆，弹出最大值
   ```

### 小顶堆

1. **找最小的k个数**
   ```cpp
   priority_queue<int, vector<int>, greater<int>> minHeap;  // 小顶堆
   ```

2. **维护最大的k个数**
   ```cpp
   priority_queue<int, vector<int>, greater<int>> minHeap;  // 小顶堆，弹出最小值
   ```

## 记忆要点

### 默认行为

- `priority_queue<int>` = 大顶堆（最大元素在顶部）
- 等价于：`priority_queue<int, vector<int>, less<int>>`

### 小顶堆写法

- `priority_queue<int, vector<int>, greater<int>>` = 小顶堆（最小元素在顶部）

### 选择原则

- **需要弹出最大值** → 用大顶堆
- **需要弹出最小值** → 用小顶堆

## 总结

1. **默认是大顶堆**：`priority_queue<int>` 默认使用 `less<int>`，最大元素在顶部
2. **小顶堆写法**：`priority_queue<int, vector<int>, greater<int>>`
3. **40题用大顶堆**：因为需要弹出最大值来保持堆大小为 k

这就是 priority_queue 的完整说明！🎯

