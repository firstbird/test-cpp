/**
 * LeetCode 剑指 Offer 40. 最小的k个数
 * 输入整数数组 arr，找出其中最小的 k 个数。
 * 
 * 方法：使用大顶堆（priority_queue）
 * - 维护一个大小为k的大顶堆
 * - 遍历数组，当堆大小超过k时，弹出最大值
 * - 最后堆中保留的就是最小的k个数
 */
class Solution {
public:
    vector<int> getLeastNumbers(vector<int>& arr, int k) {
	    vector<int> res;
	    if (k == 0) {
		    return res;
	    }
		//priority_queue<int, vector<int>, less<int>>
	    // priority_queue<int, vector<int>, greater<int>>
		// 大顶堆（默认）：priority_queue<int> 等价于 priority_queue<int, vector<int>, less<int>>
	    // 为什么用大顶堆？因为需要弹出最大值来保持堆大小为k
	    priority_queue<int> queue;  // 默认是大顶堆
	    for (int i = 0; i < arr.size(); i++) {
		    queue.push(arr[i]);
		    if (queue.size() > k) {
			    queue.pop();
		    }
	    }
	    int i = 0;
	    while (queue.size() != 0) {
		    res.push_back(queue.top());
            	    queue.pop();
	    }
	    return res;
    }
};