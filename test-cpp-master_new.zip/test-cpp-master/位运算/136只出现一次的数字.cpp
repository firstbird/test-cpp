#include <vector>
using namespace std;

/**
 * LeetCode 136: 只出现一次的数字
 * 给定一个非空整数数组，除了某个元素只出现一次以外，其余每个元素均出现两次。
 * 找出那个只出现了一次的元素。
 * 
 * 要求：时间复杂度O(n)，空间复杂度O(1)
 */
class Solution {
public:
    int singleNumber(vector<int>& nums) {
        int result = 0;
        // 利用异或的性质：a ^ a = 0, a ^ 0 = a
        // 所有数字异或后，出现两次的数字会抵消，只剩下出现一次的数字
        for (int num : nums) {
            result ^= num;
        }
        return result;
    }
};

