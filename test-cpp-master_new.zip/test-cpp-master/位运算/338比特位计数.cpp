#include <vector>
using namespace std;

/**
 * LeetCode 338: 比特位计数
 * 给你一个整数 n ，对于 0 <= i <= n 中的每个 i ，
 * 计算其二进制表示中 1 的个数 ，返回一个长度为 n + 1 的数组 ans 作为答案。
 */
class Solution {
public:
    // 方法1: 动态规划 + 最低有效位
    // dp[i] = dp[i >> 1] + (i & 1)
    vector<int> countBits(int n) {
        vector<int> dp(n + 1, 0);
        for (int i = 1; i <= n; i++) {
            dp[i] = dp[i >> 1] + (i & 1);
        }
        return dp;
    }
    
    // 方法2: 动态规划 + 最低设置位
    // dp[i] = dp[i & (i-1)] + 1
    vector<int> countBits2(int n) {
        vector<int> dp(n + 1, 0);
        for (int i = 1; i <= n; i++) {
            dp[i] = dp[i & (i - 1)] + 1;
        }
        return dp;
    }
};

