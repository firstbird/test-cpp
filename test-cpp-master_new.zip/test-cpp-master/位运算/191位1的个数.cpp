#include <cstdint>
using namespace std;

/**
 * LeetCode 191: 位1的个数
 * 编写一个函数，输入是一个无符号整数（以二进制串的形式），
 * 返回其二进制表达式中数字位数为 '1' 的个数（也被称为汉明重量）。
 */
class Solution {
public:
    // 方法1: 逐位检查
    int hammingWeight(uint32_t n) {
        int count = 0;
        while (n) {
            count += (n & 1);
            n >>= 1;
        }
        return count;
    }
    
    // 方法2: 利用 n & (n-1) 消除最低位的1
    int hammingWeight2(uint32_t n) {
        int count = 0;
        while (n) {
            n &= (n - 1); // 消除最低位的1
            count++;
        }
        return count;
    }
    
    // 方法3: 内置函数
    int hammingWeight3(uint32_t n) {
        return __builtin_popcount(n);
    }
};

