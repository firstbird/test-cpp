#include <vector>
#include <unordered_map>
using namespace std;

/**
 * LeetCode 560: 和为 K 的子数组
 * 给你一个整数数组 nums 和一个整数 k ，请你统计并返回该数组中和为 k 的连续子数组的个数。
 * 
 * 使用前缀和 + 哈希表优化
 */
class Solution {
public:
    int subarraySum(vector<int>& nums, int k) {
        unordered_map<int, int> prefixSum; // 前缀和 -> 出现次数
        prefixSum[0] = 1; // 前缀和为0出现1次（空子数组）
        
        int sum = 0;
        int count = 0;
        
        for (int num : nums) {
            sum += num; // 当前前缀和
            
            // 如果存在前缀和 sum - k，说明存在子数组和为k
            // 因为 sum - (sum - k) = k
            if (prefixSum.find(sum - k) != prefixSum.end()) {
                count += prefixSum[sum - k];
            }
            
            prefixSum[sum]++;
        }
        
        return count;
    }
};

