#include <vector>
using namespace std;

/**
 * LeetCode 370: 区间加法（会员题）
 * 假设你有一个长度为 n 的数组，初始情况下所有的数字均为 0。
 * 你将会被给出 k 个更新的操作。
 * 其中，每个操作会被表示为一个三元组：[startIndex, endIndex, inc]。
 * 你需要将子数组 A[startIndex ... endIndex]（包括 startIndex 和 endIndex）增加 inc。
 * 
 * 使用差分数组优化，将区间更新从O(n)优化到O(1)
 */
class Solution {
public:
    vector<int> getModifiedArray(int length, vector<vector<int>>& updates) {
        // 差分数组：diff[i] = arr[i] - arr[i-1]
        // 对区间[l, r]加val，只需要 diff[l] += val, diff[r+1] -= val
        vector<int> diff(length + 1, 0);
        
        for (auto& update : updates) {
            int start = update[0];
            int end = update[1];
            int inc = update[2];
            
            diff[start] += inc;
            if (end + 1 < length) {
                diff[end + 1] -= inc;
            }
        }
        
        // 通过差分数组还原原数组
        vector<int> result(length);
        result[0] = diff[0];
        for (int i = 1; i < length; i++) {
            result[i] = result[i - 1] + diff[i];
        }
        
        return result;
    }
};

