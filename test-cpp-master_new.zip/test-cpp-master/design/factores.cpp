#include <memory>
#include <string>

class Shape {
public:
    virtual ~Shape() = default;
    virtual void draw() const = 0;
};

class Circle : public Shape {
public:
    void draw() const override {}
};

class Rectangle : public Shape {
public:
    void draw() const override {}
};

// 简单工厂：集中 new，内部用分支/映射决定具体类
class ShapeFactory {
public:
    static std::unique_ptr<Shape> create(const std::string& type) {
        if (type == "circle")    return std::make_unique<Circle>();
        if (type == "rectangle") return std::make_unique<Rectangle>();
        return nullptr;
    }
};

// 使用
// auto s = ShapeFactory::create("circle");

#include <memory>
#include <string>

class IButton {
public:
    virtual ~IButton() = default;
    virtual std::string label() const = 0;
};

class IDialog {
public:
    virtual ~IDialog() = default;
    virtual std::string title() const = 0;
};

// Windows 族
class WinButton : public IButton {
public:
    std::string label() const override { return "Win OK"; }
};
class WinDialog : public IDialog {
public:
    std::string title() const override { return "Win Dialog"; }
};

// Mac 族
class MacButton : public IButton {
public:
    std::string label() const override { return "Mac OK"; }
};
class MacDialog : public IDialog {
public:
    std::string title() const override { return "Mac Dialog"; }
};

// 抽象工厂：声明「这一族」里要造哪些配套类型
class IUIFactory {
public:
    virtual ~IUIFactory() = default;
    virtual std::unique_ptr<IButton> createButton() = 0;
    virtual std::unique_ptr<IDialog> createDialog() = 0;
};

class WinUIFactory : public IUIFactory {
public:
    std::unique_ptr<IButton> createButton() override {
        return std::make_unique<WinButton>();
    }
    std::unique_ptr<IDialog> createDialog() override {
        return std::make_unique<WinDialog>();
    }
};

class MacUIFactory : public IUIFactory {
public:
    std::unique_ptr<IButton> createButton() override {
        return std::make_unique<MacButton>();
    }
    std::unique_ptr<IDialog> createDialog() override {
        return std::make_unique<MacDialog>();
    }
};

// 客户端只依赖抽象工厂 + 抽象产品；换主题 = 换具体工厂
void buildScreen(IUIFactory& f) {
    auto btn = f.createButton();
    auto dlg = f.createDialog();
    (void)btn;
    (void)dlg;
}