#include<iostream>
 
using namespace std;
 
#define DELETE(pointer) delete pointer; pointer=nullptr
 
class IProduct //抽象产品
{
public:
	IProduct() {}
	virtual ~IProduct() {}
 
	virtual void show() = 0;
};
 
class ProductA : public IProduct //具体产品A
{
public:
	ProductA() {}
	~ProductA() {}
 
	virtual void show() { cout << "ProductA" << endl; }
};
 
class ProductB : public IProduct //具体产品B
{
public:
	ProductB() {}
	~ProductB() {}
 
	virtual void show() { cout << "ProductB" << endl; }
};
 
class IFactory //抽象工厂
{
public:
	IFactory() {}
	virtual ~IFactory() {}
 
	virtual IProduct* createProduct() = 0;
};
 
class FactoryA : public IFactory //具体工厂
{
public:
	FactoryA() {}
	virtual ~FactoryA() {}
 
	IProduct* createProduct() override{	
		return new ProductA;
	}
};
 
class FactoryB : public IFactory //具体工厂
{
public:
	FactoryB() {}
	virtual ~FactoryB() {}
 
	IProduct* createProduct() override{	return new ProductB;}
};
 
void doFactoryMethod()
{
	// 工厂方法：一个工厂只创建一种产品
	IFactory *factory = new FactoryA();
	IProduct *product = factory->createProduct();
	product->show();
	DELETE(product);
	DELETE(factory);

	factory = new FactoryB();
	product = factory->createProduct();
	product->show();
	DELETE(product);
	DELETE(factory);
}

// ========== 抽象工厂：创建一族相关产品 ==========

class IButton {
public:
	virtual ~IButton() {}
	virtual void render() = 0;
};

class ITextField {
public:
	virtual ~ITextField() {}
	virtual void render() = 0;
};

class ButtonA : public IButton {
public:
	void render() override { cout << "ButtonA render" << endl; }
};

class TextFieldA : public ITextField {
public:
	void render() override { cout << "TextFieldA render" << endl; }
};

class ButtonB : public IButton {
public:
	void render() override { cout << "ButtonB render" << endl; }
};

class TextFieldB : public ITextField {
public:
	void render() override { cout << "TextFieldB render" << endl; }
};

// 抽象工厂：一次创建一族产品（Button + TextField）
class IUIFactory {
public:
	virtual ~IUIFactory() {}
	virtual IButton* createButton() = 0;
	virtual ITextField* createTextField() = 0;
};

class UIFactoryA : public IUIFactory {
public:
	IButton* createButton() override { return new ButtonA; }
	ITextField* createTextField() override { return new TextFieldA; }
};

class UIFactoryB : public IUIFactory {
public:
	IButton* createButton() override { return new ButtonB; }
	ITextField* createTextField() override { return new TextFieldB; }
};

void doAbstractFactory()
{
	// 抽象工厂：一个工厂创建一整套风格一致的产品
	IUIFactory* factory = new UIFactoryA();
	IButton* btn = factory->createButton();
	ITextField* txt = factory->createTextField();
	btn->render();
	txt->render();
	DELETE(btn);
	DELETE(txt);
	DELETE(factory);

	factory = new UIFactoryB();
	btn = factory->createButton();
	txt = factory->createTextField();
	btn->render();
	txt->render();
	DELETE(btn);
	DELETE(txt);
	DELETE(factory);
}

int main()
{
	cout << "=== Factory Method ===" << endl;
	doFactoryMethod();
	cout << "\n=== Abstract Factory ===" << endl;
	doAbstractFactory();
	return 0;
}