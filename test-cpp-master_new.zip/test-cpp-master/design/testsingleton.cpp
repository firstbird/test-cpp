#include <mutex>

using namespace std;
class Singleton {
public:
	static Singleton& getInstance() {
		static Singleton s;
		return s;
	}
private:
	Singleton() = default;
	~Singleton() = default;
	Singleton(const Singleton&) = delete;
	Singleton(Singleton&&) = delete;
	Singleton &operator=(const Singleton&) = delete;
	Singleton &operator=(Singleton&&) = delete;


};

class Singleton {
public:
	Singleton* getInstance() {
		if (!_instance) {
			mu.lock();
			if (!_instance) {
				_instance = new Singleton();
			}
			mu.unlock();
		}
		return _instance;
	}	
private:
	Singleton() {}	

	Singleton *_instance;
	mutex mu;
};
