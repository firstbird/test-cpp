#include <iostream>
using namespace std;

int main() {
    cout << "Hello, C++ in VSCode!" << endl;
    return 0;
}