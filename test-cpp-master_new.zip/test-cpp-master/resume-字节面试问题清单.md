# 字节豆包「高级 Android Framework」— 结合简历的四面问题清单

> 依据：`resume.md`（马振立）+ 豆包 JD（AMS/WMS/View/PMS/Input/SurfaceFlinger + Java/C++）  
> 用法：每面挑 **10～15 个** 做口头演练；**加粗**为与你简历强相关、极易被追问的点。

---

## 一面（基础 / 简历深挖，约 45～60 分钟）

### 通用
- 自我介绍（**控制在 2～3 分钟**，突出：华为鸿蒙 UI + 小米底层，为何投 Framework）
- 为什么从「内核/dma」转回 / 并行投 **Android Framework**？职业规划是什么？
- **Java**：HashMap 原理、并发（synchronized/volatile）、线程池使用场景
- **Android 基础**：Activity 生命周期、启动模式、进程优先级
- 可能 **1～2 道简单算法**（数组/哈希/双指针）

### 紧扣简历
- **华为·鸿蒙列表控件 owner**：你负责的「列表」具体是哪个组件？和 Android RecyclerView/ListContainer 差异？遇到过最难的适配问题？
- **京东/微博上架**：你解决过的 **具体问题** 各举 1 例（崩溃、性能、多设备）
- **EMUI**：自定义控件 + 数据绑定动效，**技术栈**（Java/Kotlin？）和 **性能** 怎么保证？
- **斑马·IDE render server / 云渲染**：架构是什么？和 Android Surface/图形管线有什么关系？
- **斑马·车机模式管理**：多模态状态机怎么设计？和 Activity 栈/系统服务如何类比？
- **小米·dma-heap / dma-buf**：一句话解释 dma-buf 是什么；**和 Android GraphicBuffer/Surface 的关系**（你要能桥接到 SF）
- **小米最近偏内核**：面试官可能问：**你投 Framework，最近两年在芯片侧，如何补 Android？**（提前准备 30 秒话术）

---

## 二面（Framework / 图形深度，约 60 分钟）

### JD 硬指标（AMS / WMS / View / SF / Binder）
- Activity **冷启动**完整链路（Launcher → AMS → Zygote → Application → Activity）
- `startActivity` 到 **窗口显示** 与 WMS、Surface、SF 的关系
- **View**：measure/layout/draw；`requestLayout` vs `invalidate`；硬件加速开关的影响
- **事件分发**：down 链路、拦截、多点、与 WMS 焦点窗口
- **SurfaceFlinger**：Layer、BufferQueue、Vsync、HWC 各干什么（和你 OpenGL 经验结合）
- **Binder**：一次跨进程调用、Parcel、Binder 线程池（可结合你熟悉 native 的优势）
- **PMS**（若问）：安装流程、签名、多用户（点到即可）

### 紧扣简历（你的差异化）
- **鸿蒙 Java UI vs Android View**：列表滑动、复用、动画，你迁移到 Android 会怎么对比讲？
- **OpenGL ES + 斑马 render server**：FBO、纹理、同步；若问到 **SurfaceTexture / EGLSurface**，能否举例？
- **dma-buf / CMA / cache 优化**：  
  - 映射慢你怎么优化的？**和 Android ION/dma-buf heap** 是否了解？  
  - **GraphicBuffer 分配路径** 能否和内核 heap 对上（至少概念层）
- **TEE 安全内存**：和 **普通 ashmem/匿名映射** 区别？为何媒体要走安全内存？
- **内存管控 + Hyper OS**：策略依据是什么（PSS、压力、场景）？和 **LMK / AMS** 有什么异同（概念即可）

### 编码（可能出现）
- 中等难度 1 题，或 **手写关键路径伪代码**（如 LRU、链表）

---

## 三面（场景 / 架构 / 压力，约 60 分钟）

### 复杂场景与稳定性
- 线上 **ANR**：如何定位（trace、主线程、输入超时）？你作为 Framework 视角会查哪些服务？
- **黑屏/闪屏/花屏**：从 View → Surface → SF → HWC 怎么分层排查？
- **多窗口/分屏/旋转**：Activity 与 Window 生命周期如何交织？
- **内存**：大图、Bitmap、native 内存泄漏；和你 **dma / 映射** 经验如何结合讲「全链路内存观」

### 项目深挖（必问简历）
- **选一个你做 owner 的项目**（建议：**鸿蒙列表** 或 **小米安全内存/dma 优化**）：  
  - 背景 → 你的职责 → 方案对比 → **量化结果**（耗时降低 %、crash 率等）
- **为什么离开华为/斑马/选择小米**：话术要 **正向、不踩前司**
- **协作**：与 PM、业务 App、驱动、TEE 团队冲突怎么解决？
- **技术债**：若让你重构车机模式管理或列表框架，你会怎么做？

### 行为与动机
- 为什么选 **字节 / 豆包**？对「助手」产品在系统层有什么理解（悬浮窗、前后台、权限）？
- 能接受的工作强度与节奏（诚实即可）

---

## 四面（HR / 综合，约 45～60 分钟）

- 离职原因、薪资期望、职级预期、到岗时间
- 长期职业规划（**走 Framework 专家** vs **图形+系统** 复合）
- 有无其他 offer、比较维度
- 反问：团队业务、技术栈、当前系统难点、培养方式

---

## 你简历上的「风险点」与应对话术（重要）

| 风险 | 面试官心理 | 建议应对 |
|------|------------|----------|
| 最近 2 年偏 **芯片/内核** | 是否还能写 App/Framework？ | 强调 **华为 3 年鸿蒙/EMUI UI 框架** + 平时保持 Android 源码阅读；小米工作 **与图形 buffer、显示强相关**，和 SF/图形天然衔接 |
| 岗位写 **Android**，你鸿蒙多 | 是否匹配？ | **声明式 UI 与 Android View 体系差异**能说清；强调 **控件/列表/性能/多设备** 经验可迁移 |
| 斑马偏 **车载** | 是否了解手机生态？ | 车机也是 Android/AOSP 变种；**系统服务、多模态、渲染** 可映射到 Framework |

---

## 建议的「主叙事」一句话（面试开场可用）

> 「我前期在华为做 **鸿蒙 Java UI 框架与列表控件**，对 View 体系、性能与三方适配很深；后来在斑马做 **渲染与车机系统服务**；当前在小米做 **dma-buf/显示与安全内存**，从内核到用户态链路比较完整。希望回到 **Android Framework 与图形栈**，把列表/渲染与 buffer 经验用在助手类产品上。」

---

## 每面自检清单（开面前 5 分钟过一遍）

- [ ] 一面：2 个项目 STAR + 离职/动机 30 秒  
- [ ] 二面：2 条长链路（启动到显示、触摸到 View）+ 1 个 dma/Surface 桥接点  
- [ ] 三面：1 个最难项目 + 1 个失败与复盘  
- [ ] 四面：薪资区间与底线、反问 2 个  

如需把本清单 **合并进 `resume.md`** 或改成 **一页纸打印版**，可以说一下我帮你排版。
