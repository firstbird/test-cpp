#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Markdown to DOCX converter
"""
import sys
import os
import re

try:
    from docx import Document
    from docx.shared import Pt, Inches, RGBColor
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml.ns import qn
except ImportError:
    print("错误: 需要安装 python-docx 库")
    print("请运行: pip3 install python-docx")
    sys.exit(1)

def parse_markdown(md_file):
    """Parse markdown file into structured content"""
    with open(md_file, 'r', encoding='utf-8') as f:
        content_text = f.read()
    
    content = []
    current_paragraph = []
    in_list = False
    in_table = False
    in_html_table = False
    html_table_rows = []
    table_rows = []
    
    lines = content_text.split('\n')
    
    for line in lines:
        line = line.rstrip()
        
        # HTML table detection
        if '<table' in line:
            in_html_table = True
            html_table_rows = []
            continue
        elif '</table>' in line:
            if html_table_rows:
                content.append(('html_table', html_table_rows))
            in_html_table = False
            html_table_rows = []
            continue
        elif in_html_table:
            if '<tr>' in line or line.strip().startswith('<tr'):
                html_table_rows.append([])
            elif '<td' in line:
                # Extract all content from td tag (may span multiple lines)
                td_match = re.search(r'<td[^>]*>(.*?)</td>', line, re.DOTALL)
                if td_match:
                    cell_content = td_match.group(1)
                    # Keep the HTML structure for processing
                    if html_table_rows:
                        html_table_rows[-1].append(cell_content)
            continue
        
        # Headers
        if line.startswith('# '):
            if current_paragraph:
                content.append(('p', '\n'.join(current_paragraph)))
                current_paragraph = []
            content.append(('h1', line[2:]))
        elif line.startswith('## '):
            if current_paragraph:
                content.append(('p', '\n'.join(current_paragraph)))
                current_paragraph = []
            content.append(('h2', line[3:]))
        elif line.startswith('### '):
            if current_paragraph:
                content.append(('p', '\n'.join(current_paragraph)))
                current_paragraph = []
            content.append(('h3', line[4:]))
        elif line.startswith('#### '):
            if current_paragraph:
                content.append(('p', '\n'.join(current_paragraph)))
                current_paragraph = []
            content.append(('h4', line[5:]))
        # Horizontal rule
        elif line.startswith('---'):
            if current_paragraph:
                content.append(('p', '\n'.join(current_paragraph)))
                current_paragraph = []
            content.append(('hr',))
        # Table
        elif '|' in line:
            if not in_table:
                in_table = True
                table_rows = []
            if not line.strip().startswith('|---'):
                cells = [cell.strip() for cell in line.split('|')[1:-1]]
                if cells:
                    table_rows.append(cells)
        # List items
        elif line.startswith('- '):
            if in_table:
                content.append(('table', table_rows))
                table_rows = []
                in_table = False
            if current_paragraph:
                content.append(('p', '\n'.join(current_paragraph)))
                current_paragraph = []
            content.append(('li', line[2:]))
        # Empty line
        elif not line:
            if in_table:
                content.append(('table', table_rows))
                table_rows = []
                in_table = False
            if current_paragraph:
                content.append(('p', '\n'.join(current_paragraph)))
                current_paragraph = []
        # Regular text
        else:
            if in_table:
                content.append(('table', table_rows))
                table_rows = []
                in_table = False
            current_paragraph.append(line)
    
    if current_paragraph:
        content.append(('p', '\n'.join(current_paragraph)))
    if table_rows:
        content.append(('table', table_rows))
    
    return content

def add_formatted_text(paragraph, text):
    """Add formatted text to paragraph (handle bold, italic)"""
    # Split by bold markers
    parts = re.split(r'(\*\*.*?\*\*)', text)
    for part in parts:
        if part.startswith('**') and part.endswith('**'):
            # Bold text
            run = paragraph.add_run(part[2:-2])
            run.bold = True
        elif part.startswith('*') and part.endswith('*') and len(part) > 2:
            # Italic text
            run = paragraph.add_run(part[1:-1])
            run.italic = True
        else:
            # Regular text
            paragraph.add_run(part)

def markdown_to_docx(md_file, docx_file):
    """Convert markdown file to DOCX"""
    content = parse_markdown(md_file)
    
    # Create document
    doc = Document()
    
    # Set default font to support Chinese
    style = doc.styles['Normal']
    font = style.font
    font.name = 'PingFang SC'
    font._element.rPr.rFonts.set(qn('w:eastAsia'), 'PingFang SC')
    font.size = Pt(11)
    
    for elem_type, *args in content:
        if elem_type == 'h1':
            p = doc.add_heading(args[0], level=1)
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        elif elem_type == 'h2':
            p = doc.add_heading(args[0], level=2)
        elif elem_type == 'h3':
            p = doc.add_heading(args[0], level=3)
        elif elem_type == 'h4':
            p = doc.add_heading(args[0], level=4)
        elif elem_type == 'p':
            text = args[0]
            if text.strip():
                p = doc.add_paragraph()
                add_formatted_text(p, text)
        elif elem_type == 'li':
            p = doc.add_paragraph(style='List Bullet')
            add_formatted_text(p, args[0])
        elif elem_type == 'table':
            rows = args[0]
            if rows:
                table = doc.add_table(rows=len(rows), cols=len(rows[0]))
                table.style = 'Light Grid Accent 1'
                for i, row in enumerate(rows):
                    for j, cell in enumerate(row):
                        table.rows[i].cells[j].text = cell
                        # Make first row bold
                        if i == 0:
                            for paragraph in table.rows[i].cells[j].paragraphs:
                                for run in paragraph.runs:
                                    run.bold = True
        elif elem_type == 'html_table':
            rows = args[0]
            if rows:
                # Find max columns
                max_cols = max(len(row) for row in rows) if rows else 0
                if max_cols > 0:
                    table = doc.add_table(rows=len(rows), cols=max_cols)
                    # Remove table borders
                    table.style = 'Table Grid'
                    # Remove all borders
                    from docx.oxml import OxmlElement
                    tbl = table._tbl
                    tblBorders = OxmlElement('w:tblBorders')
                    for border_name in ['top', 'left', 'bottom', 'right', 'insideH', 'insideV']:
                        border = OxmlElement(f'w:{border_name}')
                        border.set(qn('w:val'), 'none')
                        border.set(qn('w:sz'), '0')
                        border.set(qn('w:space'), '0')
                        border.set(qn('w:color'), 'auto')
                        tblBorders.append(border)
                    tbl.tblPr.append(tblBorders)
                    
                    for i, row in enumerate(rows):
                        for j in range(max_cols):
                            cell_content = row[j] if j < len(row) else ''
                            cell = table.rows[i].cells[j]
                            # Remove cell padding
                            cell._element.tcPr.append(OxmlElement('w:tcMar'))
                            # Clear default paragraph
                            cell.paragraphs[0].clear()
                            
                            # Extract all divs from cell content
                            divs = re.findall(r'<div[^>]*>(.*?)</div>', cell_content, re.DOTALL)
                            if not divs:
                                # If no divs, use the whole content
                                divs = [cell_content]
                            
                            for div_idx, div_content in enumerate(divs):
                                if div_idx > 0:
                                    p = cell.add_paragraph()
                                else:
                                    p = cell.paragraphs[0]
                                
                                # Check for large font size and bold (姓名) - same size as h2 (18pt)
                                if 'font-size: 18pt' in cell_content or ('font-size: 18pt' in str(div_content) and 'font-weight: bold' in str(div_content)):
                                    # Extract text from div
                                    clean_text = re.sub(r'<[^>]+>', '', div_content).strip()
                                    if clean_text:
                                        run = p.add_run(clean_text)
                                        run.bold = True
                                        run.font.size = Pt(18)
                                else:
                                    # Remove HTML tags and add text
                                    clean_text = re.sub(r'<[^>]+>', '', div_content).strip()
                                    if clean_text:
                                        add_formatted_text(p, clean_text)
                            
                            # Center align for second column (个人信息)
                            if j == 1:  # Second column
                                for paragraph in cell.paragraphs:
                                    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
                            # Right align for third column (头像)
                            elif j == 2:  # Third column
                                for paragraph in cell.paragraphs:
                                    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        elif elem_type == 'hr':
            p = doc.add_paragraph()
            p.add_run('_' * 50)
    
    # Save document
    doc.save(docx_file)
    print(f"成功将 {md_file} 转换为 {docx_file}")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("用法: python3 md_to_docx.py <input.md> <output.docx>")
        sys.exit(1)
    
    md_file = sys.argv[1]
    docx_file = sys.argv[2]
    
    if not os.path.exists(md_file):
        print(f"错误: 文件 {md_file} 不存在")
        sys.exit(1)
    
    try:
        markdown_to_docx(md_file, docx_file)
    except Exception as e:
        print(f"错误: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

