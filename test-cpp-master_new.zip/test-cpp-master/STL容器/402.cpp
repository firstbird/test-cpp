#include <string>
#include <vector>
using namespace std;
/*
这是经典单调栈贪心题（LeetCode 402：移掉 K 位数字），目标是：从数字串 num 中删除 k 个数字，使结果数字最小。
核心思想：维持一个“尽量单调递增”的栈
用 vector<char> stk 当栈，依次处理每一位 digit：
for (auto& digit: num) {    while (stk.size() > 0 && stk.back() > digit && k) {        stk.pop_back();        k -= 1;    }    stk.push_back(digit);}
含义：
遍历每个数字 digit，希望前面的数尽量小。
如果栈顶数字比当前 digit 大，且还能删（k > 0），就把栈顶弹掉：
这等价于“删除一个更高位、更大的数字”，后面用一个更小的 digit 来占位 → 整体数字变小。
持续弹出，直到：
栈空，或者
栈顶 ≤ 当前 digit（再删就不会让数更小），或者
k == 0（不能再删）。
然后把当前 digit 入栈。
这样处理完一遍后，栈中是“在不超过 k 次删除的前提下”字典序（数值）尽可能小的序列。

*/
class Solution {
    public:
        string removeKdigits(string num, int k) {
            vector<char> stk;
            for (auto& digit: num) {
                while (stk.size() > 0 && stk.back() > digit && k) {
                    stk.pop_back();
                    k -= 1;
                }
                stk.push_back(digit);
            }
    
            for (; k > 0; --k) {
                stk.pop_back();
            }
    
            string ans = "";
            // bool isLeadingZero = true;
            int i = 0;
            while (i < stk.size()) {
                if (stk[i] != '0') {
                    break;
                }
                ++i;
            }
            for (int j = i; j < stk.size(); ++j) {
                ans += stk[j];
            }
            return ans == "" ? "0" : ans;
        }
    };