#include <vector>
#include <string>
#include <iostream>
#include <memory>
using namespace std;

/**
 * push_back vs emplace_back 区别详解
 */

class TestClass {
private:
    int value_;
    string name_;
    
public:
    // 构造函数
    TestClass(int v, const string& n) : value_(v), name_(n) {
        cout << "Constructor: " << name_ << " = " << value_ << endl;
    }
    
    // 拷贝构造函数
    TestClass(const TestClass& other) 
        : value_(other.value_), name_(other.name_) {
        cout << "Copy Constructor: " << name_ << " = " << value_ << endl;
    }
    
    // 移动构造函数
    TestClass(TestClass&& other) noexcept 
        : value_(other.value_), name_(move(other.name_)) {
        cout << "Move Constructor: " << name_ << " = " << value_ << endl;
    }
    
    // 拷贝赋值
    TestClass& operator=(const TestClass& other) {
        if (this != &other) {
            value_ = other.value_;
            name_ = other.name_;
            cout << "Copy Assignment: " << name_ << " = " << value_ << endl;
        }
        return *this;
    }
    
    // 移动赋值
    TestClass& operator=(TestClass&& other) noexcept {
        if (this != &other) {
            value_ = other.value_;
            name_ = move(other.name_);
            cout << "Move Assignment: " << name_ << " = " << value_ << endl;
        }
        return *this;
    }
    
    ~TestClass() {
        cout << "Destructor: " << name_ << endl;
    }
    
    int getValue() const { return value_; }
    const string& getName() const { return name_; }
};

int main() {
    cout << "=== push_back vs emplace_back 对比 ===" << endl;
    
    vector<TestClass> vec1, vec2;
    
    // ========== 情况1: 传递临时对象 ==========
    cout << "\n--- 情况1: 传递临时对象 ---" << endl;
    
    cout << "\n1. push_back(临时对象):" << endl;
    vec1.push_back(TestClass(1, "temp1"));
    // 执行过程：
    // 1. 构造临时对象 TestClass(1, "temp1")
    // 2. push_back 调用移动构造函数（C++11）或拷贝构造函数（C++98）
    // 3. 销毁临时对象
    
    cout << "\n2. emplace_back(参数):" << endl;
    vec2.emplace_back(2, "temp2");
    // 执行过程：
    // 1. 直接在vector内存中构造对象，无需临时对象
    // 2. 更高效！
    
    // ========== 情况2: 传递已存在的对象 ==========
    cout << "\n--- 情况2: 传递已存在的对象 ---" << endl;
    
    TestClass obj(3, "existing");
    
    cout << "\n3. push_back(已存在对象):" << endl;
    vec1.push_back(obj);
    // 执行过程：
    // 1. 调用拷贝构造函数
    
    cout << "\n4. push_back(move(已存在对象)):" << endl;
    vec1.push_back(move(obj));
    // 执行过程：
    // 1. 调用移动构造函数
    
    cout << "\n5. emplace_back(已存在对象):" << endl;
    // vec2.emplace_back(obj);  // ❌ 错误！emplace_back需要构造参数，不是对象
    // 正确用法：
    vec2.emplace_back(4, "new_obj");
    
    // ========== 情况3: 复杂对象 ==========
    cout << "\n--- 情况3: 复杂对象（如pair） ---" << endl;
    
    vector<pair<int, string>> vec3;
    
    cout << "\n6. push_back(pair):" << endl;
    vec3.push_back(make_pair(10, "ten"));
    // 执行过程：
    // 1. make_pair 构造临时pair对象
    // 2. push_back 移动或拷贝pair
    // 3. 销毁临时pair
    
    cout << "\n7. push_back({}):" << endl;
    vec3.push_back({20, "twenty"});
    // 执行过程：
    // 1. 初始化列表构造临时pair对象
    // 2. push_back 移动或拷贝pair
    // 3. 销毁临时pair
    
    cout << "\n8. emplace_back(参数):" << endl;
    vec3.emplace_back(30, "thirty");
    // 执行过程：
    // 1. 直接在vector内存中构造pair
    // 2. 最高效！
    
    // ========== 性能对比总结 ==========
    cout << "\n=== 性能对比总结 ===" << endl;
    cout << "push_back(临时对象):" << endl;
    cout << "  1. 构造临时对象" << endl;
    cout << "  2. 移动/拷贝到vector" << endl;
    cout << "  3. 销毁临时对象" << endl;
    cout << "  总开销: 构造 + 移动/拷贝 + 析构" << endl;
    
    cout << "\nemplace_back(参数):" << endl;
    cout << "  1. 直接在vector内存中构造" << endl;
    cout << "  总开销: 仅构造" << endl;
    cout << "  性能提升: 避免临时对象和移动/拷贝操作" << endl;
    
    // ========== 使用建议 ==========
    cout << "\n=== 使用建议 ===" << endl;
    cout << "1. 传递构造参数时，优先使用 emplace_back" << endl;
    cout << "   ✓ emplace_back(1, \"name\")" << endl;
    cout << "   ✗ push_back(TestClass(1, \"name\"))" << endl;
    
    cout << "\n2. 传递已存在的对象时，使用 push_back" << endl;
    cout << "   ✓ push_back(obj) 或 push_back(move(obj))" << endl;
    cout << "   ✗ emplace_back(obj)  // 错误！" << endl;
    
    cout << "\n3. 对于简单类型（int, double等），性能差异可忽略" << endl;
    cout << "   但对于复杂对象，emplace_back 有明显性能优势" << endl;
    
    return 0;
}

