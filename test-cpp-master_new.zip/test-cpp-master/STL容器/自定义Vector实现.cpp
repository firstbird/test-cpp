#include <iostream>
#include <algorithm>
#include <stdexcept>
using namespace std;

/**
 * 自定义Vector实现
 * 展示vector的核心实现原理：动态扩容、迭代器、异常安全等
 */

template<typename T>
class MyVector {
private:
    T* data_;
    size_t size_;
    size_t capacity_;
    
    static constexpr size_t INITIAL_CAPACITY = 4;
    
    void reallocate(size_t new_capacity) {
        T* new_data = static_cast<T*>(::operator new(new_capacity * sizeof(T)));
        size_t new_size = 0;
        
        try {
            // 移动或拷贝现有元素
            for (size_t i = 0; i < size_; i++) {
                new (new_data + new_size) T(std::move_if_noexcept(data_[i]));
                new_size++;
            }
        } catch (...) {
            // 异常安全：清理已构造的元素
            for (size_t i = 0; i < new_size; i++) {
                (new_data + i)->~T();
            }
            ::operator delete(new_data);
            throw;
        }
        
        // 销毁旧元素
        for (size_t i = 0; i < size_; i++) {
            data_[i].~T();
        }
        ::operator delete(data_);
        
        data_ = new_data;
        capacity_ = new_capacity;
    }
    
public:
    // 迭代器
    class iterator {
    private:
        T* ptr_;
        
    public:
        using iterator_category = std::random_access_iterator_tag;
        using value_type = T;
        using difference_type = ptrdiff_t;
        using pointer = T*;
        using reference = T&;
        
        iterator(T* ptr) : ptr_(ptr) {}
        
        T& operator*() { return *ptr_; }
        T* operator->() { return ptr_; }
        
        iterator& operator++() { ptr_++; return *this; }
        iterator operator++(int) { iterator tmp = *this; ptr_++; return tmp; }
        
        iterator& operator--() { ptr_--; return *this; }
        iterator operator--(int) { iterator tmp = *this; ptr_--; return tmp; }
        
        iterator& operator+=(difference_type n) { ptr_ += n; return *this; }
        iterator& operator-=(difference_type n) { ptr_ -= n; return *this; }
        
        iterator operator+(difference_type n) const { return iterator(ptr_ + n); }
        iterator operator-(difference_type n) const { return iterator(ptr_ - n); }
        difference_type operator-(const iterator& other) const { return ptr_ - other.ptr_; }
        
        bool operator==(const iterator& other) const { return ptr_ == other.ptr_; }
        bool operator!=(const iterator& other) const { return ptr_ != other.ptr_; }
        bool operator<(const iterator& other) const { return ptr_ < other.ptr_; }
        bool operator>(const iterator& other) const { return ptr_ > other.ptr_; }
        
        T& operator[](difference_type n) { return ptr_[n]; }
    };
    
    using const_iterator = const iterator;
    
    // 构造函数
    MyVector() : data_(nullptr), size_(0), capacity_(0) {}
    
    explicit MyVector(size_t n, const T& value = T()) 
        : data_(static_cast<T*>(::operator new(n * sizeof(T)))), size_(n), capacity_(n) {
        for (size_t i = 0; i < n; i++) {
            new (data_ + i) T(value);
        }
    }
    
    MyVector(const MyVector& other) 
        : data_(static_cast<T*>(::operator new(other.capacity_ * sizeof(T)))),
          size_(other.size_), capacity_(other.capacity_) {
        for (size_t i = 0; i < size_; i++) {
            new (data_ + i) T(other.data_[i]);
        }
    }
    
    MyVector(MyVector&& other) noexcept 
        : data_(other.data_), size_(other.size_), capacity_(other.capacity_) {
        other.data_ = nullptr;
        other.size_ = 0;
        other.capacity_ = 0;
    }
    
    ~MyVector() {
        clear();
        ::operator delete(data_);
    }
    
    // 赋值运算符
    MyVector& operator=(const MyVector& other) {
        if (this != &other) {
            MyVector tmp(other);
            swap(tmp);
        }
        return *this;
    }
    
    MyVector& operator=(MyVector&& other) noexcept {
        if (this != &other) {
            clear();
            ::operator delete(data_);
            data_ = other.data_;
            size_ = other.size_;
            capacity_ = other.capacity_;
            other.data_ = nullptr;
            other.size_ = 0;
            other.capacity_ = 0;
        }
        return *this;
    }
    
    // 元素访问
    T& operator[](size_t index) { return data_[index]; }
    const T& operator[](size_t index) const { return data_[index]; }
    
    T& at(size_t index) {
        if (index >= size_) {
            throw std::out_of_range("Index out of range");
        }
        return data_[index];
    }
    
    T& front() { return data_[0]; }
    const T& front() const { return data_[0]; }
    
    T& back() { return data_[size_ - 1]; }
    const T& back() const { return data_[size_ - 1]; }
    
    // 容量
    size_t size() const { return size_; }
    size_t capacity() const { return capacity_; }
    bool empty() const { return size_ == 0; }
    
    void reserve(size_t new_capacity) {
        if (new_capacity > capacity_) {
            reallocate(new_capacity);
        }
    }
    
    void shrink_to_fit() {
        if (size_ < capacity_) {
            reallocate(size_);
        }
    }
    
    // 修改器
    void push_back(const T& value) {
        if (size_ >= capacity_) {
            reserve(capacity_ == 0 ? INITIAL_CAPACITY : capacity_ * 2);
        }
        new (data_ + size_) T(value);
        size_++;
    }
    
    void push_back(T&& value) {
        if (size_ >= capacity_) {
            reserve(capacity_ == 0 ? INITIAL_CAPACITY : capacity_ * 2);
        }
        new (data_ + size_) T(std::move(value));
        size_++;
    }
    
    void pop_back() {
        if (size_ > 0) {
            size_--;
            data_[size_].~T();
        }
    }
    
    void clear() {
        for (size_t i = 0; i < size_; i++) {
            data_[i].~T();
        }
        size_ = 0;
    }
    
    void swap(MyVector& other) noexcept {
        std::swap(data_, other.data_);
        std::swap(size_, other.size_);
        std::swap(capacity_, other.capacity_);
    }
    
    // 迭代器
    iterator begin() { return iterator(data_); }
    iterator end() { return iterator(data_ + size_); }
    const_iterator begin() const { return const_iterator(data_); }
    const_iterator end() const { return const_iterator(data_ + size_); }
};

// 测试代码
int main() {
    cout << "=== Custom Vector Implementation ===" << endl;
    
    MyVector<int> vec;
    
    cout << "\n1. Push back elements:" << endl;
    for (int i = 0; i < 10; i++) {
        vec.push_back(i);
        cout << "Size: " << vec.size() << ", Capacity: " << vec.capacity() << endl;
    }
    
    cout << "\n2. Iterate elements:" << endl;
    for (auto it = vec.begin(); it != vec.end(); ++it) {
        cout << *it << " ";
    }
    cout << endl;
    
    cout << "\n3. Range-based for loop:" << endl;
    for (const auto& val : vec) {
        cout << val << " ";
    }
    cout << endl;
    
    cout << "\n4. Access elements:" << endl;
    cout << "vec[0] = " << vec[0] << endl;
    cout << "vec.front() = " << vec.front() << endl;
    cout << "vec.back() = " << vec.back() << endl;
    
    cout << "\n5. Pop back:" << endl;
    vec.pop_back();
    cout << "Size after pop_back: " << vec.size() << endl;
    
    return 0;
}

