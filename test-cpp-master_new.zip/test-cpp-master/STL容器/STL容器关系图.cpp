#include <iostream>
#include <vector>
#include <deque>
#include <list>
#include <forward_list>
#include <array>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <stack>
#include <queue>
#include <queue>  // priority_queue 在 queue 头文件中
using namespace std;

/**
 * STL 容器层次关系演示
 */

// ========== 一、序列容器 ==========

void demonstrate_sequence_containers() {
    cout << "=== 序列容器 (Sequence Containers) ===" << endl;
    
    // 1. array - 固定大小数组
    array<int, 5> arr = {1, 2, 3, 4, 5};
    cout << "array: 固定大小，栈上分配" << endl;
    
    // 2. vector - 动态数组
    vector<int> vec = {1, 2, 3, 4, 5};
    cout << "vector: 动态数组，尾部插入O(1)" << endl;
    
    // 3. deque - 双端队列
    deque<int> dq = {1, 2, 3, 4, 5};
    cout << "deque: 双端队列，头尾插入O(1)" << endl;
    
    // 4. list - 双向链表
    list<int> lst = {1, 2, 3, 4, 5};
    cout << "list: 双向链表，任意位置插入O(1)" << endl;
    
    // 5. forward_list - 单向链表
    forward_list<int> flst = {1, 2, 3, 4, 5};
    cout << "forward_list: 单向链表，更节省内存" << endl;
}

// ========== 二、关联容器 ==========

void demonstrate_associative_containers() {
    cout << "\n=== 关联容器 (Associative Containers) ===" << endl;
    cout << "底层实现: 红黑树 (Red-Black Tree)" << endl;
    
    // 1. set - 有序、唯一
    set<int> s = {3, 1, 4, 1, 5};  // {1, 3, 4, 5}
    cout << "set: 有序、唯一，查找O(log n)" << endl;
    
    // 2. multiset - 有序、可重复
    multiset<int> ms = {3, 1, 4, 1, 5};  // {1, 1, 3, 4, 5}
    cout << "multiset: 有序、可重复" << endl;
    
    // 3. map - 键有序、唯一
    map<string, int> m = {
        {"apple", 1},
        {"banana", 2},
        {"apple", 3}  // 会被覆盖
    };
    cout << "map: 键有序、唯一" << endl;
    
    // 4. multimap - 键有序、可重复
    multimap<string, int> mm = {
        {"apple", 1},
        {"banana", 2},
        {"apple", 3}  // 保留两个
    };
    cout << "multimap: 键有序、可重复" << endl;
}

// ========== 三、无序容器 ==========

void demonstrate_unordered_containers() {
    cout << "\n=== 无序容器 (Unordered Containers, C++11) ===" << endl;
    cout << "底层实现: 哈希表 (Hash Table)" << endl;
    
    // 1. unordered_set - 无序、唯一
    unordered_set<int> us = {3, 1, 4, 1, 5};
    cout << "unordered_set: 无序、唯一，查找O(1)平均" << endl;
    
    // 2. unordered_multiset - 无序、可重复
    unordered_multiset<int> ums = {3, 1, 4, 1, 5};
    cout << "unordered_multiset: 无序、可重复" << endl;
    
    // 3. unordered_map - 键无序、唯一
    unordered_map<string, int> um = {
        {"apple", 1},
        {"banana", 2}
    };
    cout << "unordered_map: 键无序、唯一" << endl;
    
    // 4. unordered_multimap - 键无序、可重复
    unordered_multimap<string, int> umm = {
        {"apple", 1},
        {"banana", 2},
        {"apple", 3}
    };
    cout << "unordered_multimap: 键无序、可重复" << endl;
}

// ========== 四、容器适配器 ==========

void demonstrate_container_adapters() {
    cout << "\n=== 容器适配器 (Container Adapters) ===" << endl;
    cout << "使用适配器模式，封装底层容器" << endl;
    
    // 1. stack - 默认使用 deque
    stack<int> s1;
    cout << "stack: 默认底层容器 = deque" << endl;
    
    // stack 使用 vector
    stack<int, vector<int>> s2;
    cout << "stack: 可以指定底层容器 = vector" << endl;
    
    // 2. queue - 默认使用 deque
    queue<int> q1;
    cout << "queue: 默认底层容器 = deque" << endl;
    
    // queue 使用 list
    queue<int, list<int>> q2;
    cout << "queue: 可以指定底层容器 = list" << endl;
    
    // 3. priority_queue - 默认使用 vector
    priority_queue<int> pq1;
    cout << "priority_queue: 默认底层容器 = vector" << endl;
    
    // priority_queue 使用 deque
    priority_queue<int, deque<int>> pq2;
    cout << "priority_queue: 可以指定底层容器 = deque" << endl;
}

// ========== 五、迭代器层次演示 ==========

void demonstrate_iterators() {
    cout << "\n=== 迭代器层次 (Iterator Hierarchy) ===" << endl;
    
    vector<int> vec = {1, 2, 3, 4, 5};
    list<int> lst = {1, 2, 3, 4, 5};
    
    // Random Access Iterator (vector)
    cout << "vector 迭代器: Random Access Iterator" << endl;
    auto it1 = vec.begin();
    it1 += 3;  // 随机访问
    cout << "  it += 3: " << *it1 << endl;
    
    // Bidirectional Iterator (list)
    cout << "list 迭代器: Bidirectional Iterator" << endl;
    auto it2 = lst.begin();
    ++it2;  // 前向
    --it2;  // 后向
    // it2 += 3;  // ❌ 错误！不支持随机访问
    cout << "  只支持 ++ 和 --" << endl;
}

// ========== 六、容器接口统一性 ==========

template<typename Container>
void demonstrate_unified_interface(const Container& c, const string& name) {
    cout << "\n" << name << " 统一接口:" << endl;
    cout << "  begin() / end(): " << (c.begin() != c.end() ? "✓" : "✗") << endl;
    cout << "  size(): " << c.size() << endl;
    cout << "  empty(): " << (c.empty() ? "true" : "false") << endl;
}

// ========== 七、性能对比示例 ==========

void demonstrate_performance() {
    cout << "\n=== 性能对比 ===" << endl;
    
    const int N = 1000000;
    
    // vector: 尾部插入
    vector<int> vec;
    // vec.push_back() 在尾部插入，O(1) 均摊
    
    // list: 任意位置插入
    list<int> lst;
    // lst.insert() 在任意位置插入，O(1)
    
    // set: 有序插入
    set<int> s;
    // s.insert() 插入，O(log n)
    
    // unordered_set: 无序插入
    unordered_set<int> us;
    // us.insert() 插入，O(1) 平均
    
    cout << "插入性能:" << endl;
    cout << "  vector (尾部): O(1) 均摊" << endl;
    cout << "  list (任意位置): O(1)" << endl;
    cout << "  set: O(log n)" << endl;
    cout << "  unordered_set: O(1) 平均" << endl;
}

int main() {
    demonstrate_sequence_containers();
    demonstrate_associative_containers();
    demonstrate_unordered_containers();
    demonstrate_container_adapters();
    demonstrate_iterators();
    
    // 统一接口演示
    vector<int> vec = {1, 2, 3};
    list<int> lst = {1, 2, 3};
    set<int> s = {1, 2, 3};
    
    demonstrate_unified_interface(vec, "vector");
    demonstrate_unified_interface(lst, "list");
    demonstrate_unified_interface(s, "set");
    
    demonstrate_performance();
    
    return 0;
}

