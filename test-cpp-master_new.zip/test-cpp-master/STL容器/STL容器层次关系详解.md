# C++ STL 容器层次关系详解

## STL 容器分类体系

```
STL Containers
│
├── Sequence Containers (序列容器)
│   ├── array (C++11)
│   ├── vector
│   ├── deque
│   ├── list
│   └── forward_list (C++11)
│
├── Associative Containers (关联容器)
│   ├── set
│   ├── multiset
│   ├── map
│   └── multimap
│
├── Unordered Containers (无序容器, C++11)
│   ├── unordered_set
│   ├── unordered_multiset
│   ├── unordered_map
│   └── unordered_multimap
│
└── Container Adapters (容器适配器)
    ├── stack
    ├── queue
    └── priority_queue
```

## 一、序列容器 (Sequence Containers)

### 1. array (C++11)
**特点：**
- 固定大小数组
- 栈上分配
- 支持随机访问
- 大小在编译时确定

**接口层次：**
```
array<T, N>
  └── 直接实现容器接口
      ├── begin() / end()
      ├── size()
      ├── operator[]
      └── at()
```

**增删接口：**
```cpp
// array 不支持动态增删（固定大小）
// 只能通过索引修改元素值
array<int, 5> arr = {1, 2, 3, 4, 5};
arr[0] = 10;        // 修改元素，O(1)
arr.at(1) = 20;     // 修改元素（带边界检查），O(1)
// 注意：array 没有 insert()、erase()、push_back() 等方法
```

### 2. vector
**特点：**
- 动态数组
- 连续内存
- 支持随机访问
- 尾部插入/删除 O(1) 均摊

**接口层次：**
```
vector<T>
  └── 直接实现容器接口
      ├── Sequence Container 接口
      ├── Random Access Container 接口
      └── Reversible Container 接口
```

**增删接口：**
```cpp
vector<int> vec;

// ========== 插入操作 ==========
// 1. push_back() - 尾部插入
vec.push_back(10);              // O(1) 均摊
vec.emplace_back(20);           // O(1) 均摊，直接构造

// 2. insert() - 指定位置插入
vec.insert(vec.begin(), 5);                    // 头部插入，O(n)
vec.insert(vec.begin() + 2, 15);               // 位置2插入，O(n)
vec.insert(vec.begin(), 3, 100);               // 插入3个100，O(n)
vec.insert(vec.begin(), {1, 2, 3});            // 插入初始化列表，O(n)
vec.insert(vec.begin(), other.begin(), other.end()); // 插入范围，O(n)

// 3. emplace() - 指定位置直接构造
vec.emplace(vec.begin(), 30);                  // 头部构造插入，O(n)

// ========== 删除操作 ==========
// 1. pop_back() - 尾部删除
vec.pop_back();                                 // O(1)

// 2. erase() - 指定位置删除
vec.erase(vec.begin());                        // 删除第一个元素，O(n)
vec.erase(vec.begin() + 2);                   // 删除位置2的元素，O(n)
vec.erase(vec.begin(), vec.begin() + 3);      // 删除范围[begin, begin+3)，O(n)

// 3. clear() - 清空所有元素
vec.clear();                                   // O(n)

// 4. remove() - 删除指定值的元素（需要配合erase）
vec.erase(remove(vec.begin(), vec.end(), 10), vec.end()); // O(n)
```

### 3. deque
**特点：**
- 双端队列
- 分段连续内存
- 支持随机访问
- 头尾插入/删除 O(1)

**接口层次：**
```
deque<T>
  └── 类似 vector
      ├── Sequence Container 接口
      ├── Random Access Container 接口
      └── Reversible Container 接口
```

**增删接口：**
```cpp
deque<int> dq;

// ========== 插入操作 ==========
// 1. 头部插入
dq.push_front(10);              // O(1)
dq.emplace_front(20);          // O(1)，直接构造

// 2. 尾部插入
dq.push_back(30);              // O(1)
dq.emplace_back(40);           // O(1)，直接构造

// 3. 指定位置插入
dq.insert(dq.begin(), 5);                    // 头部插入，O(n)
dq.insert(dq.begin() + 2, 15);               // 位置2插入，O(n)
dq.insert(dq.begin(), 3, 100);               // 插入3个100，O(n)
dq.insert(dq.begin(), {1, 2, 3});           // 插入初始化列表，O(n)
dq.emplace(dq.begin(), 50);                  // 头部构造插入，O(n)

// ========== 删除操作 ==========
// 1. 头部删除
dq.pop_front();                               // O(1)

// 2. 尾部删除
dq.pop_back();                                // O(1)

// 3. 指定位置删除
dq.erase(dq.begin());                        // 删除第一个元素，O(n)
dq.erase(dq.begin() + 2);                    // 删除位置2的元素，O(n)
dq.erase(dq.begin(), dq.begin() + 3);        // 删除范围，O(n)

// 4. 清空
dq.clear();                                   // O(n)
```

### 4. list
**特点：**
- 双向链表
- 非连续内存
- 不支持随机访问
- 任意位置插入/删除 O(1)

**接口层次：**
```
list<T>
  └── Sequence Container 接口
      ├── Bidirectional Iterator
      └── Reversible Container 接口
```

**增删接口：**
```cpp
list<int> lst;

// ========== 插入操作 ==========
// 1. 头部插入
lst.push_front(10);              // O(1)
lst.emplace_front(20);           // O(1)，直接构造

// 2. 尾部插入
lst.push_back(30);               // O(1)
lst.emplace_back(40);            // O(1)，直接构造

// 3. 指定位置插入
lst.insert(lst.begin(), 5);                    // 头部插入，O(1)
auto it = lst.begin();
advance(it, 2);
lst.insert(it, 15);                            // 位置2插入，O(1)
lst.insert(lst.begin(), 3, 100);              // 插入3个100，O(1)
lst.insert(lst.begin(), {1, 2, 3});            // 插入初始化列表，O(1)
lst.emplace(lst.begin(), 50);                  // 头部构造插入，O(1)

// ========== 删除操作 ==========
// 1. 头部删除
lst.pop_front();                               // O(1)

// 2. 尾部删除
lst.pop_back();                                // O(1)

// 3. 指定位置删除
lst.erase(lst.begin());                       // 删除第一个元素，O(1)
auto it2 = lst.begin();
advance(it2, 2);
lst.erase(it2);                                // 删除指定位置，O(1)
lst.erase(lst.begin(), lst.end());            // 删除范围，O(n)

// 4. 删除指定值
lst.remove(10);                                // 删除所有值为10的元素，O(n)

// 5. 条件删除
lst.remove_if([](int x) { return x > 20; });  // 删除满足条件的元素，O(n)

// 6. 清空
lst.clear();                                   // O(n)

// 7. 去重（需要先排序）
lst.sort();                                    // O(n log n)
lst.unique();                                  // 删除连续重复元素，O(n)
```

### 5. forward_list (C++11)
**特点：**
- 单向链表
- 更节省内存
- 只支持前向遍历

**接口层次：**
```
forward_list<T>
  └── Sequence Container 接口
      └── Forward Iterator
```

**增删接口：**
```cpp
forward_list<int> flst;

// ========== 插入操作 ==========
// 1. 头部插入（唯一方式）
flst.push_front(10);              // O(1)
flst.emplace_front(20);           // O(1)，直接构造

// 2. 指定位置之后插入（forward_list的特殊性）
flst.insert_after(flst.before_begin(), 5);     // 头部插入，O(1)
auto it = flst.begin();
flst.insert_after(it, 15);                     // 在第一个元素后插入，O(1)
flst.insert_after(it, 3, 100);                // 插入3个100，O(1)
flst.insert_after(it, {1, 2, 3});             // 插入初始化列表，O(1)
flst.emplace_after(it, 50);                    // 构造插入，O(1)

// ========== 删除操作 ==========
// 1. 头部删除
flst.pop_front();                               // O(1)

// 2. 删除指定位置之后的元素
flst.erase_after(flst.before_begin());         // 删除第一个元素，O(1)
auto it2 = flst.begin();
flst.erase_after(it2);                         // 删除it2之后的元素，O(1)
flst.erase_after(it2, flst.end());             // 删除范围，O(n)

// 3. 删除指定值
flst.remove(10);                                // 删除所有值为10的元素，O(n)

// 4. 条件删除
flst.remove_if([](int x) { return x > 20; });  // 删除满足条件的元素，O(n)

// 5. 清空
flst.clear();                                   // O(n)

// 注意：forward_list 没有 size()、back()、pop_back() 等方法
```

## 二、关联容器 (Associative Containers)

### 底层实现：红黑树 (Red-Black Tree)

```
Associative Container Base
    │
    ├── set<T>
    │   └── 基于红黑树
    │       └── 有序、唯一
    │
    ├── multiset<T>
    │   └── 基于红黑树
    │       └── 有序、可重复
    │
    ├── map<K, V>
    │   └── 基于红黑树
    │       └── 键有序、唯一
    │
    └── multimap<K, V>
        └── 基于红黑树
            └── 键有序、可重复
```

**共同接口：**
```cpp
// 所有关联容器都支持：
- find(key)           // O(log n)
- insert(value)       // O(log n)
- erase(key)          // O(log n)
- lower_bound(key)    // O(log n)
- upper_bound(key)    // O(log n)
- equal_range(key)    // O(log n)
```

**增删接口详解：**

#### set / multiset
```cpp
set<int> s;
multiset<int> ms;

// ========== 插入操作 ==========
// 1. insert() - 插入元素
s.insert(10);                                  // O(log n)，返回 pair<iterator, bool>
s.insert(20);
s.insert({30, 40, 50});                       // 插入初始化列表，O(k log n)，k为元素数
s.insert(vec.begin(), vec.end());             // 插入范围，O(k log n)

// 2. emplace() - 直接构造插入
s.emplace(60);                                // O(log n)，返回 pair<iterator, bool>
s.emplace_hint(s.begin(), 70);                // 提示位置插入，O(log n) 或 O(1)

// multiset 插入（允许重复）
ms.insert(10);                                // O(log n)，返回 iterator
ms.insert(10);                                // 可以重复插入

// ========== 删除操作 ==========
// 1. erase() - 删除元素
s.erase(10);                                  // 删除值为10的元素，O(log n)，返回删除数量
s.erase(s.begin());                           // 删除迭代器指向的元素，O(log n)
s.erase(s.begin(), s.end());                 // 删除范围，O(k log n)

// 2. clear() - 清空
s.clear();                                    // O(n)

// multiset 删除
ms.erase(10);                                 // 删除所有值为10的元素，O(log n + k)，k为重复数
```

#### map / multimap
```cpp
map<string, int> m;
multimap<string, int> mm;

// ========== 插入操作 ==========
// 1. insert() - 插入键值对
m.insert({"apple", 1});                       // O(log n)，返回 pair<iterator, bool>
m.insert(make_pair("banana", 2));             // O(log n)
m.insert(pair<string, int>("cherry", 3));    // O(log n)
m.insert({{"date", 4}, {"elderberry", 5}});  // 插入初始化列表，O(k log n)

// 2. emplace() - 直接构造插入
m.emplace("fig", 6);                          // O(log n)，返回 pair<iterator, bool>
m.emplace_hint(m.begin(), "grape", 7);        // 提示位置插入，O(log n) 或 O(1)

// 3. operator[] - 插入或访问（仅map）
m["honeydew"] = 8;                            // 如果不存在则插入，存在则修改，O(log n)
m.at("honeydew") = 9;                        // 访问（不存在则抛出异常），O(log n)

// multimap 插入（允许重复键）
mm.insert({"apple", 1});                      // O(log n)，返回 iterator
mm.insert({"apple", 2});                     // 可以重复插入相同键

// ========== 删除操作 ==========
// 1. erase() - 删除元素
m.erase("apple");                             // 删除指定键，O(log n)，返回删除数量
m.erase(m.begin());                           // 删除迭代器指向的元素，O(log n)
m.erase(m.begin(), m.end());                  // 删除范围，O(k log n)

// 2. clear() - 清空
m.clear();                                    // O(n)

// multimap 删除
mm.erase("apple");                            // 删除所有键为"apple"的元素，O(log n + k)
```

## 三、无序容器 (Unordered Containers, C++11)

### 底层实现：哈希表 (Hash Table)

```
Unordered Container Base
    │
    ├── unordered_set<T>
    │   └── 基于哈希表
    │       └── 无序、唯一
    │
    ├── unordered_multiset<T>
    │   └── 基于哈希表
    │       └── 无序、可重复
    │
    ├── unordered_map<K, V>
    │   └── 基于哈希表
    │       └── 键无序、唯一
    │
    └── unordered_multimap<K, V>
        └── 基于哈希表
            └── 键无序、可重复
```

**共同接口：**
```cpp
// 所有无序容器都支持：
- find(key)           // O(1) 平均，O(n) 最坏
- insert(value)       // O(1) 平均，O(n) 最坏
- erase(key)          // O(1) 平均，O(n) 最坏
- bucket_count()      // 桶数量
- load_factor()       // 负载因子
```

**增删接口详解：**

#### unordered_set / unordered_multiset
```cpp
unordered_set<int> us;
unordered_multiset<int> ums;

// ========== 插入操作 ==========
// 1. insert() - 插入元素
us.insert(10);                                // O(1) 平均，O(n) 最坏，返回 pair<iterator, bool>
us.insert(20);
us.insert({30, 40, 50});                      // 插入初始化列表，O(k) 平均
us.insert(vec.begin(), vec.end());           // 插入范围，O(k) 平均

// 2. emplace() - 直接构造插入
us.emplace(60);                               // O(1) 平均，返回 pair<iterator, bool>
us.emplace_hint(us.begin(), 70);             // 提示位置插入，O(1) 平均

// unordered_multiset 插入（允许重复）
ums.insert(10);                               // O(1) 平均，返回 iterator
ums.insert(10);                               // 可以重复插入

// ========== 删除操作 ==========
// 1. erase() - 删除元素
us.erase(10);                                 // 删除值为10的元素，O(1) 平均，返回删除数量
us.erase(us.begin());                        // 删除迭代器指向的元素，O(1) 平均
us.erase(us.begin(), us.end());              // 删除范围，O(k) 平均

// 2. clear() - 清空
us.clear();                                  // O(n)

// unordered_multiset 删除
ums.erase(10);                                // 删除所有值为10的元素，O(k) 平均，k为重复数
```

#### unordered_map / unordered_multimap
```cpp
unordered_map<string, int> um;
unordered_multimap<string, int> umm;

// ========== 插入操作 ==========
// 1. insert() - 插入键值对
um.insert({"apple", 1});                      // O(1) 平均，O(n) 最坏，返回 pair<iterator, bool>
um.insert(make_pair("banana", 2));            // O(1) 平均
um.insert({{"cherry", 3}, {"date", 4}});     // 插入初始化列表，O(k) 平均

// 2. emplace() - 直接构造插入
um.emplace("elderberry", 5);                  // O(1) 平均，返回 pair<iterator, bool>
um.emplace_hint(um.begin(), "fig", 6);       // 提示位置插入，O(1) 平均

// 3. operator[] - 插入或访问（仅unordered_map）
um["grape"] = 7;                             // 如果不存在则插入，存在则修改，O(1) 平均
um.at("grape") = 8;                          // 访问（不存在则抛出异常），O(1) 平均

// unordered_multimap 插入（允许重复键）
umm.insert({"apple", 1});                     // O(1) 平均，返回 iterator
umm.insert({"apple", 2});                    // 可以重复插入相同键

// ========== 删除操作 ==========
// 1. erase() - 删除元素
um.erase("apple");                           // 删除指定键，O(1) 平均，返回删除数量
um.erase(um.begin());                        // 删除迭代器指向的元素，O(1) 平均
um.erase(um.begin(), um.end());              // 删除范围，O(k) 平均

// 2. clear() - 清空
um.clear();                                  // O(n)

// unordered_multimap 删除
umm.erase("apple");                          // 删除所有键为"apple"的元素，O(k) 平均

// ========== 哈希表管理 ==========
um.reserve(1000);                            // 预留空间，O(n)
um.rehash(1000);                             // 重新哈希，O(n)
um.max_load_factor(0.75);                    // 设置最大负载因子
```

## 四、容器适配器 (Container Adapters)

### 1. stack
**底层容器：** deque (默认) 或 vector/list

```
stack<T, Container = deque<T>>
    └── 适配器模式
        ├── 封装底层容器
        └── 只暴露栈接口
            ├── push()
            ├── pop()
            ├── top()
            └── empty()
```

**增删接口：**
```cpp
stack<int> s;
stack<int, vector<int>> s2;  // 使用vector作为底层容器

// ========== 插入操作 ==========
// 1. push() - 压栈
s.push(10);                   // O(1)，调用底层容器的 push_back()
s.push(20);
s.push(30);

// 2. emplace() - 直接构造压栈（C++11）
s.emplace(40);                // O(1)，调用底层容器的 emplace_back()

// ========== 删除操作 ==========
// 1. pop() - 出栈
s.pop();                      // O(1)，调用底层容器的 pop_back()
// 注意：pop() 不返回元素值，需要先 top() 再 pop()

// 2. 访问栈顶
int top = s.top();            // O(1)，返回栈顶元素引用

// 3. 清空（通过循环）
while (!s.empty()) {
    s.pop();
}

// 注意：stack 没有 clear() 方法，也没有 insert()、erase() 等方法
```

### 2. queue
**底层容器：** deque (默认) 或 list

```
queue<T, Container = deque<T>>
    └── 适配器模式
        ├── 封装底层容器
        └── 只暴露队列接口
            ├── push()
            ├── pop()
            ├── front()
            ├── back()
            └── empty()
```

**增删接口：**
```cpp
queue<int> q;
queue<int, list<int>> q2;  // 使用list作为底层容器

// ========== 插入操作 ==========
// 1. push() - 入队（尾部）
q.push(10);                 // O(1)，调用底层容器的 push_back()
q.push(20);
q.push(30);

// 2. emplace() - 直接构造入队（C++11）
q.emplace(40);              // O(1)，调用底层容器的 emplace_back()

// ========== 删除操作 ==========
// 1. pop() - 出队（头部）
q.pop();                    // O(1)，调用底层容器的 pop_front()
// 注意：pop() 不返回元素值，需要先 front() 再 pop()

// 2. 访问队首和队尾
int front = q.front();      // O(1)，返回队首元素引用
int back = q.back();        // O(1)，返回队尾元素引用

// 3. 清空（通过循环）
while (!q.empty()) {
    q.pop();
}

// 注意：queue 没有 clear() 方法，也没有 insert()、erase() 等方法
```

### 3. priority_queue
**底层容器：** vector (默认) 或 deque

```
priority_queue<T, Container = vector<T>, Compare = less<T>>
    └── 适配器模式
        ├── 封装底层容器
        ├── 使用堆算法
        └── 只暴露优先队列接口
            ├── push()
            ├── pop()
            ├── top()
            └── empty()
```

**增删接口：**
```cpp
// 默认大顶堆（最大元素在顶部）
priority_queue<int> pq;

// 小顶堆
priority_queue<int, vector<int>, greater<int>> pq_min;

// 自定义比较函数
struct Compare {
    bool operator()(int a, int b) {
        return a > b;  // 小顶堆
    }
};
priority_queue<int, vector<int>, Compare> pq_custom;

// ========== 插入操作 ==========
// 1. push() - 插入元素
pq.push(10);                // O(log n)，维护堆性质
pq.push(20);
pq.push(30);

// 2. emplace() - 直接构造插入（C++11）
pq.emplace(40);             // O(log n)，直接构造

// ========== 删除操作 ==========
// 1. pop() - 删除堆顶元素
pq.pop();                   // O(log n)，删除最大元素并维护堆性质
// 注意：pop() 不返回元素值，需要先 top() 再 pop()

// 2. 访问堆顶
int top = pq.top();         // O(1)，返回堆顶元素引用（最大元素）

// 3. 清空（通过循环）
while (!pq.empty()) {
    pq.pop();
}

// 注意：priority_queue 没有 clear() 方法，也没有 insert()、erase() 等方法
// 注意：priority_queue 不支持随机访问，只能访问堆顶元素
```

## 五、迭代器层次关系

```
Iterator Hierarchy
    │
    ├── Input Iterator (输入迭代器)
    │   └── 只能读取，只能前向
    │
    ├── Output Iterator (输出迭代器)
    │   └── 只能写入，只能前向
    │
    ├── Forward Iterator (前向迭代器)
    │   └── 可读写，只能前向
    │       └── forward_list
    │
    ├── Bidirectional Iterator (双向迭代器)
    │   └── 可读写，可前向后向
    │       ├── list
    │       ├── set / map
    │       └── unordered_set / unordered_map
    │
    └── Random Access Iterator (随机访问迭代器)
        └── 可读写，可随机访问
            ├── vector
            ├── deque
            └── array
```

## 六、容器接口继承关系

### 基础容器接口

```
Container Concept
    ├── begin() / end()
    ├── size()
    ├── empty()
    └── swap()
```

### 序列容器接口

```
Sequence Container
    ├── Container Concept
    ├── insert()
    ├── erase()
    └── assign()
```

### 关联容器接口

```
Associative Container
    ├── Container Concept
    ├── find()
    ├── count()
    ├── lower_bound()
    ├── upper_bound()
    └── equal_range()
```

### 无序容器接口

```
Unordered Container
    ├── Container Concept
    ├── find()
    ├── count()
    ├── bucket_count()
    └── load_factor()
```

## 七、容器选择指南

### 按使用场景选择

```
需要随机访问？
    ├── 是 → vector / deque / array
    │       ├── 固定大小？ → array
    │       ├── 主要在尾部操作？ → vector
    │       └── 需要头尾操作？ → deque
    │
    └── 否 → list / forward_list
            ├── 需要双向遍历？ → list
            └── 只需要前向遍历？ → forward_list

需要有序？
    ├── 是 → set / map / multiset / multimap
    │       ├── 唯一键？ → set / map
    │       └── 可重复键？ → multiset / multimap
    │
    └── 否 → unordered_set / unordered_map
            ├── 唯一键？ → unordered_set / unordered_map
            └── 可重复键？ → unordered_multiset / unordered_multimap

需要特殊操作？
    ├── LIFO (后进先出) → stack
    ├── FIFO (先进先出) → queue
    └── 优先级队列 → priority_queue
```

## 八、性能对比表

| 容器 | 插入 | 删除 | 查找 | 随机访问 | 内存 |
|------|------|------|------|----------|------|
| **array** | N/A | N/A | O(n) | O(1) | 固定 |
| **vector** | O(1) 尾部均摊<br>O(n) 其他位置 | O(1) 尾部<br>O(n) 其他位置 | O(n) | O(1) | 连续 |
| **deque** | O(1) 头尾<br>O(n) 中间 | O(1) 头尾<br>O(n) 中间 | O(n) | O(1) | 分段连续 |
| **list** | O(1) | O(1) | O(n) | N/A | 非连续 |
| **forward_list** | O(1) | O(1) | O(n) | N/A | 非连续 |
| **set** | O(log n) | O(log n) | O(log n) | N/A | 非连续 |
| **map** | O(log n) | O(log n) | O(log n) | N/A | 非连续 |
| **unordered_set** | O(1) 平均<br>O(n) 最坏 | O(1) 平均<br>O(n) 最坏 | O(1) 平均<br>O(n) 最坏 | N/A | 非连续 |
| **unordered_map** | O(1) 平均<br>O(n) 最坏 | O(1) 平均<br>O(n) 最坏 | O(1) 平均<br>O(n) 最坏 | N/A | 非连续 |
| **stack** | O(1) | O(1) | N/A | N/A | 取决于底层容器 |
| **queue** | O(1) | O(1) | N/A | N/A | 取决于底层容器 |
| **priority_queue** | O(log n) | O(log n) | N/A | N/A | 取决于底层容器 |

### 增删操作详细说明

#### 序列容器插入操作
- **vector**: `push_back()` O(1) 均摊，`insert()` O(n)
- **deque**: `push_front()` / `push_back()` O(1)，`insert()` O(n)
- **list**: `push_front()` / `push_back()` / `insert()` 都是 O(1)
- **forward_list**: `push_front()` / `insert_after()` 都是 O(1)

#### 序列容器删除操作
- **vector**: `pop_back()` O(1)，`erase()` O(n)
- **deque**: `pop_front()` / `pop_back()` O(1)，`erase()` O(n)
- **list**: `pop_front()` / `pop_back()` / `erase()` 都是 O(1)，`remove()` O(n)
- **forward_list**: `pop_front()` / `erase_after()` 都是 O(1)，`remove()` O(n)

#### 关联容器增删操作
- **set/map**: `insert()` / `erase()` 都是 O(log n)
- **multiset/multimap**: `insert()` O(log n)，`erase(key)` O(log n + k)，k为重复数

#### 无序容器增删操作
- **unordered_set/map**: `insert()` / `erase()` O(1) 平均，O(n) 最坏
- **unordered_multiset/multimap**: `insert()` O(1) 平均，`erase(key)` O(k) 平均，k为重复数

## 九、设计模式应用

### 1. 适配器模式 (Adapter Pattern)
```cpp
// stack, queue, priority_queue 都是适配器
stack<T, Container = deque<T>>  // 适配 deque 为 stack
```

### 2. 迭代器模式 (Iterator Pattern)
```cpp
// 所有容器都提供迭代器接口
for (auto it = container.begin(); it != container.end(); ++it)
```

### 3. 策略模式 (Strategy Pattern)
```cpp
// 关联容器使用比较函数对象
set<T, Compare = less<T>>

// 无序容器使用哈希函数对象
unordered_set<T, Hash = hash<T>, Equal = equal_to<T>>
```

## 十、实际应用示例

### 示例1：选择合适的容器

```cpp
// 场景1：需要快速查找
unordered_map<string, int> wordCount;  // O(1) 查找

// 场景2：需要有序遍历
map<string, int> sortedWords;  // O(log n) 查找，有序

// 场景3：需要随机访问
vector<int> scores;  // O(1) 随机访问

// 场景4：需要频繁插入删除
list<int> items;  // O(1) 插入删除
```

### 示例2：容器适配器使用

```cpp
// stack 适配 deque
stack<int> s1;  // 默认使用 deque

// stack 适配 vector
stack<int, vector<int>> s2;  // 使用 vector

// priority_queue 适配 vector
priority_queue<int> pq1;  // 默认使用 vector

// priority_queue 适配 deque
priority_queue<int, deque<int>> pq2;  // 使用 deque
```

## 总结

### 容器层次关系核心要点

1. **序列容器**：按位置存储，支持顺序访问
2. **关联容器**：按键值存储，基于红黑树，有序
3. **无序容器**：按键值存储，基于哈希表，无序
4. **容器适配器**：封装底层容器，提供特定接口

### 选择原则

- **随机访问** → vector / deque / array
- **快速查找** → unordered_set / unordered_map
- **有序遍历** → set / map
- **频繁插入删除** → list / forward_list
- **特殊操作** → stack / queue / priority_queue

### 设计精髓

- **接口统一**：所有容器都实现基本容器接口
- **迭代器抽象**：统一的遍历方式
- **适配器模式**：复用底层容器实现
- **策略模式**：可配置的比较/哈希函数

这就是 STL 容器的层次关系和设计哲学！🎯

