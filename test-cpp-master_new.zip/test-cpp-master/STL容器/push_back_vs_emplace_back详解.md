# push_back vs emplace_back 详解

## 核心区别

### push_back
- **接受**：已构造的对象（左值或右值）
- **过程**：先构造对象，再拷贝/移动到vector
- **C++11前**：只能拷贝构造
- **C++11后**：可以移动构造（传递右值时）

### emplace_back
- **接受**：构造参数（使用完美转发）
- **过程**：直接在vector内存中构造对象
- **C++11引入**：避免临时对象

## 详细对比

### 1. 传递临时对象

```cpp
vector<TestClass> vec;

// push_back: 需要临时对象
vec.push_back(TestClass(1, "name"));
// 执行过程：
// 1. 构造临时对象 TestClass(1, "name")
// 2. push_back 调用移动构造函数（C++11）或拷贝构造函数（C++98）
// 3. 销毁临时对象
// 总开销：构造 + 移动/拷贝 + 析构

// emplace_back: 直接构造
vec.emplace_back(1, "name");
// 执行过程：
// 1. 直接在vector内存中构造对象
// 总开销：仅构造
// 性能提升：避免临时对象和移动/拷贝操作
```

### 2. 传递已存在的对象

```cpp
TestClass obj(1, "name");

// push_back: 可以传递对象
vec.push_back(obj);        // 拷贝构造
vec.push_back(move(obj));  // 移动构造

// emplace_back: 不能传递对象
// vec.emplace_back(obj);  // ❌ 错误！需要构造参数
vec.emplace_back(1, "name");  // ✓ 正确
```

### 3. 复杂对象示例

```cpp
vector<pair<int, string>> vec;

// push_back: 需要临时对象
vec.push_back(make_pair(10, "ten"));
// 或
vec.push_back({20, "twenty"});

// emplace_back: 直接构造
vec.emplace_back(30, "thirty");  // 最高效！
```

## 性能对比

### 测试代码

```cpp
#include <vector>
#include <chrono>
#include <iostream>

class Heavy {
    int data[1000];
public:
    Heavy(int x) { data[0] = x; }
    Heavy(const Heavy&) { /* 拷贝开销大 */ }
    Heavy(Heavy&&) { /* 移动开销小 */ }
};

int main() {
    vector<Heavy> vec1, vec2;
    const int N = 1000000;
    
    // push_back 测试
    auto start = chrono::high_resolution_clock::now();
    for (int i = 0; i < N; i++) {
        vec1.push_back(Heavy(i));
    }
    auto end = chrono::high_resolution_clock::now();
    auto push_time = chrono::duration_cast<chrono::milliseconds>(end - start);
    
    // emplace_back 测试
    start = chrono::high_resolution_clock::now();
    for (int i = 0; i < N; i++) {
        vec2.emplace_back(i);
    }
    end = chrono::high_resolution_clock::now();
    auto emplace_time = chrono::duration_cast<chrono::milliseconds>(end - start);
    
    cout << "push_back: " << push_time.count() << "ms" << endl;
    cout << "emplace_back: " << emplace_time.count() << "ms" << endl;
    // emplace_back 通常快 20-30%
}
```

## 使用场景

### 优先使用 emplace_back

1. **传递构造参数时**
   ```cpp
   vec.emplace_back(1, "name", 3.14);  // ✓
   vec.push_back(MyClass(1, "name", 3.14));  // ✗ 效率低
   ```

2. **复杂对象（拷贝/移动开销大）**
   ```cpp
   vec.emplace_back(100, 200);  // pair
   vec.emplace_back("key", "value");  // map的pair
   ```

3. **性能敏感场景**

### 使用 push_back

1. **传递已存在的对象**
   ```cpp
   MyClass obj(1, "name");
   vec.push_back(obj);  // ✓
   vec.push_back(move(obj));  // ✓ 移动语义
   ```

2. **简单类型（性能差异可忽略）**
   ```cpp
   vector<int> vec;
   vec.push_back(1);  // 简单类型，差异可忽略
   ```

3. **需要明确表达意图时**
   ```cpp
   vec.push_back(getObject());  // 更清晰
   ```

## 实现原理

### push_back 实现（简化）

```cpp
template<typename T>
void vector<T>::push_back(const T& value) {
    // 如果空间不足，扩容
    if (size_ >= capacity_) {
        reserve(capacity_ * 2);
    }
    // 拷贝构造
    new (data_ + size_) T(value);
    size_++;
}

template<typename T>
void vector<T>::push_back(T&& value) {
    if (size_ >= capacity_) {
        reserve(capacity_ * 2);
    }
    // 移动构造
    new (data_ + size_) T(move(value));
    size_++;
}
```

### emplace_back 实现（简化）

```cpp
template<typename T>
template<typename... Args>
void vector<T>::emplace_back(Args&&... args) {
    if (size_ >= capacity_) {
        reserve(capacity_ * 2);
    }
    // 直接构造，使用完美转发
    new (data_ + size_) T(forward<Args>(args)...);
    size_++;
}
```

## 注意事项

### 1. 异常安全

```cpp
// push_back: 如果移动/拷贝失败，临时对象已构造
vec.push_back(Heavy(1));  // 临时对象可能已构造

// emplace_back: 如果构造失败，没有临时对象
vec.emplace_back(1);  // 更安全
```

### 2. 显式构造函数

```cpp
class MyClass {
public:
    explicit MyClass(int x) {}  // 显式构造函数
};

vector<MyClass> vec;
// vec.push_back(1);  // ❌ 错误！需要显式转换
vec.push_back(MyClass(1));  // ✓
vec.emplace_back(1);  // ✓ emplace_back可以
```

### 3. 初始化列表

```cpp
vector<vector<int>> vec;

// push_back: 需要显式构造
vec.push_back({1, 2, 3});  // ✓ 初始化列表

// emplace_back: 也可以
vec.emplace_back(initializer_list<int>{1, 2, 3});  // ✓
```

## 总结

| 特性 | push_back | emplace_back |
|------|-----------|--------------|
| **接受参数** | 已构造对象 | 构造参数 |
| **临时对象** | 需要（传递临时对象时） | 不需要 |
| **性能** | 较慢（有移动/拷贝） | 较快（直接构造） |
| **使用场景** | 传递已存在对象 | 传递构造参数 |
| **C++版本** | C++98 | C++11 |

### 最佳实践

1. **默认使用 emplace_back**（当传递构造参数时）
2. **传递对象时使用 push_back**
3. **简单类型可忽略差异**
4. **性能敏感场景优先 emplace_back**

