# Android AMS (Activity Manager Service) 面试总结

## 一、AMS 基本概念

### 1.1 什么是 AMS
- **AMS (Activity Manager Service)** 是 Android 系统中最核心的服务之一
- 负责管理所有 Activity、Service、BroadcastReceiver 和 ContentProvider 的生命周期
- 运行在 **system_server** 进程中，是系统级服务

**AMS 在 system_server 进程中的存在形式**：
- **AMS 不是 system_server 进程中的一个线程**
- **AMS 是 system_server 进程中的一个服务对象（Service 实例）**
- system_server 进程中有多个系统服务，AMS 只是其中之一
- 这些服务都在 system_server 进程的**主线程**中运行（通过 SystemServer 的 main 方法）
- AMS 内部可能有自己的 Handler 线程来处理异步任务，但 AMS 本身不是线程

### 1.2 AMS 的主要职责
- **Activity 管理**：启动、停止、暂停、恢复 Activity
- **Service 管理**：启动、绑定、停止 Service
- **进程管理**：进程的创建、销毁、优先级调整
- **任务栈管理**：Task 和 ActivityStack 的管理
- **内存管理**：低内存时杀死进程释放内存
- **权限管理**：检查应用权限

## 二、AMS 启动流程

### 2.1 SystemServer 启动流程

SystemServer 的启动流程：
```
SystemServer.main()
    ↓
SystemServer.run()
    ↓
1. startBootstrapServices()  // 启动引导服务
    ↓
2. startCoreServices()        // 启动核心服务
    ↓
3. startOtherServices()       // 启动其他服务
```

### 2.1.1 startBootstrapServices() - 引导服务

**作用**：启动系统最基础、最核心的服务，这些服务是其他服务依赖的基础。

**启动的服务**：
1. **ActivityManagerService (AMS)**
   - 管理 Activity、Service、进程等
   - 最核心的系统服务之一

2. **PowerManagerService**
   - 电源管理服务
   - 控制屏幕、CPU 等电源相关功能

3. **DisplayManagerService**
   - 显示管理服务
   - 管理多屏显示、屏幕旋转等

4. **PackageManagerService (PMS)**
   - 包管理服务
   - 管理应用的安装、卸载、权限等

5. **UserManagerService**
   - 用户管理服务
   - 管理多用户功能

6. **BatteryService**
   - 电池服务
   - 监控电池状态

```java
// SystemServer.java
private void startBootstrapServices() {
    // 1. 启动 AMS
    mActivityManagerService = mSystemServiceManager.startService(
        ActivityManagerService.Lifecycle.class).getService();
    
    // 2. 启动 PowerManagerService
    mPowerManagerService = mSystemServiceManager.startService(PowerManagerService.class);
    
    // 3. 启动 DisplayManagerService
    mDisplayManagerService = mSystemServiceManager.startService(DisplayManagerService.class);
    
    // 4. 启动 PackageManagerService
    mPackageManagerService = PackageManagerService.main(...);
    
    // 5. 启动 UserManagerService
    mUserManagerService = mSystemServiceManager.startService(UserManagerService.Lifecycle.class);
    
    // 6. 启动 BatteryService
    mBatteryService = new BatteryService(context);
    ServiceManager.addService("battery", mBatteryService);
}
```

### 2.1.2 startCoreServices() - 核心服务

**作用**：启动系统核心功能服务，这些服务提供系统的基础功能。

**启动的服务**：
1. **BatteryStatsService**
   - 电池统计服务
   - 记录应用的电池使用情况

2. **UsageStatsService**
   - 使用统计服务
   - 记录应用的使用情况（启动次数、使用时长等）

3. **WebViewUpdateService**
   - WebView 更新服务
   - 管理 WebView 的更新

4. **DropBoxManagerService**
   - DropBox 管理服务
   - 收集系统日志和崩溃信息

5. **SystemConfig**
   - 系统配置服务
   - 管理系统配置信息

```java
// SystemServer.java
private void startCoreServices() {
    // 1. 启动 BatteryStatsService
    mSystemServiceManager.startService(BatteryStatsService.class);
    
    // 2. 启动 UsageStatsService
    mSystemServiceManager.startService(UsageStatsService.Lifecycle.class);
    
    // 3. 启动 WebViewUpdateService
    mSystemServiceManager.startService(WebViewUpdateService.class);
    
    // 4. 启动 DropBoxManagerService
    mSystemServiceManager.startService(DropBoxManagerService.class);
    
    // 5. 初始化 SystemConfig
    SystemConfig.getInstance();
}
```

### 2.1.3 startOtherServices() - 其他服务

**作用**：启动其他系统服务，这些服务提供各种系统功能。

**启动的主要服务**：

1. **窗口相关服务**：
   - **WindowManagerService (WMS)**：窗口管理服务
   - **InputManagerService**：输入管理服务（触摸、按键等）

2. **网络相关服务**：
   - **ConnectivityService**：网络连接服务
   - **NetworkManagementService**：网络管理服务
   - **NetworkStatsService**：网络统计服务

3. **存储相关服务**：
   - **MountService**：挂载服务
   - **StorageManagerService**：存储管理服务

4. **账户和同步服务**：
   - **AccountManagerService**：账户管理服务
   - **ContentService**：内容服务（同步框架）

5. **通知和系统UI服务**：
   - **NotificationManagerService**：通知管理服务
   - **StatusBarManagerService**：状态栏管理服务

6. **位置服务**：
   - **LocationManagerService**：位置管理服务

7. **传感器服务**：
   - **SensorService**：传感器服务

8. **音频服务**：
   - **AudioService**：音频服务

9. **相机服务**：
   - **CameraService**：相机服务

10. **蓝牙服务**：
    - **BluetoothManagerService**：蓝牙管理服务

11. **WiFi 服务**：
    - **WifiService**：WiFi 服务

12. **电话服务**：
    - **TelephonyRegistry**：电话注册服务

13. **锁屏和安全服务**：
    - **LockSettingsService**：锁屏设置服务
    - **DevicePolicyManagerService**：设备策略管理服务

14. **备份服务**：
    - **BackupManagerService**：备份管理服务

15. **应用相关服务**：
    - **AppWidgetService**：桌面小部件服务
    - **LauncherAppsService**：启动器应用服务

```java
// SystemServer.java
private void startOtherServices() {
    // 窗口相关
    mSystemServiceManager.startService(WindowManagerService.Lifecycle.class);
    mSystemServiceManager.startService(InputManagerService.class);
    
    // 网络相关
    mSystemServiceManager.startService(ConnectivityService.class);
    mSystemServiceManager.startService(NetworkManagementService.class);
    
    // 存储相关
    mSystemServiceManager.startService(MountService.class);
    mSystemServiceManager.startService(StorageManagerService.class);
    
    // 通知服务
    mSystemServiceManager.startService(NotificationManagerService.class);
    
    // 位置服务
    mSystemServiceManager.startService(LocationManagerService.class);
    
    // 传感器服务
    mSystemServiceManager.startService(SensorService.class);
    
    // 音频服务
    mSystemServiceManager.startService(AudioService.class);
    
    // 蓝牙服务
    mSystemServiceManager.startService(BluetoothManagerService.class);
    
    // WiFi 服务
    mSystemServiceManager.startService(WifiService.class);
    
    // ... 其他服务
}
```

### 2.1.4 服务启动顺序的重要性

**为什么分三个阶段启动**：

1. **startBootstrapServices()**：
   - 启动最基础的服务（AMS、PMS 等）
   - 这些服务是其他服务的基础依赖
   - 必须最先启动

2. **startCoreServices()**：
   - 启动核心功能服务
   - 依赖引导服务，但不需要其他服务

3. **startOtherServices()**：
   - 启动其他功能服务
   - 可能依赖引导服务和核心服务
   - 可以并行启动或按需启动

**AMS 在启动流程中的位置**：
- AMS 在 **startBootstrapServices()** 中启动
- 是最早启动的服务之一
- 其他服务（如 WMS、NotificationManagerService）在 startOtherServices() 中启动
- 这些服务启动后，会通过 AMS 注册自己的服务

### 2.2 AMS 初始化流程

AMS 在 SystemServer 启动流程中的位置：
```
SystemServer.run()
    ↓
startBootstrapServices()  // 第一阶段：引导服务
    ↓
启动 AMS (ActivityManagerService)
    ↓
startCoreServices()        // 第二阶段：核心服务
    ↓
startOtherServices()        // 第三阶段：其他服务
```

1. **创建 AMS 实例**
   - 在 SystemServer 的 `startBootstrapServices()` 中创建
   - 通过 `ActivityManagerService.Lifecycle` 启动
   - **注意**：
     - AMS 运行在 **system_server** 进程中，system_server 由 **init 进程**启动，不是由 AMS 创建的
     - AMS 是 system_server 进程中的一个**服务对象**，不是线程
     - system_server 进程的主线程负责创建和初始化所有系统服务（包括 AMS）
     - AMS 在 **startBootstrapServices()** 阶段启动，是最早启动的服务之一

2. **初始化关键组件**
   - ActivityStackSupervisor：管理 ActivityStack
   - ProcessRecord：管理进程信息
   - ActivityRecord：管理 Activity 信息
   - TaskRecord：管理任务栈
   - **Handler 线程**：AMS 内部创建 HandlerThread 来处理异步任务（如进程启动、内存回收等）

3. **注册到 ServiceManager**
   - 通过 `ServiceManager.addService()` 注册
   - 其他进程可以通过 Binder 调用 AMS
   - AMS 作为 Binder 服务端，接收来自应用进程的调用

4. **与其他服务的关系**
   - AMS 启动后，其他服务（WMS、NotificationManagerService 等）在 `startOtherServices()` 中启动
   - 这些服务启动后，会通过 AMS 注册自己的服务
   - AMS 负责管理这些服务的生命周期

## 三、Activity 启动流程

### 3.1 启动流程概览

**第一次启动应用的完整流程**：
```
1. 应用进程发起启动请求 (Activity.startActivity)
    ↓
2. AMS 处理启动请求 (ActivityManagerService.startActivity)
    ↓
3. ActivityStackSupervisor 管理 ActivityStack
    ↓
4. 创建新进程（如果不存在）
    ↓
5. 应用进程初始化 (ActivityThread.main)
    ↓
6. 应用进程注册 (attachApplication)
    → 应用进程主动调用 AMS.attachApplication(mAppThread)
    ↓
7. AMS 绑定应用 (bindApplication)
    → AMS 调用应用进程的 bindApplication()
    ↓
8. 应用进程创建 Application
    → handleBindApplication()
    → Application.onCreate()
    ↓
9. AMS 启动 Activity (realStartActivityLocked)
    → 通过 ApplicationThread.scheduleLaunchActivity()
    ↓
10. 应用进程创建 Activity (handleLaunchActivity)
    → Activity.attach()
    → Activity.onCreate()
    → Activity.onStart()
    → Activity.onResume()
    ↓
11. Activity 可见并可以交互
```

**关键步骤说明**：
- **步骤 6-8**：应用进程注册和 Application 创建
- **步骤 9-10**：AMS 启动 Activity 和应用进程执行生命周期
- 整个过程通过 Binder 进行跨进程通信

### 3.2 详细流程分析

#### 3.2.1 应用进程发起启动请求
```java
// Activity.java
public void startActivity(Intent intent) {
    startActivityForResult(intent, -1);
}

public void startActivityForResult(Intent intent, int requestCode) {
    // 通过 Instrumentation 调用
    mInstrumentation.execStartActivity(
        this, mMainThread.getApplicationThread(), ...);
}
```

#### 3.2.2 跨进程调用 AMS
```java
// Instrumentation.java
public ActivityResult execStartActivity(...) {
    // 通过 ActivityManagerNative.getDefault() 获取 AMS 的 Binder 代理
    int result = ActivityManagerNative.getDefault()
        .startActivity(whoThread, who.getBasePackageName(), ...);
}
```

#### 3.2.3 AMS 处理启动请求
```java
// ActivityManagerService.java
public final int startActivity(...) {
    return startActivityAsUser(...);
}

private int startActivityAsUser(...) {
    // 1. 检查权限
    // 2. 解析 Intent
    // 3. 创建 ActivityRecord
    // 4. 启动目标进程（如果需要）
    // 5. 调用 ActivityStackSupervisor
}
```

#### 3.2.4 ActivityStackSupervisor 处理
```java
// ActivityStackSupervisor.java
final int startActivityLocked(...) {
    // 1. 检查目标 Activity 是否存在
    // 2. 检查启动模式（LaunchMode）
    // 3. 创建或复用 Task
    // 4. 调用 ActivityStack
}
```

#### 3.2.5 启动目标进程
```java
// ActivityManagerService.java
private final void startProcessLocked(...) {
    // 1. 创建 ProcessRecord
    // 2. 调用 Process.start() 创建进程
    // 3. 绑定 ApplicationThread
}
```

#### 3.2.6 应用进程初始化
```java
// ActivityThread.java
public static void main(String[] args) {
    // 1. 创建主线程 Looper
    Looper.prepareMainLooper();
    
    // 2. 创建 ActivityThread 实例
    ActivityThread thread = new ActivityThread();
    
    // 3. 绑定 ApplicationThread 到 AMS
    thread.attach(false);
    
    // 4. 启动消息循环
    Looper.loop();
}
```

#### 3.2.7 attachApplication 和 bindApplication 的区别

**第一次启动应用时的关键步骤**：

##### ActivityThread.attachApplication() - 应用进程主动调用

**调用时机**：应用进程创建后，在 `ActivityThread.main()` 中调用 `thread.attach(false)`

**调用流程**：
```java
// ActivityThread.java
private void attach(boolean system) {
    // 获取 AMS 的 Binder 代理
    final IActivityManager mgr = ActivityManagerNative.getDefault();
    
    try {
        // 应用进程主动调用 AMS 的 attachApplication
        mgr.attachApplication(mAppThread);
    } catch (RemoteException ex) {
        // 处理异常
    }
}
```

**传递的参数**：
- **mAppThread**：`ApplicationThread` 对象（应用进程的 Binder 服务端）
  - 这是应用进程提供给 AMS 的 Binder 代理
  - AMS 通过这个代理可以回调应用进程

**作用**：
- 应用进程向 AMS **注册自己**
- 告诉 AMS："我已经准备好了，你可以通过 ApplicationThread 调用我"
- 让 AMS 知道应用进程已经创建并初始化完成

##### AMS.attachApplication() - AMS 接收注册

**调用时机**：应用进程调用 `attachApplication()` 后，AMS 接收这个调用

**AMS 处理流程**：
```java
// ActivityManagerService.java
public final void attachApplication(IApplicationThread thread) {
    synchronized (this) {
        int callingPid = Binder.getCallingPid();
        ProcessRecord app = getRecordForAppLocked(thread);
        
        if (app != null) {
            // 1. 保存 ApplicationThread 引用
            app.thread = thread;
            
            // 2. 绑定应用进程
            bindApplication(...);
            
            // 3. 启动待启动的 Activity
            if (mPendingActivityLaunches.size() > 0) {
                // 启动之前等待的 Activity
            }
        }
    }
}
```

**传递的参数**：
- **thread**：`IApplicationThread`（ApplicationThread 的 Binder 代理）
  - 这是应用进程传递过来的 Binder 代理
  - AMS 通过这个代理可以调用应用进程的方法

##### AMS.bindApplication() - AMS 主动调用应用进程

**调用时机**：AMS 在 `attachApplication()` 中接收到应用进程注册后，主动调用应用进程

**调用流程**：
```java
// ActivityManagerService.java
private final boolean bindApplication(...) {
    // 通过 ApplicationThread 的 Binder 调用应用进程
    thread.bindApplication(processName, appInfo, providers, ...);
}
```

**传递的参数**（bindApplication 的参数）：
```java
// ApplicationThread.java (应用进程的 Binder 服务端)
public final void bindApplication(String processName,
    ApplicationInfo appInfo,
    List<ProviderInfo> providers,
    ComponentName instrumentationName,
    ProfilerInfo profilerInfo,
    Bundle instrumentationArgs,
    IInstrumentationWatcher instrumentationWatcher,
    int debugMode,
    boolean enableBinderTracking,
    boolean trackAllocation,
    boolean isRestrictedBackupMode,
    PersistentBundle persistentState,
    Configuration config,
    CompatibilityInfo compatInfo,
    Map<String, IBinder> services,
    Bundle coreSettings) {
    
    // 应用进程接收这些参数并处理
}
```

**主要参数说明**：
1. **processName**：进程名称
2. **appInfo**：ApplicationInfo，包含应用的基本信息（包名、版本等）
3. **providers**：ContentProvider 列表
4. **instrumentationName**：Instrumentation 组件名（用于测试）
5. **profilerInfo**：性能分析信息
6. **instrumentationArgs**：Instrumentation 参数
7. **config**：Configuration，系统配置信息（语言、屏幕方向等）
8. **compatInfo**：CompatibilityInfo，兼容性信息
9. **services**：系统服务 Map
10. **coreSettings**：核心设置 Bundle

**作用**：
- AMS 向应用进程**传递应用信息**
- 告诉应用进程："这是你的应用信息，请根据这些信息初始化 Application"
- 应用进程根据这些参数创建 Application 实例

##### 应用进程处理 bindApplication

**处理流程**：
```java
// ActivityThread.java
private void handleBindApplication(AppBindData data) {
    // 1. 设置进程名
    Process.setArgV0(data.processName);
    
    // 2. 创建 Application 实例
    Application app = data.info.makeApplication(data.restrictedBackupMode, null);
    
    // 3. 安装 ContentProvider
    if (!data.restrictedBackupMode) {
        List<ProviderInfo> providers = data.providers;
        if (providers != null) {
            installContentProviders(app, providers);
        }
    }
    
    // 4. 调用 Application.onCreate()
    mInstrumentation.callApplicationOnCreate(app);
}
```

##### 两者的区别总结

| 对比项 | attachApplication | bindApplication |
|--------|------------------|-----------------|
| **发起方** | 应用进程（ActivityThread） | AMS |
| **调用方向** | 应用进程 → AMS | AMS → 应用进程 |
| **调用时机** | 应用进程创建后，主动注册 | AMS 收到注册后，主动绑定 |
| **传递的参数** | ApplicationThread（Binder 代理） | 应用信息（ApplicationInfo、Configuration 等） |
| **主要作用** | 应用进程向 AMS 注册自己 | AMS 向应用进程传递应用信息 |
| **后续操作** | AMS 保存 ApplicationThread 引用 | 应用进程创建 Application 实例 |

**完整流程**：
```
1. 应用进程创建
   ↓
2. ActivityThread.main() 调用 attach(false)
   ↓
3. ActivityThread.attachApplication() 
   → 应用进程主动调用 AMS.attachApplication(mAppThread)
   ↓
4. AMS.attachApplication() 
   → 保存 ApplicationThread 引用
   → 调用 bindApplication()
   ↓
5. AMS.bindApplication() 
   → 通过 ApplicationThread 调用应用进程的 bindApplication()
   ↓
6. 应用进程 handleBindApplication() 
   → 创建 Application 实例
   → 调用 Application.onCreate()
   ↓
7. AMS 启动 Activity
```

#### 3.2.8 AMS 在 attachApplication 中启动待启动的 Activity

**关键点**：在 `attachApplication()` 中，AMS 会检查是否有待启动的 Activity，如果有则立即启动。

```java
// ActivityManagerService.java
public final void attachApplication(IApplicationThread thread) {
    synchronized (this) {
        // ... 前面的代码：保存 ApplicationThread，调用 bindApplication ...
        
        // 绑定应用进程后，检查是否有待启动的 Activity
        if (mPendingActivityLaunches.size() > 0) {
            // 启动之前等待的 Activity
            for (ActivityRecord r : mPendingActivityLaunches) {
                realStartActivityLocked(r, app, true, false);
            }
            mPendingActivityLaunches.clear();
        }
    }
}
```

**为什么需要 mPendingActivityLaunches**：
- 当 AMS 需要启动 Activity 时，如果目标进程还没有创建，会先创建进程
- 在进程创建完成之前，待启动的 Activity 会被放入 `mPendingActivityLaunches`
- 当进程创建完成并调用 `attachApplication()` 后，AMS 会启动这些待启动的 Activity

#### 3.2.9 AMS.realStartActivityLocked() - 真正启动 Activity

**调用时机**：AMS 在 `attachApplication()` 中，或者直接启动 Activity 时调用

**调用流程**：
```java
// ActivityManagerService.java
final boolean realStartActivityLocked(ActivityRecord r,
        ProcessRecord app, boolean andResume, boolean checkConfig) {
    
    // 1. 设置进程信息
    r.app = app;
    app.waitingToKill = null;
    
    // 2. 创建 Activity 启动参数
    ActivityClientRecord clientRecord = new ActivityClientRecord();
    clientRecord.token = r.appToken;
    clientRecord.ident = app.addActivity(r);
    clientRecord.intent = r.intent;
    clientRecord.activityInfo = r.activityInfo;
    clientRecord.config = mConfiguration;
    // ... 其他参数 ...
    
    // 3. 通过 ApplicationThread 调用应用进程
    app.thread.scheduleLaunchActivity(
        clientRecord.intent,
        clientRecord.token,
        clientRecord.ident,
        clientRecord.activityInfo,
        clientRecord.config,
        clientRecord.compatInfo,
        // ... 其他参数 ...
    );
    
    return true;
}
```

**传递的参数（scheduleLaunchActivity 的参数）**：
- **intent**：启动 Activity 的 Intent
- **token**：ActivityRecord 的 token（IBinder），用于标识 Activity
- **ident**：Activity 的唯一标识
- **info**：ActivityInfo，Activity 的信息（类名、主题等）
- **curConfig**：当前 Configuration（语言、屏幕方向等）
- **compatInfo**：兼容性信息
- **state**：保存的状态（如果有，用于恢复 Activity 状态）
- **procState**：进程状态

#### 3.2.10 应用进程执行生命周期

**调用流程**：
```java
// ActivityThread.java
private void handleLaunchActivity(ActivityClientRecord r, Intent customIntent) {
    // 1. 创建 Activity 实例
    Activity activity = null;
    try {
        java.lang.ClassLoader cl = r.packageInfo.getClassLoader();
        activity = mInstrumentation.newActivity(
            cl, component.getClassName(), r.intent);
    } catch (Exception e) {
        // 处理异常
    }
    
    // 2. 创建 Application（如果还没有，通常已经在 bindApplication 中创建）
    Application app = r.packageInfo.makeApplication(false, mInstrumentation);
    
    // 3. 创建 Context
    Context appContext = createBaseContextForActivity(r, activity);
    
    // 4. 调用 Activity.attach()
    activity.attach(appContext, this, getInstrumentation(), r.token,
        r.ident, app, r.intent, r.activityInfo, ...);
    
    // 5. 调用 Activity.onCreate()
    if (r.isPersistable()) {
        mInstrumentation.callActivityOnCreate(activity, r.state, r.persistentState);
    } else {
        mInstrumentation.callActivityOnCreate(activity, r.state);
    }
    
    // 6. 调用 Activity.onStart()
    activity.performStart();
    
    // 7. 调用 Activity.onResume()
    mInstrumentation.callActivityOnResume(activity);
}
```

**生命周期执行顺序**：
```
Activity.attach()      // 绑定 Context 和 Window
    ↓
Activity.onCreate()    // 初始化 Activity
    ↓
Activity.onStart()      // Activity 可见但不可交互
    ↓
Activity.onResume()    // Activity 可见且可交互
```

**关键点**：
- **Activity.attach()**：在 onCreate 之前调用，绑定 Context、Window 等
- **Application 复用**：Application 在 bindApplication 中已创建，这里通常直接复用
- **状态恢复**：如果 Activity 有保存的状态，会在 onCreate 中恢复
- **所有操作在主线程**：Activity 的创建和生命周期都在应用进程的主线程中执行

## 四、AMS 核心功能详解

### 4.1 Activity 栈管理

#### 4.1.1 ActivityStack
- **作用**：管理 Activity 的栈结构
- **类型**：
  - **HomeStack**：桌面应用栈
  - **ApplicationStack**：应用栈
  - **RecentsStack**：最近任务栈

#### 4.1.2 TaskRecord（任务记录）
- **作用**：管理一个任务（Task），一个任务对应一个 TaskRecord
- **任务（Task）的概念**：
  - 任务是一组 Activity 的集合，这些 Activity 按照启动顺序形成一个栈结构
  - 用户可以通过返回键在同一个 Task 中导航
  - 不同应用的 Activity 可以属于同一个 Task（通过 taskAffinity 属性）

**TaskRecord 的结构**：
```
TaskRecord {
    taskId: 唯一标识一个任务
    rootActivity: 任务栈底部的 Activity（第一个启动的 Activity）
    mActivities: List<ActivityRecord>  // 任务中的所有 Activity，按栈结构排列
    affinity: 任务的 affinity（用于任务归属判断）
    userId: 用户 ID
}
```

**任务栈的栈结构**：
- 任务栈是一个**后进先出（LIFO）**的栈结构
- 新启动的 Activity 放在栈顶
- 返回键会移除栈顶的 Activity，显示下一个 Activity
- 栈底是任务的根 Activity（rootActivity）

**TaskRecord 与用户操作的对应关系**：

1. **启动 Activity 时**：
   ```
   用户操作：点击应用图标启动 Activity A
   → AMS 创建新的 TaskRecord（如果不存在）
   → 创建 ActivityRecord A，放入 TaskRecord 的栈顶
   → TaskRecord.mActivities = [A]
   ```

2. **在同一个 Task 中启动新 Activity**：
   ```
   用户操作：在 Activity A 中启动 Activity B
   → 找到当前的 TaskRecord
   → 创建 ActivityRecord B，放入栈顶
   → TaskRecord.mActivities = [A, B]  // B 在栈顶
   ```

3. **按返回键**：
   ```
   用户操作：在 Activity B 中按返回键
   → AMS 找到当前 TaskRecord
   → 移除栈顶的 ActivityRecord B（调用 onDestroy）
   → 恢复栈顶的 ActivityRecord A（调用 onResume）
   → TaskRecord.mActivities = [A]
   ```

4. **多任务切换**：
   ```
   用户操作：按多任务键，切换到另一个应用
   → AMS 找到对应的 TaskRecord
   → 将当前 TaskRecord 移到后台
   → 激活目标 TaskRecord，显示其栈顶 Activity
   ```

5. **从其他应用返回**：
   ```
   用户操作：从应用 B 返回到应用 A
   → AMS 找到应用 A 的 TaskRecord
   → 恢复该 TaskRecord 的栈顶 Activity
   → 如果 TaskRecord 被系统回收，需要重新创建
   ```

**实际例子**：

**场景 1：微信聊天流程**
```
1. 用户点击微信图标
   → 创建 TaskRecord(taskId=1)
   → 启动 MainActivity（微信主界面）
   → TaskRecord.mActivities = [MainActivity]

2. 用户点击某个聊天
   → 在 TaskRecord(taskId=1) 中启动 ChatActivity
   → TaskRecord.mActivities = [MainActivity, ChatActivity]

3. 用户在聊天中点击图片
   → 在 TaskRecord(taskId=1) 中启动 ImageViewActivity
   → TaskRecord.mActivities = [MainActivity, ChatActivity, ImageViewActivity]

4. 用户按返回键
   → 移除 ImageViewActivity
   → TaskRecord.mActivities = [MainActivity, ChatActivity]
   → 显示 ChatActivity

5. 用户再按返回键
   → 移除 ChatActivity
   → TaskRecord.mActivities = [MainActivity]
   → 显示 MainActivity
```

**场景 2：跨应用启动（浏览器打开链接）**
```
1. 用户在微信中点击链接
   → 浏览器应用启动 BrowserActivity
   → 如果浏览器没有运行，创建新的 TaskRecord(taskId=2)
   → 如果浏览器正在运行，使用现有的 TaskRecord
   → TaskRecord(taskId=2).mActivities = [BrowserActivity]

2. 用户在浏览器中按返回键
   → 如果浏览器 TaskRecord 中只有一个 Activity
   → 返回到微信的 TaskRecord(taskId=1)
   → 显示微信的栈顶 Activity
```

**场景 3：多任务管理**
```
系统中有多个 TaskRecord：
- TaskRecord(taskId=1): [微信 MainActivity, ChatActivity]
- TaskRecord(taskId=2): [浏览器 BrowserActivity]
- TaskRecord(taskId=3): [音乐 MusicActivity]

用户按多任务键：
→ 显示所有 TaskRecord 的缩略图
→ 用户选择某个 TaskRecord
→ AMS 激活该 TaskRecord，显示其栈顶 Activity
```

**TaskRecord 的关键属性**：
- **taskId**：任务的唯一标识，用于区分不同的任务
- **affinity**：任务的 affinity，决定 Activity 应该归属哪个 Task
- **rootActivity**：任务的根 Activity，通常是第一个启动的 Activity
- **mActivities**：任务中的所有 Activity，按栈结构排列

#### 4.1.3 ActivityRecord
- **作用**：表示一个 Activity 实例
- **包含信息**：
  - Activity 的 Intent
  - Activity 的状态（CREATED, STARTED, RESUMED 等）
  - Activity 的配置信息

### 4.2 启动模式（LaunchMode）

#### 4.2.1 Standard（标准模式）
- **特点**：每次启动都创建新实例
- **使用场景**：大多数 Activity

#### 4.2.2 SingleTop（栈顶复用）
- **特点**：如果 Activity 在栈顶，则复用，否则创建新实例
- **使用场景**：通知栏点击、推送消息

#### 4.2.3 SingleTask（栈内复用）
- **特点**：在栈内只存在一个实例，如果已存在则清除其上的所有 Activity
- **使用场景**：主界面、登录页

#### 4.2.4 SingleInstance（单例模式）
- **特点**：整个系统只有一个实例，独占一个 Task
- **使用场景**：通话界面、Launcher

### 4.3 进程管理

#### 4.3.1 进程优先级
1. **Foreground Process**（前台进程）
   - 正在与用户交互的 Activity
   - 优先级：最高

2. **Visible Process**（可见进程）
   - Activity 可见但不在前台
   - 优先级：高

3. **Service Process**（服务进程）
   - 正在运行 Service
   - 优先级：中

4. **Background Process**（后台进程）
   - Activity 不可见
   - 优先级：低

5. **Empty Process**（空进程）
   - 没有组件在运行
   - 优先级：最低

#### 4.3.2 进程回收策略（Low Memory Killer）
- **OOM_ADJ**：进程优先级值，值越大越容易被杀死
- **内存阈值**：系统根据可用内存决定杀死哪些进程
- **回收顺序**：从低优先级到高优先级

#### 4.3.3 AMS 管理的进程类型

##### AMS 创建的进程
AMS 会在以下情况下创建新进程：

1. **应用进程（Application Process）**
   - 启动 Activity 时，如果目标应用进程不存在
   - 启动 Service 时，如果目标应用进程不存在
   - 启动 ContentProvider 时，如果目标应用进程不存在
   - 接收 BroadcastReceiver 时，如果目标应用进程不存在

2. **特殊进程**
   - **persistent 进程**：在 AndroidManifest.xml 中声明 `android:persistent="true"` 的进程
   - **isolated 进程**：隔离进程，用于运行不受信任的代码

**注意**：
- **system_server** 和 **zygote** 不是由 AMS 创建的
- **system_server** 由 **init 进程**启动，AMS 运行在 system_server 进程中
- **zygote** 也由 **init 进程**启动，AMS 通过 zygote 来 fork 应用进程
- AMS 主要负责创建和管理**应用进程**，而不是系统进程

##### AMS 销毁的进程
AMS 会在以下情况下销毁进程：

1. **正常销毁**
   - 应用主动调用 `finish()` 或 `System.exit()`
   - 所有 Activity 都 finish，且没有 Service 在运行
   - 用户强制停止应用

2. **异常销毁**
   - 应用崩溃（ANR、未捕获异常）
   - 内存不足时被 Low Memory Killer 杀死
   - 系统资源不足

3. **系统回收**
   - 低内存时杀死后台进程
   - 系统重启或关机

##### Linux 原生进程与 AMS 管理的关系

**AMS 管理的进程范围**：
AMS **只管理 Android 应用进程**，包括：
- 通过 Android 应用框架启动的进程（Activity、Service、ContentProvider、BroadcastReceiver）
- 在 AndroidManifest.xml 中声明的进程
- persistent 进程（虽然由 init 启动，但会被 AMS 管理）

**AMS 不管理的进程**：
以下 Linux 原生进程**不会被 AMS 销毁**：

1. **系统核心进程**
   - **init 进程**（PID 1）：系统第一个进程，永远不会被杀死
   - **kernel 线程**：内核线程，由内核管理
   - **system_server**：虽然运行 AMS，但不由 AMS 管理，由 init 管理
   - **zygote**：由 init 管理，AMS 通过它 fork 应用进程

2. **原生 Linux 进程**
   - 通过 `fork()`、`exec()` 直接创建的进程
   - 通过 shell 命令启动的进程（如 `adb shell` 启动的进程）
   - 通过 JNI 调用 `fork()` 创建的进程（如果不在 Android 框架管理下）
   - 原生守护进程（daemon）

3. **特殊系统进程**
   - **surfaceflinger**：图形合成服务
   - **servicemanager**：Binder 服务管理器
   - **vold**：存储管理服务
   - 其他系统服务进程

**进程管理机制**：
- **AMS 管理**：通过 ProcessRecord 记录，可以调整 OOM_ADJ，可以主动杀死
- **Linux 原生进程**：由 init 进程或父进程管理，AMS 无法直接控制
- **Low Memory Killer**：虽然可以杀死任何进程（包括原生进程），但 AMS 只负责调整应用进程的 OOM_ADJ

**总结**：
- **Linux 原生进程不会被 AMS 销毁**，它们由 init 进程或父进程管理
- **AMS 只管理 Android 应用进程**，这些进程通过 Android 框架启动
- 即使原生进程内存占用高，AMS 也无法直接杀死，只能由系统级的 Low Memory Killer 处理

##### AMS 调整 OOM_ADJ 的进程

AMS 会根据进程状态动态调整 OOM_ADJ 值，影响进程被回收的优先级：

1. **前台进程（OOM_ADJ = 0）**
   - 正在与用户交互的 Activity 所在进程
   - 正在执行 `onReceive()` 的 BroadcastReceiver 所在进程
   - 正在执行 `onStart()`、`onCreate()`、`onDestroy()` 的 Service 所在进程

2. **可见进程（OOM_ADJ = 100）**
   - Activity 可见但不在前台（如对话框后面的 Activity）
   - 绑定到可见 Activity 的 Service

3. **服务进程（OOM_ADJ = 200-500）**
   - 正在运行 Service 的进程
   - 根据 Service 的重要性调整 ADJ 值
   - **前台 Service**：OOM_ADJ = 200
   - **普通 Service**：OOM_ADJ = 400-500

4. **后台进程（OOM_ADJ = 600-700）**
   - Activity 不可见但进程仍存在
   - 没有 Service 在运行
   - **缓存进程**：OOM_ADJ = 700

5. **空进程（OOM_ADJ = 800-900）**
   - 没有任何组件在运行
   - 仅保留进程结构，用于快速启动
   - **空进程**：OOM_ADJ = 900

6. **系统进程（OOM_ADJ < 0）**
   - **system_server**：OOM_ADJ = -900
   - **persistent 进程**：OOM_ADJ = -800
   - **核心系统进程**：OOM_ADJ = -1000（永远不会被杀死）

##### OOM_ADJ 调整时机

AMS 会在以下时机调整进程的 OOM_ADJ：

1. **Activity 状态变化**
   - Activity 进入前台：降低 ADJ（提高优先级）
   - Activity 进入后台：提高 ADJ（降低优先级）
   - Activity 不可见：进一步提高 ADJ

2. **Service 状态变化**
   - Service 启动：降低 ADJ
   - Service 停止：提高 ADJ
   - Service 绑定到前台 Activity：进一步降低 ADJ

3. **内存压力**
   - 系统内存不足时，批量调整进程 ADJ
   - 根据进程重要性重新计算 ADJ

4. **进程优先级变化**
   - 通过 `setProcessImportant()` 设置进程重要性
   - 通过 `setProcessLimit()` 限制进程数量

### 4.4 内存管理

#### 4.4.1 内存监控
- **meminfo**：监控系统内存使用情况
- **dumpsys meminfo**：查看进程内存详情

#### 4.4.2 内存回收
- **onTrimMemory()**：通知应用释放内存
- **onLowMemory()**：低内存回调
- **killProcess()**：杀死进程释放内存

## 五、常见面试问题

### 5.1 SystemServer 启动流程
**问题**：SystemServer 的 main()->run() 调用过程中会启动哪些服务？startBootstrapServices、startCoreServices、startOtherServices 分别启动哪些服务？

**答案要点**：

**SystemServer 启动流程**：
1. `SystemServer.main()` → `SystemServer.run()`
2. `startBootstrapServices()` - 引导服务
3. `startCoreServices()` - 核心服务
4. `startOtherServices()` - 其他服务

**startBootstrapServices() - 引导服务**：
- **ActivityManagerService (AMS)**：管理 Activity、Service、进程
- **PowerManagerService**：电源管理
- **DisplayManagerService**：显示管理
- **PackageManagerService (PMS)**：包管理
- **UserManagerService**：用户管理
- **BatteryService**：电池服务

**startCoreServices() - 核心服务**：
- **BatteryStatsService**：电池统计
- **UsageStatsService**：使用统计
- **WebViewUpdateService**：WebView 更新
- **DropBoxManagerService**：日志收集
- **SystemConfig**：系统配置

**startOtherServices() - 其他服务**：
- **窗口服务**：WindowManagerService、InputManagerService
- **网络服务**：ConnectivityService、NetworkManagementService
- **存储服务**：MountService、StorageManagerService
- **通知服务**：NotificationManagerService
- **位置服务**：LocationManagerService
- **传感器服务**：SensorService
- **音频服务**：AudioService
- **蓝牙服务**：BluetoothManagerService
- **WiFi 服务**：WifiService
- **其他服务**：锁屏、备份、应用相关服务等

**启动顺序的重要性**：
- 引导服务必须最先启动（AMS、PMS 等）
- 核心服务依赖引导服务
- 其他服务可能依赖前两个阶段的服务

### 5.2 Activity 启动流程
**问题**：请详细说明 Activity 的启动流程。

**答案要点**：
1. 应用进程调用 `startActivity()`
2. 通过 Binder 跨进程调用 AMS
3. AMS 检查权限、解析 Intent
4. ActivityStackSupervisor 管理 ActivityStack
5. 创建或复用进程
6. 通过 ApplicationThread 通知应用进程
7. ActivityThread 执行生命周期方法

### 5.2.1 attachApplication 和 bindApplication 的区别
**问题**：第一次启动应用过程中，ActivityThread 发起的 attachApplication 和 AMS 发起的 bindApplication 的区别，各自传递的参数是什么？

**答案要点**：

**attachApplication - 应用进程主动调用 AMS**：
1. **发起方**：应用进程（ActivityThread）
2. **调用时机**：应用进程创建后，在 `ActivityThread.main()` 中调用 `thread.attach(false)`
3. **调用方向**：应用进程 → AMS
4. **传递的参数**：
   - **mAppThread**：`ApplicationThread` 对象（应用进程的 Binder 服务端）
   - 这是应用进程提供给 AMS 的 Binder 代理
5. **作用**：
   - 应用进程向 AMS **注册自己**
   - 告诉 AMS："我已经准备好了，你可以通过 ApplicationThread 调用我"
   - 让 AMS 知道应用进程已经创建并初始化完成

**bindApplication - AMS 主动调用应用进程**：
1. **发起方**：AMS
2. **调用时机**：AMS 在 `attachApplication()` 中接收到应用进程注册后
3. **调用方向**：AMS → 应用进程
4. **传递的参数**：
   - **processName**：进程名称
   - **appInfo**：ApplicationInfo（应用基本信息：包名、版本等）
   - **providers**：ContentProvider 列表
   - **instrumentationName**：Instrumentation 组件名
   - **profilerInfo**：性能分析信息
   - **config**：Configuration（系统配置：语言、屏幕方向等）
   - **compatInfo**：CompatibilityInfo（兼容性信息）
   - **services**：系统服务 Map
   - **coreSettings**：核心设置 Bundle
5. **作用**：
   - AMS 向应用进程**传递应用信息**
   - 告诉应用进程："这是你的应用信息，请根据这些信息初始化 Application"
   - 应用进程根据这些参数创建 Application 实例

**完整流程**：
```
1. 应用进程创建
   ↓
2. ActivityThread.main() → attach(false)
   ↓
3. ActivityThread.attachApplication() 
   → 应用进程主动调用 AMS.attachApplication(mAppThread)
   ↓
4. AMS.attachApplication() 
   → 保存 ApplicationThread 引用
   → 调用 bindApplication()
   ↓
5. AMS.bindApplication() 
   → 通过 ApplicationThread 调用应用进程的 bindApplication()
   ↓
6. 应用进程 handleBindApplication() 
   → 创建 Application 实例
   → 调用 Application.onCreate()
   ↓
7. AMS 启动 Activity（见下方详细流程）
```

##### 第6步之后：AMS 启动 Activity 的流程

**在 Application.onCreate() 完成后，AMS 会启动之前等待的 Activity**：

**7. AMS 检查并启动待启动的 Activity**
```java
// ActivityManagerService.java
public final void attachApplication(IApplicationThread thread) {
    synchronized (this) {
        // ... 前面的代码 ...
        
        // 绑定应用进程
        bindApplication(...);
        
        // 检查是否有待启动的 Activity
        if (mPendingActivityLaunches.size() > 0) {
            // 启动之前等待的 Activity
            for (ActivityRecord r : mPendingActivityLaunches) {
                realStartActivityLocked(r, app, true, false);
            }
            mPendingActivityLaunches.clear();
        }
    }
}
```

**8. AMS.realStartActivityLocked() - 真正启动 Activity**
```java
// ActivityManagerService.java
final boolean realStartActivityLocked(ActivityRecord r,
        ProcessRecord app, boolean andResume, boolean checkConfig) {
    
    // 1. 设置进程信息
    r.app = app;
    app.waitingToKill = null;
    
    // 2. 创建 Activity 启动参数
    ActivityClientRecord clientRecord = new ActivityClientRecord();
    clientRecord.token = r.appToken;
    clientRecord.ident = app.addActivity(r);
    clientRecord.intent = r.intent;
    clientRecord.activityInfo = r.activityInfo;
    // ... 其他参数 ...
    
    // 3. 通过 ApplicationThread 调用应用进程
    app.thread.scheduleLaunchActivity(...);
    
    return true;
}
```

**传递的参数（scheduleLaunchActivity 的参数）**：
```java
// ApplicationThread.java
public final void scheduleLaunchActivity(Intent intent, IBinder token,
    int ident, ActivityInfo info, Configuration curConfig,
    CompatibilityInfo compatInfo, String referrer, IVoiceInteractor voiceInteractor,
    int procState, Bundle state, PersistableBundle persistentState,
    List<ResultInfo> pendingResults, List<ReferrerIntent> pendingNewIntents,
    boolean notResumed, boolean isForward, ProfilerInfo profilerInfo) {
    
    // 发送消息到 ActivityThread 的 Handler
    sendMessage(H.LAUNCH_ACTIVITY, r);
}
```

**主要参数说明**：
1. **intent**：启动 Activity 的 Intent
2. **token**：ActivityRecord 的 token（IBinder），用于标识 Activity
3. **ident**：Activity 的唯一标识
4. **info**：ActivityInfo，Activity 的信息（类名、主题等）
5. **curConfig**：当前 Configuration
6. **compatInfo**：兼容性信息
7. **state**：保存的状态（如果有）
8. **procState**：进程状态

**9. 应用进程处理启动 Activity**
```java
// ActivityThread.java
private void handleLaunchActivity(ActivityClientRecord r, Intent customIntent) {
    // 1. 创建 Activity 实例
    Activity activity = null;
    try {
        java.lang.ClassLoader cl = r.packageInfo.getClassLoader();
        activity = mInstrumentation.newActivity(
            cl, component.getClassName(), r.intent);
    } catch (Exception e) {
        // 处理异常
    }
    
    // 2. 创建 Application（如果还没有）
    Application app = r.packageInfo.makeApplication(false, mInstrumentation);
    
    // 3. 创建 Context
    Context appContext = createBaseContextForActivity(r, activity);
    
    // 4. 调用 Activity.attach()
    activity.attach(appContext, this, getInstrumentation(), r.token,
        r.ident, app, r.intent, r.activityInfo, ...);
    
    // 5. 调用 Activity.onCreate()
    if (r.isPersistable()) {
        mInstrumentation.callActivityOnCreate(activity, r.state, r.persistentState);
    } else {
        mInstrumentation.callActivityOnCreate(activity, r.state);
    }
    
    // 6. 调用 Activity.onStart()
    activity.performStart();
    
    // 7. 调用 Activity.onResume()
    mInstrumentation.callActivityOnResume(activity);
}
```

**10. Activity 生命周期执行**
```
Activity.onCreate()
    ↓
Activity.onStart()
    ↓
Activity.onResume()
    ↓
Activity 可见并可以交互
```

**完整流程总结**：
```
1. 应用进程创建
   ↓
2. ActivityThread.main() → attach(false)
   ↓
3. ActivityThread.attachApplication() 
   → 应用进程主动调用 AMS.attachApplication(mAppThread)
   ↓
4. AMS.attachApplication() 
   → 保存 ApplicationThread 引用
   → 调用 bindApplication()
   ↓
5. AMS.bindApplication() 
   → 通过 ApplicationThread 调用应用进程的 bindApplication()
   ↓
6. 应用进程 handleBindApplication() 
   → 创建 Application 实例
   → 调用 Application.onCreate()
   ↓
7. AMS 检查待启动的 Activity
   → 如果有，调用 realStartActivityLocked()
   ↓
8. AMS.realStartActivityLocked()
   → 创建 ActivityClientRecord
   → 通过 ApplicationThread.scheduleLaunchActivity() 调用应用进程
   ↓
9. 应用进程 handleLaunchActivity()
   → 创建 Activity 实例
   → 调用 Activity.attach()
   → 调用 Activity.onCreate()
   → 调用 Activity.onStart()
   → 调用 Activity.onResume()
   ↓
10. Activity 可见并可以交互
```

**关键点**：
- **Application.onCreate()** 在 Activity 启动**之前**执行
- AMS 在 Application 创建完成后，才会启动 Activity
- Activity 的创建和生命周期都在应用进程的主线程中执行
- 整个过程通过 Binder 进行跨进程通信

**关键区别**：
- **attachApplication**：应用进程注册，传递 ApplicationThread
- **bindApplication**：AMS 绑定应用，传递应用信息

### 5.3 AMS 如何管理 Activity 栈
**问题**：AMS 是如何管理 Activity 栈的？

**答案要点**：
1. **ActivityStackSupervisor**：管理多个 ActivityStack
2. **ActivityStack**：管理 TaskRecord 和 ActivityRecord
3. **TaskRecord**：管理一个任务中的多个 Activity
4. **ActivityRecord**：表示一个 Activity 实例

### 5.3.1 TaskRecord 与用户操作的对应关系
**问题**：TaskRecord 管理任务栈具体是什么，怎么和用户的操作对应起来？

**答案要点**：

**TaskRecord 的概念**：
1. **TaskRecord 管理一个任务（Task）**：
   - 任务是一组 Activity 的集合，按启动顺序形成栈结构
   - 每个任务对应一个 TaskRecord
   - TaskRecord 包含：taskId、rootActivity、mActivities 列表

2. **任务栈的栈结构**：
   - 后进先出（LIFO）结构
   - 新启动的 Activity 放在栈顶
   - 返回键移除栈顶 Activity

**与用户操作的对应**：
1. **启动 Activity**：
   - 创建或找到 TaskRecord
   - 创建 ActivityRecord，放入栈顶

2. **按返回键**：
   - 移除栈顶 ActivityRecord
   - 恢复下一个 ActivityRecord

3. **多任务切换**：
   - 找到对应的 TaskRecord
   - 激活该 TaskRecord，显示栈顶 Activity

4. **跨应用启动**：
   - 根据 taskAffinity 决定归属哪个 TaskRecord
   - 可能创建新 TaskRecord 或使用现有 TaskRecord

**实际例子**：
- 微信聊天：MainActivity → ChatActivity → ImageViewActivity
- 返回键操作：依次移除栈顶 Activity
- 多任务：每个应用对应一个或多个 TaskRecord

### 5.4 LaunchMode 的区别
**问题**：四种 LaunchMode 的区别和使用场景？

**答案要点**：
- **Standard**：每次都创建新实例
- **SingleTop**：栈顶复用
- **SingleTask**：栈内复用，清除其上 Activity
- **SingleInstance**：单例，独占 Task

### 5.5 进程优先级如何影响进程回收
**问题**：进程优先级如何影响系统的进程回收策略？

**答案要点**：
1. 进程优先级从高到低：Foreground > Visible > Service > Background > Empty
2. Low Memory Killer 根据 OOM_ADJ 值决定回收顺序
3. 低优先级进程先被回收
4. 前台进程最后被回收

### 5.6 Binder 在 AMS 中的作用
**问题**：Binder 在 AMS 中是如何使用的？

**答案要点**：
1. **AMS 作为服务端**：运行在 system_server 进程
2. **应用进程作为客户端**：通过 Binder 调用 AMS
3. **ApplicationThread**：应用进程的 Binder 服务端，AMS 可以回调
4. **跨进程通信**：Activity 启动、生命周期管理都通过 Binder

### 5.7 Activity 生命周期与 AMS 的关系
**问题**：Activity 的生命周期是如何与 AMS 交互的？

**答案要点**：
1. AMS 通过 ApplicationThread 通知应用进程
2. ActivityThread 的 Handler 处理消息
3. 执行对应的生命周期方法
4. 应用进程通过 Binder 通知 AMS 状态变化

### 5.8 多任务管理
**问题**：Android 如何实现多任务管理？

**答案要点**：
1. **TaskRecord**：每个任务一个 TaskRecord
2. **RecentTasks**：管理最近任务列表
3. **ActivityStack**：不同任务在不同栈中
4. **Task 切换**：通过 ActivityStackSupervisor 切换

### 5.9 内存不足时的处理
**问题**：系统内存不足时，AMS 如何处理？

**答案要点**：
1. 监控系统内存使用情况
2. 调用 `onTrimMemory()` 通知应用释放内存
3. 根据进程优先级杀死进程
4. 优先杀死低优先级进程（Background、Empty）

### 5.10 AMS 管理的进程类型
**问题**：AMS 创建、销毁、调整 adj 的进程有哪些？

**答案要点**：

**AMS 创建的进程**：
1. **应用进程**：启动 Activity、Service、ContentProvider、BroadcastReceiver 时创建
2. **特殊进程**：persistent 进程、isolated 进程

**注意**：system_server 和 zygote 不是 AMS 创建的，它们由 init 进程启动。AMS 运行在 system_server 进程中，通过 zygote 来 fork 应用进程。

**AMS 销毁的进程**：
1. **正常销毁**：应用主动 finish、所有组件结束
2. **异常销毁**：应用崩溃、ANR
3. **系统回收**：低内存时被杀死

**AMS 调整 OOM_ADJ 的进程**：
1. **前台进程**（ADJ=0）：正在交互的 Activity
2. **可见进程**（ADJ=100）：可见但不在前台的 Activity
3. **服务进程**（ADJ=200-500）：运行 Service 的进程
4. **后台进程**（ADJ=600-700）：Activity 不可见
5. **空进程**（ADJ=800-900）：无组件运行
6. **系统进程**（ADJ<0）：system_server、persistent 进程

**调整时机**：
- Activity 状态变化（前台/后台/不可见）
- Service 状态变化（启动/停止/绑定）
- 内存压力时批量调整
- 进程优先级变化

### 5.11 Linux 原生进程与 AMS 管理
**问题**：Linux 创建的进程，会不会被 AMS 销毁？

**答案要点**：

**AMS 不管理 Linux 原生进程**：
1. **AMS 只管理 Android 应用进程**：
   - 通过 Android 框架启动的进程（Activity、Service 等）
   - 在 AndroidManifest.xml 中声明的进程

2. **Linux 原生进程不会被 AMS 销毁**：
   - **init 进程**：系统第一个进程，由内核管理
   - **system_server、zygote**：由 init 管理
   - **原生守护进程**：由 init 或父进程管理
   - **通过 shell 启动的进程**：不受 AMS 管理
   - **通过 JNI fork 的进程**：如果不在 Android 框架下，不受 AMS 管理

3. **进程管理机制**：
   - AMS 通过 ProcessRecord 管理应用进程
   - Linux 原生进程由 init 或父进程管理
   - Low Memory Killer 可以杀死任何进程，但 AMS 只负责调整应用进程的 OOM_ADJ

**总结**：Linux 原生进程不会被 AMS 销毁，它们由系统级进程管理器（如 init）管理。

### 5.12 AMS 在 system_server 进程中的存在形式
**问题**：AMS 是不是 system_server 进程中的一个线程？

**答案要点**：

**AMS 不是线程，而是服务对象**：
1. **AMS 是 system_server 进程中的一个服务实例**：
   - AMS 是 `ActivityManagerService` 类的实例对象
   - 在 SystemServer 的 `startBootstrapServices()` 中创建
   - 作为系统服务注册到 ServiceManager

2. **system_server 进程的结构**：
   - system_server 进程有**一个主线程**（SystemServer.main）
   - 主线程负责创建和初始化所有系统服务（AMS、WMS、PMS 等）
   - 这些服务对象都在主线程中创建，但可以有自己的 Handler 线程

3. **AMS 的线程模型**：
   - AMS 的主要逻辑在 system_server 的**主线程**中执行
   - AMS 内部创建 **HandlerThread** 来处理异步任务
   - 如：进程启动、内存回收、ANR 检测等异步操作

4. **与其他服务的关系**：
   - system_server 进程中有多个系统服务：AMS、WMS、PMS、PMS 等
   - 它们都是服务对象，不是独立的线程
   - 都在 system_server 进程的主线程中初始化

**总结**：
- AMS 是 system_server 进程中的一个**服务对象**，不是线程
- system_server 进程的主线程负责创建和运行所有系统服务
- AMS 内部可能有自己的 Handler 线程处理异步任务，但 AMS 本身不是线程

## 六、关键类和方法

### 6.1 核心类
- **ActivityManagerService**：AMS 主类
- **ActivityStackSupervisor**：管理 ActivityStack
- **ActivityStack**：管理 Activity 栈
- **TaskRecord**：任务记录
- **ActivityRecord**：Activity 记录
- **ProcessRecord**：进程记录
- **ActivityThread**：应用主线程
- **ApplicationThread**：应用进程的 Binder 服务端

### 6.2 关键方法
- `startActivity()`：启动 Activity
- `startActivityAsUser()`：以指定用户启动
- `startProcessLocked()`：启动进程
- `realStartActivityLocked()`：真正启动 Activity
- `scheduleLaunchActivity()`：调度启动 Activity
- `handleLaunchActivity()`：处理启动 Activity

## 七、性能优化相关

### 7.1 Activity 启动优化
- **冷启动优化**：减少 Application 初始化时间
- **热启动优化**：复用进程和 Activity
- **预加载**：预加载常用 Activity

### 7.2 内存优化
- **及时释放**：Activity 不可见时释放资源
- **避免内存泄漏**：注意 Context、Handler 的使用
- **图片优化**：合理使用图片缓存

## 八、总结

AMS 是 Android 系统的核心服务，负责：
1. **Activity 生命周期管理**
2. **进程管理和调度**
3. **内存管理和回收**
4. **任务栈管理**
5. **权限检查**

理解 AMS 的工作原理对于：
- 优化应用性能
- 解决内存问题
- 理解 Activity 启动流程
- 处理多任务场景

都非常重要。

