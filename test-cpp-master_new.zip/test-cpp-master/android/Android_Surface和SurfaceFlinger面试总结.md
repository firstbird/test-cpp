# Android Surface 和 SurfaceFlinger 面试总结

## 一、基本概念

### 1.1 什么是 Surface

- **Surface** 是 Android 图形系统中的核心概念
- 代表一个**绘图表面**，应用程序可以在上面绘制内容
- 每个 Activity 都有一个 Surface，用于显示 UI
- Surface 是应用层和系统层之间的桥梁

### 1.2 Surface 的作用

- **提供绘图缓冲区**：应用程序在 Surface 上绘制内容
- **管理图形缓冲区**：Surface 管理多个 Buffer（双缓冲或三缓冲）
- **与 SurfaceFlinger 通信**：通过 Surface 将绘制的内容提交给 SurfaceFlinger 合成显示

### 1.3 什么是 SurfaceFlinger

- **SurfaceFlinger** 是 Android 系统的图形合成服务
- 运行在 **system_server** 进程中（或独立进程，取决于版本）
- 负责将多个 Surface 的内容**合成**到屏幕上
- 是 Android 图形系统的核心服务

### 1.4 SurfaceFlinger 的主要职责

- **Surface 管理**：管理系统中所有的 Surface
- **图形合成**：将多个 Surface 的内容合成为最终的画面
- **VSync 同步**：与硬件 VSync 信号同步，控制帧率
- **Buffer 管理**：管理图形缓冲区的分配和释放
- **显示输出**：将合成后的画面输出到屏幕

## 二、Surface 的创建和管理

### 2.1 Surface 的创建流程

**在 Activity 启动时创建 Surface**：

```
Activity.onCreate()
    ↓
WindowManager.addView()
    ↓
ViewRootImpl.setView()
    ↓
Session.addToDisplay() (通过 Binder 调用 WMS)
    ↓
WindowManagerService.addWindow()
    ↓
SurfaceControl.create()
    ↓
Surface 创建完成
```

### 2.2 Surface 的层次结构

```
Surface (应用层)
    ↓
SurfaceControl (系统层，WMS 管理)
    ↓
Native Surface (Native 层)
    ↓
BufferQueue (缓冲区队列)
    ↓
GraphicBuffer (图形缓冲区)
```

### 2.3 Surface 的关键组件

#### 2.3.1 BufferQueue

- **作用**：管理图形缓冲区的队列
- **生产者-消费者模式**：
  - **生产者**：应用进程（通过 Canvas、OpenGL 等绘制）
  - **消费者**：SurfaceFlinger（合成并显示）
- **缓冲区数量**：通常使用双缓冲或三缓冲

#### 2.3.2 GraphicBuffer

- **作用**：实际的图形缓冲区
- **存储内容**：像素数据（RGB、RGBA 等）
- **分配方式**：从共享内存（ashmem）或 GPU 内存分配
- **生命周期**：由 BufferQueue 管理

### 2.4 Surface 的绘制流程

```
1. 应用进程获取 Canvas 或 OpenGL ES 上下文
    ↓
2. 在 Surface 的 Buffer 上绘制内容
    ↓
3. 绘制完成后，调用 queueBuffer() 将 Buffer 入队
    ↓
4. SurfaceFlinger 通过 dequeueBuffer() 获取 Buffer
    ↓
5. SurfaceFlinger 合成多个 Surface 的内容
    ↓
6. 将合成后的画面输出到屏幕
```

## 三、SurfaceFlinger 的工作原理

### 3.1 SurfaceFlinger 的启动

**启动流程**：
```
init 进程
    ↓
启动 surfaceflinger 进程
    ↓
SurfaceFlinger::init()
    ↓
创建 EventThread (VSync 线程)
    ↓
创建 MessageQueue (消息队列)
    ↓
启动主循环
```

### 3.2 SurfaceFlinger 的架构

```
SurfaceFlinger
    ├── EventThread (VSync 事件线程)
    ├── MessageQueue (消息队列)
    ├── Layer (图层管理)
    │   ├── BufferLayer (Buffer 图层)
    │   ├── ColorLayer (颜色图层)
    │   └── ContainerLayer (容器图层)
    ├── CompositionEngine (合成引擎)
    │   ├── RenderEngine (渲染引擎)
    │   └── Display (显示管理)
    └── BufferQueueLayer (Buffer 队列图层)
```

### 3.3 SurfaceFlinger 的主循环

```cpp
// SurfaceFlinger.cpp
void SurfaceFlinger::onMessageReceived(int32_t what) {
    switch (what) {
        case MessageQueue::INVALIDATE:
            // 收到 VSync 信号，准备合成
            onMessageReceived();
            break;
        case MessageQueue::REFRESH:
            // 执行合成和显示
            onMessageReceived();
            break;
    }
}

void SurfaceFlinger::onMessageReceived() {
    // 1. 收集需要合成的 Layer
    // 2. 合成所有 Layer
    // 3. 输出到屏幕
}
```

### 3.4 图形合成流程

**合成流程**：
```
1. VSync 信号到达
    ↓
2. EventThread 通知 SurfaceFlinger
    ↓
3. SurfaceFlinger 收集所有可见的 Layer
    ↓
4. 按照 Z-order 排序 Layer
    ↓
5. 对每个 Layer 进行合成
    ↓
6. 使用 GPU 或硬件合成器（HWC）合成
    ↓
7. 将合成后的画面输出到显示缓冲区
    ↓
8. 等待下一个 VSync 信号
```

## 四、VSync 机制

### 4.1 什么是 VSync

- **VSync (Vertical Synchronization)**：垂直同步信号
- 由**显示硬件**产生，表示屏幕刷新完成
- 通常频率为 60Hz（每 16.67ms 一次）或 120Hz（每 8.33ms 一次）
- 用于同步应用的绘制和屏幕刷新

### 4.2 VSync 的作用

1. **防止画面撕裂**：确保在屏幕刷新时显示完整的帧
2. **控制帧率**：应用按照 VSync 节奏绘制，避免无效绘制
3. **同步多个 Surface**：所有 Surface 在同一时刻合成

### 4.3 VSync 的传递路径

```
硬件 VSync 信号
    ↓
Kernel (DRM/KMS)
    ↓
HWC (Hardware Composer)
    ↓
EventThread (SurfaceFlinger)
    ↓
Choreographer (应用进程)
    ↓
应用开始绘制
```

### 4.4 Choreographer

- **作用**：应用进程中的 VSync 接收器
- **位置**：每个应用进程都有一个 Choreographer 实例
- **功能**：
  - 接收 SurfaceFlinger 发送的 VSync 信号
  - 调度应用的绘制任务（doFrame）
  - 确保绘制在正确的时机进行

**Choreographer 的工作流程**：
```java
// Choreographer.java
void doFrame(long frameTimeNanos, int frame) {
    // 1. 处理输入事件
    doCallbacks(Choreographer.CALLBACK_INPUT, frameTimeNanos);
    
    // 2. 处理动画
    doCallbacks(Choreographer.CALLBACK_ANIMATION, frameTimeNanos);
    
    // 3. 处理插入的动画
    doCallbacks(Choreographer.CALLBACK_INSETS_ANIMATION, frameTimeNanos);
    
    // 4. 处理 Traversal（测量、布局、绘制）
    doCallbacks(Choreographer.CALLBACK_TRAVERSAL, frameTimeNanos);
    
    // 5. 处理提交
    doCallbacks(Choreographer.CALLBACK_COMMIT, frameTimeNos);
}
```

## 五、Buffer 管理

### 5.1 BufferQueue 的工作原理

**BufferQueue 的状态**：
```
FREE: 缓冲区空闲，可以被生产者使用
DEQUEUED: 缓冲区被生产者获取，正在绘制
QUEUED: 绘制完成，等待消费者使用
ACQUIRED: 缓冲区被消费者（SurfaceFlinger）获取
```

**状态转换**：
```
FREE → dequeueBuffer() → DEQUEUED
DEQUEUED → queueBuffer() → QUEUED
QUEUED → acquireBuffer() → ACQUIRED
ACQUIRED → releaseBuffer() → FREE
```

### 5.2 双缓冲机制

**为什么需要双缓冲**：
- **防止画面撕裂**：一个 Buffer 用于绘制，另一个 Buffer 用于显示
- **提高性能**：绘制和显示可以并行进行

**双缓冲工作流程**：
```
帧 1：
  Buffer A: 绘制中
  Buffer B: 显示中

帧 2：
  Buffer A: 显示中
  Buffer B: 绘制中

帧 3：
  Buffer A: 绘制中
  Buffer B: 显示中
```

### 5.3 三缓冲机制

**为什么需要三缓冲**：
- **减少卡顿**：当绘制时间超过一个 VSync 周期时，三缓冲可以提供缓冲
- **提高流畅度**：即使某一帧绘制较慢，也不会影响显示

**三缓冲工作流程**：
```
帧 1：
  Buffer A: 绘制中
  Buffer B: 显示中
  Buffer C: 空闲

帧 2：
  Buffer A: 显示中
  Buffer B: 空闲
  Buffer C: 绘制中

帧 3：
  Buffer A: 空闲
  Buffer B: 绘制中
  Buffer C: 显示中
```

### 5.4 Buffer 的分配

**分配方式**：
1. **ashmem（匿名共享内存）**：
   - 用于 CPU 渲染的 Buffer
   - 应用进程和 SurfaceFlinger 共享

2. **GPU 内存**：
   - 用于 GPU 渲染的 Buffer
   - 通过 Gralloc（Graphics Allocator）分配

3. **硬件 Buffer**：
   - 某些设备支持硬件 Buffer
   - 可以直接用于硬件合成

### 5.5 GraphicBuffer 的申请机制

#### 5.5.1 GraphicBuffer 的申请流程

**GraphicBuffer 的申请时机**：
- 当 BufferQueue 需要新的 Buffer 时申请
- 通常在 `dequeueBuffer()` 时，如果空闲 Buffer 不足，会申请新的 Buffer

**申请流程**：
```
BufferQueue.dequeueBuffer()
    ↓
检查是否有空闲 Buffer
    ↓
如果没有，调用 allocateBuffers()
    ↓
GraphicBuffer::allocate()
    ↓
Gralloc HAL (Graphics Allocator HAL)
    ↓
分配内存（GPU 内存或系统内存）
    ↓
创建 GraphicBuffer 对象
    ↓
返回给 BufferQueue
```

**源码位置**：

**① BufferQueue.dequeueBuffer()**：
- **路径**：`frameworks/native/libs/gui/BufferQueue.cpp`
- **函数签名**：`status_t BufferQueue::dequeueBuffer(int* outSlot, sp<Fence>* outFence, uint32_t width, uint32_t height, PixelFormat format, uint32_t usage)`
- **关键逻辑**：检查 `mFreeSlots`，如果为空则调用 `allocateBuffers()`

**② allocateBuffers()**：
- **路径**：`frameworks/native/libs/gui/BufferQueue.cpp`
- **函数签名**：`void BufferQueue::allocateBuffers()`
- **关键逻辑**：创建 `GraphicBuffer` 对象并调用 `allocate()`

**③ GraphicBuffer::allocate()**：
- **路径**：`frameworks/native/libs/ui/GraphicBuffer.cpp`
- **函数签名**：`status_t GraphicBuffer::allocate(uint32_t w, uint32_t h, PixelFormat format, uint32_t usage)`
- **关键逻辑**：获取 Gralloc HAL 模块，调用 `alloc()` 方法分配内存

**④ Gralloc HAL**：
- **HAL 接口定义**：`hardware/libhardware/include/hardware/gralloc.h`
- **HAL 实现**：设备厂商实现，通常在以下路径之一：
  - `hardware/*/libgralloc/`
  - `vendor/*/gralloc/`
  - `hardware/qcom/display/gralloc/`（高通）
  - `hardware/samsung_slsi/gralloc/`（三星）
- **关键接口**：`gralloc_module_t::alloc()`

**⑤ 内存分配底层实现**：
- **ION 分配器**：`system/core/libion/`（某些设备使用）
- **dma-buf 框架**：Linux 内核 `drivers/dma-buf/`
- **设备特定实现**：各厂商的 Gralloc HAL 实现中

#### 5.5.2 Gralloc HAL

**Gralloc (Graphics Allocator)**：
- **作用**：图形内存分配器，是 Android HAL（Hardware Abstraction Layer）的一部分
- **位置**：运行在系统进程中，通过 Binder 提供服务
- **功能**：
  - 分配图形缓冲区内存
  - 管理 GPU 内存和系统内存
  - 提供内存映射功能

**Gralloc HAL 的接口**：
```cpp
// gralloc.h
typedef struct gralloc_module_t {
    // 分配 Buffer
    int (*alloc)(struct gralloc_module_t* module,
                 int width, int height, int format,
                 int usage, buffer_handle_t* handle,
                 int* stride);
    
    // 释放 Buffer
    int (*free)(struct gralloc_module_t* module,
                buffer_handle_t* handle);
    
    // 锁定 Buffer（用于 CPU 访问）
    int (*lock)(struct gralloc_module_t* module,
                buffer_handle_t handle, int usage,
                int l, int t, int w, int h,
                void** vaddr);
    
    // 解锁 Buffer
    int (*unlock)(struct gralloc_module_t* module,
                  buffer_handle_t handle);
} gralloc_module_t;
```

#### 5.5.3 GraphicBuffer 的申请方式

**方式 1：通过 Gralloc HAL 分配**
```cpp
// GraphicBuffer.cpp
status_t GraphicBuffer::allocate(uint32_t width, uint32_t height,
        PixelFormat format, uint32_t usage) {
    
    // 1. 获取 Gralloc HAL 模块
    gralloc_module_t const* module = getGrallocModule();
    
    // 2. 调用 Gralloc HAL 的 alloc 函数
    int err = module->alloc(module, width, height, format, usage,
                           &mHandle, &mStride);
    
    if (err == 0) {
        // 3. 创建 GraphicBuffer 对象
        mWidth = width;
        mHeight = height;
        mFormat = format;
        mUsage = usage;
    }
    
    return err;
}
```

**方式 2：从 BufferQueue 申请**
```cpp
// BufferQueue.cpp
status_t BufferQueue::dequeueBuffer(int* outSlot, sp<Fence>* outFence,
                                   uint32_t width, uint32_t height,
                                   PixelFormat format, uint32_t usage) {
    
    // 1. 查找空闲的 Buffer
    int found = findFreeSlotLocked();
    
    if (found == INVALID_BUFFER_SLOT) {
        // 2. 如果没有空闲 Buffer，申请新的
        found = allocateBuffersLocked(width, height, format, usage);
    }
    
    // 3. 返回 Buffer
    *outSlot = found;
    return NO_ERROR;
}
```

#### 5.5.4 内存类型

**GraphicBuffer 可能分配的内存类型**：

1. **GPU 内存（GPU Memory）**：
   - **用途**：GPU 渲染的 Buffer
   - **特点**：GPU 可以直接访问，性能高
   - **分配位置**：GPU 的显存或统一内存架构（UMA）的 GPU 部分
   
   **使用场景**：
   - **硬件加速的 View**：使用 GPU 渲染的 View（如复杂动画、3D 图形）
   - **OpenGL ES 渲染**：通过 OpenGL ES 或 Vulkan 绘制的 Surface
   - **SurfaceView**：使用 GPU 渲染的 SurfaceView
   - **TextureView**：显示 GPU 纹理的 View
   - **Usage 标志**：包含 `USAGE_GPU_TEXTURE` 或 `USAGE_GPU_RENDER_TARGET`
   
   **优势**：
   - GPU 直接访问，无需内存拷贝
   - 性能高，适合复杂图形渲染
   - 支持硬件加速的图形操作

2. **系统内存（System Memory）**：
   - **用途**：CPU 渲染的 Buffer
   - **特点**：CPU 可以直接访问
   - **分配位置**：系统 RAM
   
   **使用场景**：
   - **软件渲染的 View**：使用 Canvas 和 Skia 库绘制的 View
   - **禁用硬件加速**：`android:hardwareAccelerated="false"` 的应用
   - **简单的 2D 图形**：不需要 GPU 加速的简单绘制
   - **CPU 图像处理**：需要 CPU 处理像素数据的场景
   - **Usage 标志**：包含 `USAGE_SW_READ_OFTEN` 或 `USAGE_SW_WRITE_OFTEN`
   
   **优势**：
   - CPU 直接访问，适合 CPU 渲染
   - 兼容性好，所有设备都支持
   - 适合简单的 2D 图形绘制

3. **共享内存（Shared Memory）**：
   - **用途**：CPU 和 GPU 都需要访问的 Buffer
   - **特点**：通过 ashmem 或 dma-buf 实现
   - **分配位置**：系统内存，但可以被 GPU 映射
   
   **使用场景**：
   - **混合渲染**：CPU 和 GPU 都需要访问的 Buffer
   - **图像数据共享**：应用进程和 SurfaceFlinger 共享 Buffer
   - **跨进程访问**：不同进程需要访问同一个 Buffer
   - **CPU 预处理 + GPU 渲染**：CPU 处理数据后，GPU 进行渲染
   - **Usage 标志**：同时包含 CPU 和 GPU 访问标志
   
   **实现方式**：
   - **ashmem（Android Shared Memory）**：Android 的匿名共享内存
   - **dma-buf**：Linux 内核的 DMA Buffer 框架
   - **ion**：某些设备使用的 ION 内存分配器
   
   **优势**：
   - CPU 和 GPU 都可以访问
   - 减少内存拷贝
   - 支持跨进程共享

4. **硬件 Buffer（Hardware Buffer）**：
   - **用途**：硬件合成器可以直接使用的 Buffer
   - **特点**：某些设备支持，可以直接用于 HWC
   - **分配位置**：硬件特定的内存区域
   
   **使用场景**：
   - **硬件合成优化**：支持 HWC 的 Layer，可以直接由硬件合成
   - **视频播放**：视频解码器输出的 Buffer
   - **相机预览**：相机预览的 Buffer
   - **Overlay 层**：某些系统 UI 层（如状态栏、导航栏）
   - **Usage 标志**：包含 `USAGE_HW_COMPOSER` 或 `USAGE_HW_TEXTURE`
   
   **优势**：
   - 硬件直接合成，性能最高
   - 降低 GPU 和 CPU 负载
   - 功耗更低
   - 减少内存带宽占用

#### 5.5.4.1 内存类型选择机制

**Gralloc 如何选择内存类型**：

**选择依据**：
1. **Usage 标志**：根据 Usage 标志判断需要哪种访问方式
2. **设备能力**：检查设备是否支持相应的内存类型
3. **性能优化**：选择性能最优的内存类型

**选择流程**：
```cpp
// Gralloc 选择内存类型的逻辑（简化）
if (usage & USAGE_HW_COMPOSER && device_supports_hwc_buffer) {
    // 优先使用硬件 Buffer
    allocate_hardware_buffer();
} else if (usage & USAGE_GPU_TEXTURE || usage & USAGE_GPU_RENDER_TARGET) {
    // 使用 GPU 内存
    allocate_gpu_memory();
} else if (usage & USAGE_SW_READ_OFTEN || usage & USAGE_SW_WRITE_OFTEN) {
    // 使用系统内存
    allocate_system_memory();
} else {
    // 默认使用共享内存
    allocate_shared_memory();
}
```

**实际场景示例**：

**场景 1：普通 Activity（硬件加速开启）**
```
Usage: USAGE_GPU_RENDER_TARGET | USAGE_HW_COMPOSER
    ↓
选择：GPU 内存或硬件 Buffer（如果设备支持）
    ↓
原因：需要 GPU 渲染，且可能用于硬件合成
```

**场景 2：普通 Activity（硬件加速关闭）**
```
Usage: USAGE_SW_WRITE_OFTEN
    ↓
选择：系统内存
    ↓
原因：CPU 渲染，不需要 GPU 访问
```

**场景 3：SurfaceView（视频播放）**
```
Usage: USAGE_HW_COMPOSER | USAGE_HW_TEXTURE
    ↓
选择：硬件 Buffer
    ↓
原因：视频解码器输出，可以直接用于硬件合成
```

**场景 4：相机预览**
```
Usage: USAGE_HW_COMPOSER | USAGE_HW_CAMERA_WRITE
    ↓
选择：硬件 Buffer
    ↓
原因：相机硬件直接写入，可以直接用于硬件合成
```

**场景 5：混合渲染（CPU 处理 + GPU 渲染）**
```
Usage: USAGE_SW_WRITE_OFTEN | USAGE_GPU_TEXTURE
    ↓
选择：共享内存（dma-buf）
    ↓
原因：CPU 和 GPU 都需要访问
```

#### 5.5.5 Buffer 的 Usage 标志

**Usage 标志决定 Buffer 的分配方式**：

```cpp
// GraphicBuffer.h
enum {
    // CPU 访问标志
    USAGE_SW_READ_NEVER = 0x00000000,
    USAGE_SW_READ_RARELY = 0x00000002,
    USAGE_SW_READ_OFTEN = 0x00000003,
    USAGE_SW_WRITE_NEVER = 0x00000000,
    USAGE_SW_WRITE_RARELY = 0x00000020,
    USAGE_SW_WRITE_OFTEN = 0x00000030,
    
    // GPU 访问标志
    USAGE_GPU_TEXTURE = 0x00000100,
    USAGE_GPU_RENDER_TARGET = 0x00000200,
    
    // 硬件合成标志
    USAGE_HW_COMPOSER = 0x00000800,
    USAGE_HW_TEXTURE = 0x00001000,
    
    // 显示相关
    USAGE_HW_FB = 0x00002000,  // Framebuffer
    USAGE_EXTERNAL_DISP = 0x00004000,
};
```

**Usage 标志的作用**：
- **决定内存类型**：根据 Usage 标志选择 GPU 内存或系统内存
- **优化性能**：Gralloc 可以根据 Usage 选择最优的内存分配策略
- **权限控制**：限制 Buffer 的访问方式（只读、只写等）

#### 5.5.6 GraphicBuffer 的生命周期

**创建**：
```
BufferQueue 需要新 Buffer
    ↓
调用 GraphicBuffer::allocate()
    ↓
通过 Gralloc HAL 分配内存
    ↓
创建 GraphicBuffer 对象
```

**使用**：
```
应用进程 dequeueBuffer() 获取 Buffer
    ↓
在 Buffer 上绘制内容
    ↓
queueBuffer() 将 Buffer 入队
    ↓
SurfaceFlinger acquireBuffer() 获取 Buffer
    ↓
合成并显示
    ↓
releaseBuffer() 释放 Buffer
```

**销毁**：
```
BufferQueue 不再需要 Buffer
    ↓
调用 GraphicBuffer 的析构函数
    ↓
通过 Gralloc HAL 释放内存
    ↓
内存回收
```

#### 5.5.7 Buffer 的共享机制

**为什么需要共享**：
- 应用进程和 SurfaceFlinger 需要访问同一个 Buffer
- 不同进程之间需要共享图形数据

**共享方式**：

1. **Binder 传递 Buffer Handle**：
   - GraphicBuffer 通过 Binder 传递 `buffer_handle_t`
   - 接收方通过 handle 访问 Buffer

2. **内存映射**：
   - 通过 `mmap()` 或 `ion` 将 Buffer 映射到进程地址空间
   - 多个进程可以映射同一个 Buffer

3. **dma-buf**：
   - Linux 内核的 DMA Buffer 框架
   - 用于在不同设备（CPU、GPU、显示硬件）之间共享 Buffer

**共享流程**：
```
应用进程创建 GraphicBuffer
    ↓
通过 Binder 传递 buffer_handle_t 给 SurfaceFlinger
    ↓
SurfaceFlinger 通过 handle 映射 Buffer
    ↓
两个进程都可以访问同一个 Buffer
```

## 六、图形渲染路径

### 6.1 软件渲染（CPU 渲染）

**流程**：
```
应用进程
    ↓
Canvas 绘制
    ↓
Skia 库（2D 图形库）
    ↓
CPU 渲染到 Buffer
    ↓
SurfaceFlinger 合成
    ↓
屏幕显示
```

**特点**：
- 使用 CPU 进行渲染
- 性能较低，但兼容性好
- 适用于简单的 2D 图形

### 6.2 硬件渲染（GPU 渲染）

**流程**：
```
应用进程
    ↓
OpenGL ES / Vulkan
    ↓
GPU 渲染到 Buffer
    ↓
SurfaceFlinger 合成
    ↓
屏幕显示
```

**特点**：
- 使用 GPU 进行渲染
- 性能高，支持复杂图形
- 适用于 3D 图形、动画等

### 6.3 硬件合成（HWC）

**Hardware Composer (HWC)**：
- 硬件合成器，由显示硬件提供
- 可以将多个 Layer 直接合成，无需 GPU
- 性能更高，功耗更低

**HWC 的优势**：
- **减少 GPU 负载**：某些 Layer 可以直接由硬件合成
- **降低功耗**：硬件合成比 GPU 合成更省电
- **提高性能**：硬件合成速度更快

**HWC 的工作流程**：
```
SurfaceFlinger
    ↓
检查每个 Layer 是否支持硬件合成
    ↓
将支持的 Layer 交给 HWC
    ↓
HWC 直接合成到显示缓冲区
    ↓
不支持的 Layer 由 GPU 合成
```

## 七、Layer 管理

### 7.1 Layer 的类型

#### 7.1.1 BufferLayer
- **作用**：管理有内容的 Layer（如 Activity 的 Surface）
- **特点**：有 BufferQueue，内容由应用绘制
- **使用场景**：Activity、Dialog、SurfaceView 等

#### 7.1.2 ColorLayer
- **作用**：纯色 Layer
- **特点**：没有 BufferQueue，只有颜色信息
- **使用场景**：状态栏、导航栏的背景色

#### 7.1.3 ContainerLayer
- **作用**：容器 Layer，包含其他 Layer
- **特点**：用于组织 Layer 的层次结构
- **使用场景**：Window 容器

### 7.2 Layer 的 Z-order

**Z-order 决定 Layer 的显示顺序**：
- **Z-order 越大**：显示在上层
- **Z-order 越小**：显示在下层

**Z-order 的分配**：
- **系统 UI**：Z-order 较高（状态栏、导航栏）
- **应用 Window**：Z-order 中等（Activity）
- **背景**：Z-order 较低（壁纸）

### 7.3 Layer 的合成

**合成顺序**：
```
1. 按照 Z-order 从低到高排序
2. 对每个 Layer 进行合成
3. 上层 Layer 覆盖下层 Layer
4. 支持透明度混合（Alpha Blending）
```

## 八、性能优化

### 8.1 减少过度绘制

**过度绘制的原因**：
- 多个 View 重叠绘制
- 背景色不透明
- 不必要的绘制操作

**优化方法**：
- 移除不必要的背景
- 使用 `clipRect()` 裁剪绘制区域
- 使用 `View.setWillNotDraw(true)` 跳过不需要绘制的 View

### 8.2 使用硬件加速

**硬件加速的优势**：
- GPU 渲染性能更高
- 支持复杂的图形效果
- 减少 CPU 负载

**启用硬件加速**：
```xml
<!-- AndroidManifest.xml -->
<application android:hardwareAccelerated="true">
```

### 8.3 优化 Surface 数量

**问题**：
- 每个 Surface 都需要内存和合成资源
- Surface 过多会导致性能下降

**优化方法**：
- 减少 Dialog、PopupWindow 的使用
- 复用 Surface（如 RecyclerView）
- 及时释放不需要的 Surface

### 8.4 使用 HWC

**优势**：
- 硬件合成性能更高
- 降低 GPU 和 CPU 负载
- 减少功耗

**如何利用 HWC**：
- 系统自动选择使用 HWC 或 GPU 合成
- 应用层通常不需要关心，由 SurfaceFlinger 决定

## 九、常见面试问题

### 9.1 Surface 和 SurfaceFlinger 的关系

**问题**：Surface 和 SurfaceFlinger 是什么关系？

**答案要点**：
1. **Surface**：应用层的绘图表面，应用程序在 Surface 上绘制内容
2. **SurfaceFlinger**：系统层的合成服务，将多个 Surface 合成为最终画面
3. **关系**：
   - 应用进程创建 Surface 并绘制内容
   - Surface 通过 BufferQueue 管理图形缓冲区
   - SurfaceFlinger 从 BufferQueue 获取 Buffer 进行合成
   - SurfaceFlinger 将合成后的画面输出到屏幕

### 9.2 Surface 的创建流程

**问题**：Surface 是如何创建的？

**答案要点**：
1. Activity 启动时，WindowManager 创建 Window
2. ViewRootImpl 调用 WMS 的 addWindow()
3. WMS 创建 SurfaceControl
4. SurfaceControl 创建 Native Surface
5. Native Surface 创建 BufferQueue
6. Surface 创建完成，应用可以开始绘制

### 9.3 VSync 的作用

**问题**：VSync 在图形系统中起什么作用？

**答案要点**：
1. **防止画面撕裂**：确保在屏幕刷新时显示完整的帧
2. **控制帧率**：应用按照 VSync 节奏绘制，避免无效绘制
3. **同步多个 Surface**：所有 Surface 在同一时刻合成
4. **传递路径**：硬件 VSync → HWC → EventThread → Choreographer → 应用

### 9.4 双缓冲和三缓冲的区别

**问题**：双缓冲和三缓冲有什么区别？为什么需要三缓冲？

**答案要点**：
1. **双缓冲**：
   - 两个 Buffer：一个绘制，一个显示
   - 适用于绘制时间小于一个 VSync 周期的情况

2. **三缓冲**：
   - 三个 Buffer：一个绘制，一个显示，一个备用
   - 适用于绘制时间可能超过一个 VSync 周期的情况
   - 可以减少卡顿，提高流畅度

3. **选择原则**：
   - 绘制时间稳定且小于 VSync 周期：双缓冲
   - 绘制时间不稳定或可能超过 VSync 周期：三缓冲

### 9.5 SurfaceFlinger 的合成流程

**问题**：SurfaceFlinger 是如何合成多个 Surface 的？

**答案要点**：
1. **VSync 信号到达**：EventThread 通知 SurfaceFlinger
2. **收集 Layer**：收集所有可见的 Layer
3. **排序**：按照 Z-order 排序
4. **合成**：
   - 优先使用 HWC 硬件合成
   - 不支持的 Layer 使用 GPU 合成
5. **输出**：将合成后的画面输出到显示缓冲区

### 9.6 BufferQueue 的工作原理

**问题**：BufferQueue 是如何工作的？

**答案要点**：
1. **生产者-消费者模式**：
   - 生产者：应用进程（绘制内容）
   - 消费者：SurfaceFlinger（合成显示）

2. **状态转换**：
   - FREE → DEQUEUED（生产者获取）
   - DEQUEUED → QUEUED（绘制完成）
   - QUEUED → ACQUIRED（消费者获取）
   - ACQUIRED → FREE（显示完成）

3. **缓冲区管理**：通常使用双缓冲或三缓冲

### 9.6.1 GraphicBuffer 的申请机制
**问题**：GraphicBuffer 是怎么申请出来的？

**答案要点**：

**申请流程**：
1. **触发时机**：
   - BufferQueue 在 `dequeueBuffer()` 时，如果空闲 Buffer 不足
   - 会调用 `allocateBuffers()` 申请新的 Buffer

2. **申请路径**：
   ```
   BufferQueue.dequeueBuffer()
       ↓
   allocateBuffers()
       ↓
   GraphicBuffer::allocate()
       ↓
   Gralloc HAL (Graphics Allocator HAL)
       ↓
   分配内存（GPU 内存或系统内存）
   ```

   **源码位置**：
   
   **① BufferQueue.dequeueBuffer()**：
   - **路径**：`frameworks/native/libs/gui/BufferQueue.cpp`
   - **关键代码**：
     ```cpp
     // BufferQueue.cpp
     status_t BufferQueue::dequeueBuffer(int* outSlot, ...) {
         // 检查是否有空闲的 Buffer
         if (mFreeSlots.empty()) {
             // 调用 allocateBuffers() 申请新 Buffer
             allocateBuffers();
         }
         // ...
     }
     ```
   
   **② allocateBuffers()**：
   - **路径**：`frameworks/native/libs/gui/BufferQueue.cpp`
   - **关键代码**：
     ```cpp
     // BufferQueue.cpp
     void BufferQueue::allocateBuffers() {
         // 创建 GraphicBuffer
         sp<GraphicBuffer> graphicBuffer = new GraphicBuffer(
             mDefaultWidth, mDefaultHeight, mDefaultFormat,
             mDefaultUsage);
         // 调用 GraphicBuffer::allocate()
         status_t err = graphicBuffer->initCheck();
         if (err == NO_ERROR) {
             err = graphicBuffer->allocate();
         }
         // ...
     }
     ```
   
   **③ GraphicBuffer::allocate()**：
   - **路径**：`frameworks/native/libs/ui/GraphicBuffer.cpp`
   - **关键代码**：
     ```cpp
     // GraphicBuffer.cpp
     status_t GraphicBuffer::allocate(uint32_t w, uint32_t h, PixelFormat format,
                                      uint32_t usage) {
         // 获取 Gralloc HAL 模块
         if (mInitCheck != NO_ERROR) {
             return mInitCheck;
         }
         
         // 调用 Gralloc HAL 的 alloc() 方法
         status_t err = mAllocator->allocate(w, h, format, usage, &handle, &stride);
         if (err == NO_ERROR) {
             mBufferMapper.get(handle, &mBuffer);
         }
         return err;
     }
     ```
   
   **④ Gralloc HAL**：
   - **HAL 接口定义**：`hardware/libhardware/include/hardware/gralloc.h`
   - **HAL 实现**：设备厂商实现，通常在 `hardware/*/libgralloc/` 或 `vendor/*/gralloc/`
   - **关键接口**：
     ```cpp
     // gralloc.h
     typedef struct gralloc_module_t {
         // ...
         int (*alloc)(struct gralloc_module_t* module,
                      size_t width, size_t height, int format,
                      int usage, buffer_handle_t* handle, int* stride);
         // ...
     } gralloc_module_t;
     ```
   
   **⑤ 内存分配实现**：
   - **ION 分配器**：`system/core/libion/`（某些设备）
   - **dma-buf 框架**：Linux 内核 `drivers/dma-buf/`
   - **设备特定实现**：各厂商的 Gralloc HAL 实现
     - 高通：`hardware/qcom/display/gralloc/`
     - 三星：`hardware/samsung_slsi/gralloc/`
     - 其他厂商：各自的 vendor 目录下

3. **Gralloc HAL**：
   - **作用**：图形内存分配器，Android HAL 的一部分
   - **功能**：分配图形缓冲区内存，管理 GPU 内存和系统内存
   - **接口**：`alloc()`, `free()`, `lock()`, `unlock()`

4. **内存类型**：
   - **GPU 内存**：用于 GPU 渲染，GPU 可直接访问
   - **系统内存**：用于 CPU 渲染，CPU 可直接访问
   - **共享内存**：通过 ashmem 或 dma-buf 实现，CPU 和 GPU 都可访问
   - **硬件 Buffer**：某些设备支持，可直接用于 HWC

5. **Usage 标志**：
   - 决定 Buffer 的分配方式（GPU 内存或系统内存）
   - 优化性能：Gralloc 根据 Usage 选择最优的内存分配策略
   - 权限控制：限制 Buffer 的访问方式

6. **共享机制**：
   - 通过 Binder 传递 `buffer_handle_t`
   - 通过 `mmap()` 或 `ion` 映射到进程地址空间
   - 通过 dma-buf 在不同设备间共享

### 9.6.2 不同内存类型的使用场景
**问题**：Android 中 GraphicBuffer 的不同内存类型各自在什么场景下使用？

**答案要点**：

**1. GPU 内存（GPU Memory）**：
- **使用场景**：
  - 硬件加速的 View（复杂动画、3D 图形）
  - OpenGL ES/Vulkan 渲染的 Surface
  - SurfaceView、TextureView
  - Usage 包含 `USAGE_GPU_TEXTURE` 或 `USAGE_GPU_RENDER_TARGET`
- **优势**：GPU 直接访问，性能高，适合复杂图形渲染

**2. 系统内存（System Memory）**：
- **使用场景**：
  - 软件渲染的 View（Canvas + Skia）
  - 禁用硬件加速的应用
  - 简单的 2D 图形绘制
  - CPU 图像处理场景
  - Usage 包含 `USAGE_SW_READ_OFTEN` 或 `USAGE_SW_WRITE_OFTEN`
- **优势**：CPU 直接访问，兼容性好，适合简单 2D 图形

**3. 共享内存（Shared Memory）**：
- **使用场景**：
  - CPU 和 GPU 都需要访问的 Buffer
  - 应用进程和 SurfaceFlinger 共享 Buffer
  - 跨进程访问的 Buffer
  - CPU 预处理 + GPU 渲染的场景
  - 同时包含 CPU 和 GPU 访问标志
- **实现方式**：ashmem、dma-buf、ion
- **优势**：CPU 和 GPU 都可访问，减少内存拷贝

**4. 硬件 Buffer（Hardware Buffer）**：
- **使用场景**：
  - 支持 HWC 的 Layer（硬件合成优化）
  - 视频播放（视频解码器输出）
  - 相机预览（相机硬件直接写入）
  - Overlay 层（状态栏、导航栏）
  - Usage 包含 `USAGE_HW_COMPOSER` 或 `USAGE_HW_TEXTURE`
- **优势**：硬件直接合成，性能最高，功耗更低

**选择机制**：
- Gralloc 根据 Usage 标志和设备能力选择内存类型
- 优先使用硬件 Buffer（如果支持），其次 GPU 内存，最后系统内存
- 如果 CPU 和 GPU 都需要访问，使用共享内存

### 9.7 硬件渲染和软件渲染的区别

**问题**：硬件渲染和软件渲染有什么区别？

**答案要点**：
1. **软件渲染（CPU 渲染）**：
   - 使用 CPU 和 Skia 库渲染
   - 性能较低，兼容性好
   - 适用于简单 2D 图形

2. **硬件渲染（GPU 渲染）**：
   - 使用 GPU 和 OpenGL ES/Vulkan 渲染
   - 性能高，支持复杂图形
   - 适用于 3D 图形、动画

3. **选择**：系统根据 View 的特性自动选择渲染方式

### 9.8 HWC 的作用

**问题**：Hardware Composer (HWC) 是什么？有什么作用？

**答案要点**：
1. **HWC**：硬件合成器，由显示硬件提供
2. **作用**：
   - 将多个 Layer 直接合成，无需 GPU
   - 性能更高，功耗更低
   - 减少 GPU 负载

3. **工作方式**：
   - SurfaceFlinger 检查 Layer 是否支持硬件合成
   - 支持的 Layer 交给 HWC
   - 不支持的 Layer 由 GPU 合成

### 9.9 如何优化图形性能

**问题**：如何优化 Android 应用的图形性能？

**答案要点**：
1. **减少过度绘制**：
   - 移除不必要的背景
   - 使用 clipRect() 裁剪
   - 使用 setWillNotDraw(true)

2. **使用硬件加速**：
   - 启用 GPU 渲染
   - 使用 OpenGL ES 进行复杂绘制

3. **优化 Surface 数量**：
   - 减少 Dialog、PopupWindow
   - 复用 Surface

4. **优化绘制时机**：
   - 在 VSync 信号到达时绘制
   - 避免在 onDraw() 中做耗时操作

### 9.10 Choreographer 的作用

**问题**：Choreographer 在图形系统中起什么作用？

**答案要点**：
1. **作用**：应用进程中的 VSync 接收器
2. **功能**：
   - 接收 SurfaceFlinger 发送的 VSync 信号
   - 调度应用的绘制任务（doFrame）
   - 确保绘制在正确的时机进行

3. **回调顺序**：
   - INPUT（输入事件）
   - ANIMATION（动画）
   - TRAVERSAL（测量、布局、绘制）
   - COMMIT（提交）

## 十、关键类和方法

### 10.1 核心类

- **Surface**：应用层的绘图表面
- **SurfaceControl**：系统层的 Surface 控制
- **SurfaceFlinger**：图形合成服务
- **BufferQueue**：缓冲区队列
- **GraphicBuffer**：图形缓冲区
- **Layer**：图层（BufferLayer、ColorLayer 等）
- **Choreographer**：VSync 接收器
- **EventThread**：VSync 事件线程
- **HardwareComposer**：硬件合成器

### 10.2 关键方法

- `Surface.lockCanvas()`：锁定 Canvas 进行绘制
- `Surface.unlockCanvasAndPost()`：解锁并提交绘制内容
- `BufferQueue.dequeueBuffer()`：获取空闲 Buffer
- `BufferQueue.queueBuffer()`：将绘制完成的 Buffer 入队
- `SurfaceFlinger.onMessageReceived()`：处理 VSync 消息
- `Choreographer.doFrame()`：执行一帧的绘制

## 十一、总结

Surface 和 SurfaceFlinger 是 Android 图形系统的核心：

1. **Surface**：
   - 应用层的绘图表面
   - 管理图形缓冲区和绘制内容
   - 通过 BufferQueue 与 SurfaceFlinger 通信

2. **SurfaceFlinger**：
   - 系统层的图形合成服务
   - 将多个 Surface 合成为最终画面
   - 与 VSync 同步，控制帧率

3. **关键机制**：
   - **VSync**：同步绘制和显示
   - **BufferQueue**：管理图形缓冲区
   - **HWC**：硬件合成提高性能

理解 Surface 和 SurfaceFlinger 的工作原理对于：
- 优化应用性能
- 解决图形问题
- 理解 Android 图形系统
- 进行图形开发

都非常重要。

