#include <iostream>
#include <memory>
#include <stdexcept>
#include <vector>
using namespace std;

/**
 * 异常安全 (Exception Safety) 示例
 * 展示三种异常安全级别：基本保证、强保证、不抛异常保证
 */

// 1. 基本保证 (Basic Guarantee)
// 如果抛出异常，对象处于有效但未指定的状态
class BasicGuarantee {
private:
    vector<int> data_;
    int* ptr_;
    
public:
    BasicGuarantee(size_t size) : ptr_(new int[size]) {
        // 如果这里抛出异常，已分配的内存会泄漏
        // 需要使用RAII或智能指针
    }
    
    ~BasicGuarantee() {
        delete[] ptr_;
    }
};

// 2. 强保证 (Strong Guarantee) - 使用RAII
// 如果抛出异常，对象状态不变（事务性）
// 明确承诺：只有100%确定不会抛异常时才用 noexcept

// 移动操作优先：移动构造/赋值应尽量标记为 noexcept

// 避免滥用：不要给可能抛异常的函数加 noexcept

// 析构函数：永远不要让析构函数抛出异常

// 逐步添加：可以先不写，确定后再添加
// 要加 noexcept
// 用意	具体表现	受益方
// 性能优化	允许移动而非复制，减少异常处理代码	程序运行效率
// 接口清晰	明确告知调用者不会抛异常	代码维护者
// 编译优化	编译器可生成更精简的代码	二进制大小/速度
// 安全保证	防止异常在不该出现的地方出现	程序稳定性
// 标准库兼容	满足容器算法优化条件	标准库性能
// 核心思想：noexcept 不是"保证不抛异常"的工具，而是告诉编译器和调用者"如果这里抛异常，我愿意接受程序终止的后果"的承诺。这是一种用安全性换性能/简洁性的设计选择。
class StrongGuarantee {
private:
    unique_ptr<int[]> ptr_;
    size_t size_;
    
public:
    StrongGuarantee(size_t size) 
        : ptr_(make_unique<int[]>(size)), size_(size) {
        // 使用智能指针，异常安全
    }
    
    // 强保证的赋值操作：先拷贝，再交换
    StrongGuarantee& operator=(const StrongGuarantee& other) {
        StrongGuarantee temp(other); // 如果这里失败，原对象不变
        swap(temp);
        return *this;
    }
    
    void swap(StrongGuarantee& other) noexcept {
        std::swap(ptr_, other.ptr_);
        std::swap(size_, other.size_);
    }
};

// 3. 不抛异常保证 (No-throw Guarantee)
// 函数保证不抛出异常
class NoThrowGuarantee {
private:
    int value_;
    
public:
    // 移动操作通常标记为noexcept
    NoThrowGuarantee(NoThrowGuarantee&& other) noexcept 
        : value_(other.value_) {
        other.value_ = 0;
    }
    
    NoThrowGuarantee& operator=(NoThrowGuarantee&& other) noexcept {
        if (this != &other) {
            value_ = other.value_;
            other.value_ = 0;
        }
        return *this;
    }
    
    // 析构函数应该标记为noexcept
    ~NoThrowGuarantee() noexcept = default;
    
    // swap通常不抛异常
    void swap(NoThrowGuarantee& other) noexcept {
        std::swap(value_, other.value_);
    }
};

// 4. RAII (Resource Acquisition Is Initialization)
// 资源获取即初始化，确保资源正确释放
class RAIIExample {
private:
    FILE* file_;
    
public:
    explicit RAIIExample(const char* filename) : file_(nullptr) {
        file_ = fopen(filename, "r");
        if (!file_) {
            throw runtime_error("Failed to open file");
        }
    }
    
    ~RAIIExample() {
        if (file_) {
            fclose(file_);
        }
    }
    
    // 禁止拷贝
    RAIIExample(const RAIIExample&) = delete;
    RAIIExample& operator=(const RAIIExample&) = delete;
    
    // 允许移动
    RAIIExample(RAIIExample&& other) noexcept : file_(other.file_) {
        other.file_ = nullptr;
    }
    
    FILE* get() const { return file_; }
};

// 5. 异常安全的容器操作
template<typename T>
class SafeVector {
private:
    vector<T> data_;
    
public:
    // 强保证的插入操作
    void insert_safe(size_t pos, const T& value) {
        vector<T> temp = data_; // 先拷贝
        temp.insert(temp.begin() + pos, value); // 如果失败，原data_不变
        data_.swap(temp); // 交换（不抛异常）
    }
    
    // 使用emplace_back（强保证）
    template<typename... Args>
    void emplace_safe(Args&&... args) {
        data_.emplace_back(forward<Args>(args)...);
        // vector的emplace_back提供强保证
    }
};

// 6. 异常规范 (Exception Specification) - C++11/17
class ExceptionSpec {
public:
    // noexcept说明符
    void no_throw_func() noexcept {
        // 如果这里抛出异常，会调用std::terminate
    }
    
    // 条件noexcept
    template<typename T>
    void conditional_noexcept(T&& t) noexcept(noexcept(t.swap(t))) {
        t.swap(t);
    }
};

// 7. 异常安全的资源管理
class ResourceManager {
private:
    vector<unique_ptr<int>> resources_;
    
public:
    void add_resource(int value) {
        // 使用make_unique，异常安全
        auto resource = make_unique<int>(value);
        resources_.push_back(move(resource));
        // 如果push_back失败，resource会被正确释放
    }
    
    // 强保证的批量操作
    void add_resources(const vector<int>& values) {
        vector<unique_ptr<int>> temp;
        temp.reserve(values.size());
        
        for (int value : values) {
            temp.push_back(make_unique<int>(value));
        }
        
        // 如果到这里没有异常，交换（强保证）
        resources_.swap(temp);
    }
};

int main() {
    cout << "=== Exception Safety Demo ===" << endl;
    
    // RAII示例
    try {
        RAIIExample file("nonexistent.txt");
    } catch (const exception& e) {
        cout << "Exception caught: " << e.what() << endl;
    }
    
    // 异常安全的资源管理
    ResourceManager rm;
    rm.add_resource(42);
    cout << "Resource added successfully" << endl;
    
    return 0;
}

