#include <iostream>
#include <cstdlib>
#include <cstddef>
#include <new>
#include <memory>
using namespace std;

/**
 * 内存池实现
 * 预分配大块内存，减少malloc/free调用次数，提高性能
 */

template<typename T, size_t BlockSize = 4096>
class MemoryPool {
private:
    // 内存块结构
    union Slot {
        T element;
        Slot* next;
    };
    
    // 当前内存块
    char* currentBlock_;
    Slot* currentSlot_;
    Slot* lastSlot_;
    Slot* freeSlots_;
    
    // 对齐到指定字节
    size_t alignPointer(char* ptr, size_t align) const {
        size_t addr = reinterpret_cast<size_t>(ptr);
        return (addr + align - 1) & ~(align - 1);
    }
    
    // 分配新的内存块
    void allocateBlock() {
        // 分配对齐的内存
        char* newBlock = reinterpret_cast<char*>(operator new(BlockSize));
        char* body = newBlock + sizeof(Slot*);
        size_t bodyPadding = alignPointer(body, alignof(Slot)) - body;
        currentSlot_ = reinterpret_cast<Slot*>(body + bodyPadding);
        lastSlot_ = reinterpret_cast<Slot*>(newBlock + BlockSize - sizeof(Slot) + 1);
        
        // 链接内存块
        *reinterpret_cast<Slot**>(newBlock) = currentBlock_;
        currentBlock_ = newBlock;
    }
    
public:
    MemoryPool() noexcept 
        : currentBlock_(nullptr), currentSlot_(nullptr), 
          lastSlot_(nullptr), freeSlots_(nullptr) {}
    
    ~MemoryPool() noexcept {
        Slot* curr = reinterpret_cast<Slot*>(currentBlock_);
        while (curr != nullptr) {
            Slot* prev = *reinterpret_cast<Slot**>(curr);
            operator delete(curr);
            curr = prev;
        }
    }
    
    // 禁止拷贝
    MemoryPool(const MemoryPool&) = delete;
    MemoryPool& operator=(const MemoryPool&) = delete;
    
    // 分配内存
    T* allocate(size_t n = 1) {
        if (freeSlots_ != nullptr) {
            T* result = reinterpret_cast<T*>(freeSlots_);
            freeSlots_ = freeSlots_->next;
            return result;
        }
        
        if (currentSlot_ >= lastSlot_) {
            allocateBlock();
        }
        
        return reinterpret_cast<T*>(currentSlot_++);
    }
    
    // 释放内存
    void deallocate(T* p, size_t n = 1) {
        if (p != nullptr) {
            reinterpret_cast<Slot*>(p)->next = freeSlots_;
            freeSlots_ = reinterpret_cast<Slot*>(p);
        }
    }
    
    // 构造对象
    template<typename... Args>
    T* construct(Args&&... args) {
        T* result = allocate();
        new (result) T(forward<Args>(args)...);
        return result;
    }
    
    // 销毁对象
    void destroy(T* p) {
        if (p != nullptr) {
            p->~T();
            deallocate(p);
        }
    }
};

// 使用示例
class TestClass {
private:
    int value_;
    
public:
    TestClass(int v) : value_(v) {
        cout << "Constructed TestClass with value: " << value_ << endl;
    }
    
    ~TestClass() {
        cout << "Destructed TestClass with value: " << value_ << endl;
    }
    
    int getValue() const { return value_; }
};

int main() {
    cout << "=== Memory Pool Implementation ===" << endl;
    
    MemoryPool<TestClass> pool;
    
    // 分配和构造对象
    TestClass* obj1 = pool.construct(10);
    TestClass* obj2 = pool.construct(20);
    TestClass* obj3 = pool.construct(30);
    
    cout << "obj1 value: " << obj1->getValue() << endl;
    cout << "obj2 value: " << obj2->getValue() << endl;
    cout << "obj3 value: " << obj3->getValue() << endl;
    
    // 销毁对象（内存返回池中）
    pool.destroy(obj2);
    pool.destroy(obj1);
    
    // 重新使用内存
    TestClass* obj4 = pool.construct(40);
    cout << "obj4 value: " << obj4->getValue() << endl;
    
    // 清理
    pool.destroy(obj3);
    pool.destroy(obj4);
    
    return 0;
}

