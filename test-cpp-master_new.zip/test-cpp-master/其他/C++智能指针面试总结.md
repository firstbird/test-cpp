# C++ 智能指针面试总结

## 一、智能指针概述

### 为什么需要智能指针？

**传统指针的问题：**
- 内存泄漏：忘记 `delete`
- 重复释放：多次 `delete` 同一指针
- 野指针：使用已释放的内存

**智能指针的优势：**
- 自动管理内存：自动释放资源
- 异常安全：即使发生异常也能正确释放
- RAII（Resource Acquisition Is Initialization）原则

## 二、三种智能指针

### 1. unique_ptr（独占所有权）

**特点：**
- 独占资源所有权
- 不能拷贝，只能移动
- 性能最优（无引用计数开销）

**使用场景：**
- 单一所有权
- 性能敏感的场景
- 工厂函数返回值

**代码示例：**

```cpp
#include <memory>
#include <iostream>

// 基本使用
void basicUsage() {
    std::unique_ptr<int> p1(new int(42));
    std::unique_ptr<int> p2 = std::make_unique<int>(100);  // C++14
    
    // 访问
    std::cout << *p1 << std::endl;  // 42
    std::cout << *p2 << std::endl;  // 100
    
    // 不能拷贝，只能移动
    // std::unique_ptr<int> p3 = p1;  // ❌ 编译错误
    std::unique_ptr<int> p3 = std::move(p1);  // ✅ 移动
    
    // p1 现在是 nullptr
    if (p1 == nullptr) {
        std::cout << "p1 is null" << std::endl;
    }
}

// 自定义删除器
void customDeleter() {
    auto deleter = [](int* p) {
        std::cout << "Deleting " << *p << std::endl;
        delete p;
    };
    
    std::unique_ptr<int, decltype(deleter)> p(new int(42), deleter);
    // 离开作用域时自动调用deleter
}

// 数组
void arrayUsage() {
    std::unique_ptr<int[]> arr(new int[10]);
    arr[0] = 1;
    arr[1] = 2;
    // 自动调用 delete[]
    // ✅ 注意：unique_ptr<T[]> 特化版本提供了 operator[]
    // 非数组版本 unique_ptr<T> 没有 operator[]，只有 operator* 和 operator->
}
```

### 2. shared_ptr（共享所有权）

**特点：**
- 多个 `shared_ptr` 可以共享同一资源
- 使用引用计数管理资源
- 引用计数为0时自动释放资源

**使用场景：**
- 多个对象需要共享资源
- 需要循环引用时配合 `weak_ptr` 使用

**代码示例：**

```cpp
#include <memory>
#include <iostream>

// 基本使用
void basicUsage() {
    std::shared_ptr<int> p1 = std::make_shared<int>(42);
    std::shared_ptr<int> p2 = p1;  // ✅ 可以拷贝
    
    // use_count() 返回指向同一资源的 shared_ptr 数量
    // p1 和 p2 都指向同一个资源，所以都是 2
    std::cout << p1.use_count() << std::endl;  // 2
    std::cout << p2.use_count() << std::endl;  // 2
    
    p1.reset();  // p1不再指向资源
    std::cout << p1.use_count() << std::endl;  // 0（p1已不指向资源）
    std::cout << p2.use_count() << std::endl;  // 1
    
    // p2离开作用域时，资源自动释放
}

// 自定义删除器
void customDeleter() {
    auto deleter = [](int* p) {
        std::cout << "Custom delete: " << *p << std::endl;
        delete p;
    };
    
    std::shared_ptr<int> p(new int(42), deleter);
    // 离开作用域时自动调用deleter
}

// 循环引用问题
struct Node {
    std::shared_ptr<Node> next;
    int value;
    
    Node(int v) : value(v) {}
    ~Node() {
        std::cout << "Node " << value << " destroyed" << std::endl;
    }
};

void circularReference() {
    auto n1 = std::make_shared<Node>(1);
    auto n2 = std::make_shared<Node>(2);
    
    n1->next = n2;
    n2->next = n1;  // ❌ 循环引用，内存泄漏！
    
    // n1和n2离开作用域时，引用计数都是1，不会释放
}
```

### 3. weak_ptr（弱引用）

**特点：**
- 不增加引用计数
- 不能直接访问资源，需要转换为 `shared_ptr`
- 用于解决循环引用问题

**使用场景：**
- 打破循环引用
- 观察者模式
- 缓存系统

**代码示例：**

```cpp
#include <memory>
#include <iostream>

// 解决循环引用
struct Node {
    std::shared_ptr<Node> next;
    std::weak_ptr<Node> prev;  // ✅ 使用weak_ptr打破循环
    int value;
    
    Node(int v) : value(v) {}
    ~Node() {
        std::cout << "Node " << value << " destroyed" << std::endl;
    }
};

void solveCircularReference() {
    auto n1 = std::make_shared<Node>(1);
    auto n2 = std::make_shared<Node>(2);
    
    n1->next = n2;
    // 这里weak_ptr也是由shared_ptr产生的
    n2->prev = n1;  // ✅ 使用weak_ptr，不会增加引用计数
    
    // n1和n2离开作用域时，可以正确释放
}

// 使用weak_ptr访问资源
void accessResource() {
    std::shared_ptr<int> sp = std::make_shared<int>(42);
    std::weak_ptr<int> wp = sp;
    
    // 检查资源是否还存在
    if (auto locked = wp.lock()) {  // 转换为shared_ptr
        std::cout << *locked << std::endl;  // 42
    }
    
    sp.reset();  // 释放资源
    
    if (wp.expired()) {  // 检查是否过期
        std::cout << "Resource expired" << std::endl;
    }
}
```

## 三、对比总结

| 特性 | unique_ptr | shared_ptr | weak_ptr |
|------|-----------|------------|----------|
| **所有权** | 独占 | 共享 | 无（弱引用） |
| **拷贝** | ❌ 不能 | ✅ 可以 | ✅ 可以 |
| **移动** | ✅ 可以 | ✅ 可以 | ✅ 可以 |
| **引用计数** | 无 | 有 | 不增加 |
| **性能** | 最优 | 有开销 | 有开销 |
| **线程安全** | 否 | 引用计数线程安全 | 否 |
| **使用场景** | 单一所有权 | 共享所有权 | 打破循环引用 |

## 四、最佳实践

### 1. 优先使用 make_unique 和 make_shared

```cpp
// ✅ 推荐
auto p1 = std::make_unique<int>(42);
auto p2 = std::make_shared<int>(100);

// ❌ 不推荐（可能内存泄漏）
std::unique_ptr<int> p3(new int(42));
std::shared_ptr<int> p4(new int(100));
```

**原因：**
- **异常安全**：`make_*` 保证异常安全
  - `shared_ptr(new T)`：`new` 和 `shared_ptr` 构造是两个操作，如果 `new` 成功但 `shared_ptr` 构造失败，内存泄漏
  - `make_shared`：原子操作，异常安全
- **性能**：`make_shared` 可以优化内存分配（可能一次分配对象+控制块）
- **代码一致性**：使用 `make_*` 更一致

### 2. 避免循环引用

```cpp
// ❌ 错误：循环引用
struct A {
    std::shared_ptr<B> b;
};
struct B {
    std::shared_ptr<A> a;
};

// ✅ 正确：使用weak_ptr
struct A {
    std::shared_ptr<B> b;  // 注意：默认构造为空指针，不会自动创建B对象
};
struct B {
    std::weak_ptr<A> a;  // 使用weak_ptr
};

// 使用示例：
// A a;  // a.b 是空的 shared_ptr，不会自动创建 B 对象
// 需要显式初始化：
// a.b = std::make_shared<B>();
```

### 3. 不要混用原始指针和智能指针

```cpp
// ❌ 错误
int* raw = new int(42);
std::shared_ptr<int> sp(raw);
delete raw;  // ❌ 重复释放！

初始状态：
raw ──┐
      ├──> [内存: 42]
sp ───┘

执行 delete raw 后：
raw ──> [内存已释放！❌]
sp ───> [指向已释放的内存❌]

sp 析构时：
尝试再次 delete 已释放的内存
❌ 重复释放！未定义行为！
// ✅ 正确
std::shared_ptr<int> sp = std::make_shared<int>(42);
```

### 4. 不要返回原始指针

```cpp
// ❌ 错误
int* getValue() {
    auto p = std::make_unique<int>(42);
    return p.get();  // ❌ 返回原始指针，资源可能被释放
}

// ✅ 正确
std::unique_ptr<int> getValue() {
    return std::make_unique<int>(42);
}
```

## 五、常见面试问题

### Q1: unique_ptr 和 shared_ptr 的区别？

**答案：**
- `unique_ptr`：独占所有权，不能拷贝，性能最优
- `shared_ptr`：共享所有权，可以拷贝，使用引用计数

### Q2: 如何解决 shared_ptr 的循环引用？

**答案：**
使用 `weak_ptr` 打破循环引用，`weak_ptr` 不增加引用计数。

### Q3: make_shared 和 shared_ptr(new T) 的区别？

**答案：**
- `make_shared`：异常安全，可能优化内存分配（一次分配）
- `shared_ptr(new T)`：可能内存泄漏（如果后续构造失败）

### Q4: weak_ptr 如何访问资源？

**答案：**
使用 `lock()` 方法转换为 `shared_ptr`，然后访问。

```cpp
std::weak_ptr<int> wp = sp;
if (auto locked = wp.lock()) {
    // 使用 locked
}
```

### Q5: 智能指针的线程安全性？

**答案：**
- `shared_ptr` 的引用计数是线程安全的
- 但访问指向的对象不是线程安全的
- 需要额外的同步机制保护共享资源

### Q6: 智能指针作为函数参数是否需要引用？

**答案：**
- **unique_ptr**：
  - 转移所有权 → 值传递
  - 不转移所有权 → 裸指针（推荐）或 const引用
- **shared_ptr**：
  - 只使用资源 → **裸指针（最推荐）**或 const引用
  - 需要保存shared_ptr → 值传递（会增加引用计数）
- **weak_ptr**：值传递

**推荐做法：**
```cpp
// ✅ unique_ptr：值传递（转移所有权）
void takeOwnership(std::unique_ptr<int> p);

// ✅ shared_ptr：裸指针（不增加引用计数，性能最好）
void useResource(int* p);

// ✅ shared_ptr：const引用（不增加引用计数）
void useResource(const std::shared_ptr<int>& p);
```

## 六、完整示例

```cpp
#include <memory>
#include <iostream>
#include <vector>

// 工厂函数返回unique_ptr
std::unique_ptr<int> createInt(int value) {
    return std::make_unique<int>(value);
}

// 共享资源
class Resource {
public:
    Resource(int id) : id_(id) {
        std::cout << "Resource " << id_ << " created" << std::endl;
    }
    ~Resource() {
        std::cout << "Resource " << id_ << " destroyed" << std::endl;
    }
    int getId() const { return id_; }
private:
    int id_;
};

// 使用shared_ptr共享资源
void shareResource() {
    auto r1 = std::make_shared<Resource>(1);
    auto r2 = r1;  // 共享资源
    
    std::cout << "r1 use_count: " << r1.use_count() << std::endl;  // 2
    std::cout << "r2 use_count: " << r2.use_count() << std::endl;  // 2
}

// 使用weak_ptr观察资源
void observeResource() {
    std::shared_ptr<Resource> sp = std::make_shared<Resource>(1);
    std::weak_ptr<Resource> wp = sp;
    
    std::cout << "sp use_count: " << sp.use_count() << std::endl;  // 1
    
    if (auto locked = wp.lock()) {
        std::cout << "Resource ID: " << locked->getId() << std::endl;
    }
    
    sp.reset();
    
    if (wp.expired()) {
        std::cout << "Resource expired" << std::endl;
    }
}

int main() {
    // unique_ptr示例
    auto p1 = std::make_unique<int>(42);
    auto p2 = std::move(p1);  // 移动
    
    // shared_ptr示例
    shareResource();
    
    // weak_ptr示例
    observeResource();
    
    return 0;
}
```

## 七、总结

### 核心要点

1. **unique_ptr**：独占所有权，性能最优，用于单一所有权场景
2. **shared_ptr**：共享所有权，使用引用计数，用于共享资源场景
3. **weak_ptr**：弱引用，不增加引用计数，用于打破循环引用

### 选择原则

- **单一所有权** → `unique_ptr`
- **共享所有权** → `shared_ptr`
- **需要打破循环引用** → `weak_ptr`
- **性能敏感** → `unique_ptr`

### 记忆要点

- **unique_ptr = 独占 = 不能拷贝 = 性能最优**
- **shared_ptr = 共享 = 引用计数 = 可以拷贝**
- **weak_ptr = 弱引用 = 不增加计数 = 打破循环**

这就是C++智能指针的完整面试总结！🎯

