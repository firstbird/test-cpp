# C++ 多线程面试总结

## 一、线程基础

### 1. 创建线程

```cpp
#include <thread>
#include <iostream>

// 方式1：函数指针
void threadFunc1() {
    std::cout << "Thread 1 running" << std::endl;
}

// 方式2：Lambda表达式
void createThreads() {
    std::thread t1(threadFunc1);
    
    std::thread t2([]() {
        std::cout << "Thread 2 running" << std::endl;
    });
    
    // 方式3：成员函数
    class MyClass {
    public:
        void memberFunc() {
            std::cout << "Member function thread" << std::endl;
        }
    };
    MyClass obj;
    std::thread t3(&MyClass::memberFunc, &obj);
    
    t1.join();  // 等待线程结束
    t2.join();
    t3.join();
}
```

### 2. join() 和 detach()

```cpp
#include <thread>
#include <iostream>

void threadFunc() {
    std::this_thread::sleep_for(std::chrono::seconds(1));
    std::cout << "Thread finished" << std::endl;
}

int main() {
    std::thread t(threadFunc);
    
    // join()：等待线程完成
    t.join();  // 主线程阻塞，等待t完成
    std::cout << "Main thread continues" << std::endl;
    
    // detach()：分离线程（不推荐，除非明确需要）
    std::thread t2(threadFunc);
    t2.detach();  // 线程在后台运行，主线程不等待
    // ⚠️ 注意：detach后无法再join，线程生命周期独立
    
    return 0;
}
```

**关键点：**
- `join()`：等待线程完成，确保线程资源被正确回收
- `detach()`：分离线程，线程在后台运行（谨慎使用）
- **必须调用 join() 或 detach()，否则程序终止**

## 二、互斥锁（Mutex）

### 0. mutex 的实现原理

#### 0.1 底层实现架构

**mutex 的实现层次：**

```
C++ std::mutex
    ↓
标准库实现（pthread_mutex_t / Windows CriticalSection）
    ↓
操作系统系统调用（futex / WaitForSingleObject）
    ↓
内核同步原语（自旋锁 + 等待队列）
    ↓
CPU 原子指令（CAS, XCHG）
```

#### 0.2 Linux 平台实现（基于 futex）

**futex（Fast Userspace Mutex）机制：**

```cpp
// std::mutex 的简化实现（Linux平台）
class mutex {
private:
    std::atomic<int> state{0};  // 0=未锁定, 1=已锁定, 2=已锁定且有等待者
    
public:
    void lock() {
        // 快速路径：尝试原子操作获取锁
        int expected = 0;
        if (state.compare_exchange_weak(expected, 1, 
                                       std::memory_order_acquire)) {
            return;  // 成功获取锁，无需系统调用
        }
        
        // 慢速路径：锁已被占用，进入等待
        lock_slow();
    }
    
private:
    void lock_slow() {
        int expected = 1;
        // 尝试将状态设置为 2（表示有等待者）
        if (state.compare_exchange_weak(expected, 2, 
                                       std::memory_order_relaxed)) {
            // 进入内核等待队列
            syscall(SYS_futex, &state, FUTEX_WAIT, 2, nullptr, nullptr, 0);
            // 被唤醒后，重新尝试获取锁
            lock();
        } else {
            // 其他线程可能已经释放锁，重试
            lock();
        }
    }
    
    void unlock() {
        // 快速路径：直接释放锁
        if (state.exchange(0, std::memory_order_release) == 2) {
            // 有等待者，需要唤醒
            unlock_slow();
        }
    }
    
    void unlock_slow() {
        // 唤醒等待队列中的一个线程
        syscall(SYS_futex, &state, FUTEX_WAKE, 1, nullptr, nullptr, 0);
    }
};
```

**futex 的优势：**
- **快速路径**：无竞争时无需系统调用（用户态完成）
- **慢速路径**：有竞争时才进入内核（系统调用）
- **性能优化**：减少系统调用开销

#### 0.3 Windows 平台实现（基于 CriticalSection）

```cpp
// std::mutex 的简化实现（Windows平台）
class mutex {
private:
    CRITICAL_SECTION cs;  // Windows 临界区对象
    
public:
    mutex() {
        InitializeCriticalSection(&cs);
    }
    
    void lock() {
        EnterCriticalSection(&cs);
        // Windows 内部实现：
        // 1. 尝试原子操作获取锁（用户态）
        // 2. 失败则进入等待队列（内核态）
        // 3. 使用事件对象（Event）进行唤醒
    }
    
    void unlock() {
        LeaveCriticalSection(&cs);
        // 如果有等待者，唤醒一个线程
    }
    
    ~mutex() {
        DeleteCriticalSection(&cs);
    }
};
```

#### 0.4 自旋锁（Spinlock）阶段

**mutex 通常包含自旋阶段：**

```cpp
class mutex {
private:
    std::atomic<int> state{0};
    static const int SPIN_COUNT = 1000;  // 自旋次数
    
public:
    void lock() {
        // 阶段1：自旋等待（用户态，无系统调用）
        for (int i = 0; i < SPIN_COUNT; ++i) {
            int expected = 0;
            if (state.compare_exchange_weak(expected, 1, 
                                           std::memory_order_acquire)) {
                return;  // 成功获取锁
            }
            // CPU 暂停指令，减少功耗
            std::this_thread::yield();
        }
        
        // 阶段2：进入内核等待（系统调用）
        lock_slow();
    }
};
```

**自旋锁的优势：**
- **短时间等待**：避免系统调用开销
- **低延迟**：锁很快释放时，立即获取
- **适用场景**：临界区执行时间短

**自旋锁的劣势：**
- **CPU 占用**：长时间自旋浪费 CPU
- **不适用场景**：临界区执行时间长

#### 0.5 等待队列机制

**等待线程的管理：**

```cpp
class mutex {
private:
    std::atomic<int> state{0};
    // 等待队列（内核维护）
    // Linux: futex 等待队列
    // Windows: 事件对象等待队列
    
public:
    void lock_slow() {
        // 1. 将当前线程加入等待队列
        // 2. 将线程状态设置为阻塞（BLOCKED）
        // 3. 触发调度器，切换到其他线程
        
        // Linux futex 实现：
        syscall(SYS_futex, &state, FUTEX_WAIT, 2, nullptr, nullptr, 0);
        // 参数说明：
        // - &state: 等待的地址
        // - FUTEX_WAIT: 等待操作
        // - 2: 期望的值（如果 state != 2，立即返回）
        // - nullptr: 超时时间（无限等待）
    }
    
    void unlock_slow() {
        // 1. 从等待队列中取出一个线程
        // 2. 将线程状态设置为就绪（READY）
        // 3. 触发调度器，唤醒线程
        
        // Linux futex 实现：
        syscall(SYS_futex, &state, FUTEX_WAKE, 1, nullptr, nullptr, 0);
        // 参数说明：
        // - FUTEX_WAKE: 唤醒操作
        // - 1: 唤醒的线程数量
    }
};
```

#### 0.6 内存屏障和内存顺序

**mutex 操作的内存语义：**

```cpp
class mutex {
public:
    void lock() {
        // memory_order_acquire: 获取操作
        // 保证后续的内存操作不会重排到 lock() 之前
        state.compare_exchange_weak(0, 1, std::memory_order_acquire);
        
        // 编译为：
        // x86: LOCK CMPXCHG + MFENCE（内存屏障）
        // ARM: LDREX/STREX + DMB（数据内存屏障）
    }
    
    void unlock() {
        // memory_order_release: 释放操作
        // 保证之前的内存操作不会重排到 unlock() 之后
        state.store(0, std::memory_order_release);
        
        // 编译为：
        // x86: MFENCE + MOV（内存屏障）
        // ARM: DMB + STR（数据内存屏障）
    }
};
```

**内存顺序保证：**

```cpp
// 线程1
mutex.lock();        // acquire 屏障
data = 42;           // 临界区操作
flag = true;         // 临界区操作
mutex.unlock();      // release 屏障

// 线程2
mutex.lock();        // acquire 屏障
int val = data;      // 保证看到 data = 42
bool f = flag;       // 保证看到 flag = true
mutex.unlock();      // release 屏障

// 内存屏障保证：
// 1. 线程1的 unlock() 之前的所有写操作
// 2. 对线程2的 lock() 之后的所有读操作可见
```

#### 0.7 性能开销分析

**mutex 操作的开销：**

| 阶段 | 操作 | 开销 | 说明 |
|------|------|------|------|
| **快速路径** | CAS 原子操作 | ~10ns | 无竞争时，用户态完成 |
| **自旋阶段** | 循环 CAS | ~100ns | 短时间等待，避免系统调用 |
| **系统调用** | futex/EnterCriticalSection | ~1-10μs | 进入内核，上下文切换 |
| **线程阻塞** | 线程切换 | ~1-100μs | 调度器切换，可能跨 CPU 核心 |
| **唤醒** | 系统调用 + 调度 | ~1-10μs | 唤醒等待线程 |

**性能优化策略：**

```cpp
// 优化1：自适应自旋
class adaptive_mutex {
    int spin_count = 1000;  // 初始自旋次数
    
    void lock() {
        // 根据历史等待时间调整自旋次数
        if (average_wait_time < threshold) {
            spin_count *= 2;  // 增加自旋
        } else {
            spin_count /= 2;  // 减少自旋
        }
    }
};

// 优化2：NUMA 感知
// 优先唤醒同一 NUMA 节点的线程

// 优化3：优先级继承
// 高优先级线程等待低优先级线程持有的锁时
// 临时提升低优先级线程的优先级
```

#### 0.8 死锁检测和避免

**操作系统级别的死锁检测：**

```cpp
// Linux: 死锁检测器（Deadlock Detector）
// 1. 维护锁依赖图
// 2. 检测循环依赖
// 3. 报告死锁信息

// Windows: 死锁超时机制
// 1. 设置锁超时时间
// 2. 超时后自动释放或报告错误
```

#### 0.9 完整示例：简化 mutex 实现

```cpp
#include <atomic>
#include <thread>
#include <linux/futex.h>
#include <sys/syscall.h>
#include <unistd.h>

class SimpleMutex {
private:
    std::atomic<int> state{0};  // 0=未锁定, 1=已锁定
    
    static void futex_wait(int* addr, int val) {
        syscall(SYS_futex, addr, FUTEX_WAIT, val, nullptr, nullptr, 0);
    }
    
    static void futex_wake(int* addr, int count) {
        syscall(SYS_futex, addr, FUTEX_WAKE, count, nullptr, nullptr, 0);
    }
    
public:
    void lock() {
        int expected = 0;
        // 快速路径：尝试获取锁
        if (state.compare_exchange_weak(expected, 1, 
                                       std::memory_order_acquire)) {
            return;
        }
        
        // 慢速路径：自旋等待
        for (int i = 0; i < 1000; ++i) {
            expected = 0;
            if (state.compare_exchange_weak(expected, 1, 
                                           std::memory_order_acquire)) {
                return;
            }
            std::this_thread::yield();
        }
        
        // 进入内核等待
        while (state.exchange(2, std::memory_order_acquire) != 0) {
            futex_wait(reinterpret_cast<int*>(&state), 2);
        }
    }
    
    void unlock() {
        if (state.exchange(0, std::memory_order_release) == 2) {
            futex_wake(reinterpret_cast<int*>(&state), 1);
        }
    }
};
```

#### 0.10 总结：mutex 实现原理

**核心要点：**

1. **两层实现**：用户态快速路径 + 内核态慢速路径
2. **自旋优化**：短时间自旋避免系统调用
3. **等待队列**：使用 futex/CriticalSection 管理等待线程
4. **内存屏障**：acquire/release 语义保证内存可见性
5. **性能权衡**：自旋时间 vs 系统调用开销

**实现层次：**
```
用户态（快速路径）
    ↓ CAS 原子操作
    ↓ 自旋等待
内核态（慢速路径）
    ↓ 系统调用
    ↓ 等待队列
    ↓ 线程调度
```

**记忆要点：**
- **mutex = 自旋 + 等待队列 = 两层实现**
- **快速路径 = CAS = 无系统调用**
- **慢速路径 = futex = 系统调用**
- **acquire/release = 内存屏障 = 可见性保证**

### 1. std::mutex 基础

```cpp
#include <thread>
#include <mutex>
#include <iostream>

std::mutex mtx;
int counter = 0;

void increment() {
    for (int i = 0; i < 100000; ++i) {
        mtx.lock();      // 加锁
        counter++;       // 临界区
        mtx.unlock();    // 解锁
    }
}

int main() {
    std::thread t1(increment);
    std::thread t2(increment);
    
    t1.join();
    t2.join();
    
    std::cout << "Counter: " << counter << std::endl;  // 应该是 200000
    return 0;
}
```

### 2. std::lock_guard（推荐）

```cpp
#include <thread>
#include <mutex>
#include <iostream>

std::mutex mtx;
int counter = 0;

void increment() {
    for (int i = 0; i < 100000; ++i) {
        std::lock_guard<std::mutex> lock(mtx);  // RAII：自动加锁/解锁
        counter++;
        // lock 离开作用域时自动解锁
    }
}

int main() {
    std::thread t1(increment);
    std::thread t2(increment);
    
    t1.join();
    t2.join();
    
    std::cout << "Counter: " << counter << std::endl;
    return 0;
}
```

**优势：**
- **RAII机制**：自动管理锁的生命周期
- **异常安全**：即使发生异常也能正确解锁
- **避免忘记解锁**

### 3. std::unique_lock（更灵活）

```cpp
#include <thread>
#include <mutex>
#include <iostream>

std::mutex mtx;

void flexibleLock() {
    std::unique_lock<std::mutex> lock(mtx);
    
    // 可以手动解锁
    lock.unlock();
    
    // 可以重新加锁
    lock.lock();
    
    // 可以延迟加锁
    std::unique_lock<std::mutex> lock2(mtx, std::defer_lock);
    lock2.lock();  // 手动加锁
    
    // 离开作用域时自动解锁
}
```

**特点：**
- 比 `lock_guard` 更灵活
- 支持延迟加锁、手动解锁、条件变量
- 性能略低于 `lock_guard`

### 4. std::shared_mutex（读写锁）

```cpp
#include <thread>
#include <shared_mutex>
#include <iostream>
#include <vector>

std::shared_mutex rw_mtx;
std::vector<int> data = {1, 2, 3, 4, 5};

void reader(int id) {
    std::shared_lock<std::shared_mutex> lock(rw_mtx);  // 共享锁（读锁）
    std::cout << "Reader " << id << " reads: ";
    for (int val : data) {
        std::cout << val << " ";
    }
    std::cout << std::endl;
}

void writer(int id) {
    std::unique_lock<std::shared_mutex> lock(rw_mtx);  // 独占锁（写锁）
    data.push_back(id);
    std::cout << "Writer " << id << " writes" << std::endl;
}

int main() {
    std::thread readers[3];
    std::thread writers[2];
    
    for (int i = 0; i < 3; ++i) {
        readers[i] = std::thread(reader, i);
    }
    
    for (int i = 0; i < 2; ++i) {
        writers[i] = std::thread(writer, i);
    }
    
    for (auto& t : readers) t.join();
    for (auto& t : writers) t.join();
    
    return 0;
}
```

**关键点：**
- **shared_lock**：多个线程可以同时持有（读操作）
- **unique_lock**：独占锁（写操作）
- **适用场景**：读多写少的场景

### 5. std::recursive_mutex（递归锁）

```cpp
#include <mutex>
#include <iostream>

std::recursive_mutex rmtx;

void recursiveFunc(int n) {
    std::lock_guard<std::recursive_mutex> lock(rmtx);
    
    if (n > 0) {
        std::cout << n << " ";
        recursiveFunc(n - 1);  // 递归调用，同一个线程可以再次加锁
    }
}

int main() {
    std::thread t(recursiveFunc, 5);
    t.join();
    return 0;
}
```

**适用场景：**
- 递归函数需要加锁
- 同一个线程需要多次加锁

## 三、条件变量（Condition Variable）

### 1. 生产者-消费者模式

```cpp
#include <thread>
#include <mutex>
#include <condition_variable>
#include <queue>
#include <iostream>

std::mutex mtx;
std::condition_variable cv;
std::queue<int> q;
bool finished = false;

void producer() {
    for (int i = 0; i < 10; ++i) {
        std::unique_lock<std::mutex> lock(mtx);
        q.push(i);
        std::cout << "Produced: " << i << std::endl;
        lock.unlock();
        cv.notify_one();  // 通知一个等待的线程
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
    
    {
        std::lock_guard<std::mutex> lock(mtx);
        finished = true;
    }
    cv.notify_all();  // 通知所有等待的线程
}

void consumer() {
    while (true) {
        std::unique_lock<std::mutex> lock(mtx);
        // 等待条件满足：队列不为空或生产完成
        cv.wait(lock, []() { return !q.empty() || finished; });
        
        if (!q.empty()) {
            int val = q.front();
            q.pop();
            lock.unlock();
            std::cout << "Consumed: " << val << std::endl;
        } else if (finished) {
            break;
        }
    }
}

int main() {
    std::thread p(producer);
    std::thread c(consumer);
    
    p.join();
    c.join();
    
    return 0;
}
```

**关键点：**
- `wait(lock, predicate)`：等待条件满足
- `notify_one()`：唤醒一个等待线程
- `notify_all()`：唤醒所有等待线程
- **必须配合互斥锁使用**

### 2. 条件变量的正确使用

```cpp
#include <thread>
#include <mutex>
#include <condition_variable>

std::mutex mtx;
std::condition_variable cv;
bool ready = false;

void waitForSignal() {
    std::unique_lock<std::mutex> lock(mtx);
    
    // ✅ 正确：使用predicate防止虚假唤醒
    cv.wait(lock, []() { return ready; });
    
    // ❌ 错误：不使用predicate（可能虚假唤醒）
    // cv.wait(lock);
    
    std::cout << "Signal received!" << std::endl;
}

void sendSignal() {
    {
        std::lock_guard<std::mutex> lock(mtx);
        ready = true;
    }
    cv.notify_one();
}
```

## 四、原子操作（Atomic）

### 1. std::atomic 基础

```cpp
#include <thread>
#include <atomic>
#include <iostream>

std::atomic<int> counter(0);  // 原子变量

void increment() {
    for (int i = 0; i < 100000; ++i) {
        counter++;  // 原子操作，无需加锁
    }
}

int main() {
    std::thread t1(increment);
    std::thread t2(increment);
    
    t1.join();
    t2.join();
    
    std::cout << "Counter: " << counter << std::endl;  // 200000
    return 0;
}
```

**优势：**
- **无锁编程**：性能优于互斥锁
- **线程安全**：保证操作的原子性
- **内存顺序**：提供内存顺序保证

### 2. 原子操作的内存顺序

```cpp
#include <atomic>
#include <thread>

std::atomic<bool> flag{false};
std::atomic<int> data{0};

void producer() {
    data.store(42, std::memory_order_release);  // 释放操作
    flag.store(true, std::memory_order_release);
}

void consumer() {
    while (!flag.load(std::memory_order_acquire)) {  // 获取操作
        std::this_thread::yield();
    }
    int val = data.load(std::memory_order_acquire);
    std::cout << "Data: " << val << std::endl;
}
```

**内存顺序：**
- `memory_order_relaxed`：最宽松，只保证原子性
- `memory_order_acquire`：获取操作，保证后续读操作不会重排到之前
- `memory_order_release`：释放操作，保证之前的写操作不会重排到之后
- `memory_order_seq_cst`：顺序一致性（默认，最严格）

### 3. compare_and_swap（CAS）

```cpp
#include <atomic>
#include <thread>

std::atomic<int> counter(0);

void increment() {
    int expected;
    do {
        expected = counter.load();
    } while (!counter.compare_exchange_weak(expected, expected + 1));
    // CAS：如果counter == expected，则设置为expected + 1
}

int main() {
    std::thread t1(increment);
    std::thread t2(increment);
    
    t1.join();
    t2.join();
    
    std::cout << "Counter: " << counter << std::endl;
    return 0;
}
```

### 4. atomic 的实现原理

#### 4.1 底层实现机制

**atomic 的底层实现依赖于 CPU 硬件支持：**

```cpp
// std::atomic<int> 的底层实现（简化版）
template<typename T>
class atomic {
private:
    T value;  // 实际存储的值
    
public:
    // 底层使用 CPU 原子指令
    T load() const {
        // 编译为：MOV + 内存屏障指令
        // x86: mov eax, [value] + mfence
        // ARM: ldr + dmb
        return __atomic_load_n(&value, __ATOMIC_SEQ_CST);
    }
    
    void store(T desired) {
        // 编译为：内存屏障指令 + MOV
        // x86: mfence + mov [value], desired
        // ARM: dmb + str
        __atomic_store_n(&value, desired, __ATOMIC_SEQ_CST);
    }
    
    bool compare_exchange_weak(T& expected, T desired) {
        // 编译为：LOCK CMPXCHG（x86）或 LDREX/STREX（ARM）
        // 这是硬件级别的原子操作
        return __atomic_compare_exchange_n(
            &value, &expected, desired, 
            false, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST
        );
    }
};
```

#### 4.2 CPU 指令支持

**x86/x64 架构：**

```cpp
// atomic<int>::operator++() 的底层实现
// 编译后的汇编代码（伪代码）

// C++ 代码：
std::atomic<int> counter(0);
counter++;

// 编译为 x86 汇编：
// LOCK XADD [counter], 1
// 或
// LOCK INC [counter]

// LOCK 前缀的作用：
// 1. 锁定内存总线，确保操作的原子性
// 2. 防止其他 CPU 核心同时访问同一内存
// 3. 保证缓存一致性（MESI 协议）
```

**ARM 架构：**

```cpp
// ARM 使用 Load-Link/Store-Conditional (LL/SC) 机制

// atomic<int>::compare_exchange_weak() 的底层实现
// 编译为 ARM 汇编：

// LDREX r0, [counter]      // Load-Exclusive：独占加载
// CMP r0, expected
// STREXEQ r1, desired, [counter]  // Store-Exclusive：条件存储
// CMP r1, #0               // 检查是否成功
// BNE retry                 // 失败则重试
```

#### 4.3 内存屏障（Memory Barrier）

**atomic 操作会自动插入内存屏障：**

```cpp
#include <atomic>

std::atomic<int> data{0};
std::atomic<bool> ready{false};

void producer() {
    data.store(42, std::memory_order_release);
    // 编译为：
    // MOV [data], 42
    // MFENCE 或 LOCK（内存屏障）
    
    ready.store(true, std::memory_order_release);
}

void consumer() {
    while (!ready.load(std::memory_order_acquire)) {
        // 编译为：
        // MFENCE 或 LOCK（内存屏障）
        // MOV eax, [ready]
    }
    
    int val = data.load(std::memory_order_acquire);
    // 保证在 ready 为 true 之后，data 的值一定是 42
}
```

**内存屏障类型：**

| 屏障类型 | x86 指令 | ARM 指令 | 作用 |
|---------|---------|---------|------|
| **Load Barrier** | LFENCE | DMB LD | 保证后续读操作不会重排到之前 |
| **Store Barrier** | SFENCE | DMB ST | 保证之前的写操作不会重排到之后 |
| **Full Barrier** | MFENCE | DMB SY | 保证所有内存操作不会重排 |

#### 4.4 缓存一致性协议（MESI）

**atomic 操作如何保证多核一致性：**

```
CPU Core 1                    CPU Core 2
    |                            |
    |  LOCK XADD [counter], 1   |
    |         |                  |
    |         v                  |
    |   [MESI 协议]              |
    |         |                  |
    |   1. 获取 Exclusive 状态   |
    |   2. 执行原子操作           |
    |   3. 通知其他核心           |
    |         |                  |
    |         v                  |
    |  其他核心的缓存行失效        |
    |         |                  |
    |         v                  |
    |   操作完成，释放锁          |
```

**MESI 状态：**
- **M (Modified)**：已修改，只有当前核心有最新数据
- **E (Exclusive)**：独占，当前核心独占，未修改
- **S (Shared)**：共享，多个核心都有副本
- **I (Invalid)**：无效，缓存行无效

#### 4.5 不同大小的 atomic 实现

**小类型（1-8 字节）：硬件原子指令**

```cpp
std::atomic<int> a;      // 4 字节，硬件支持
std::atomic<long> b;     // 8 字节，x64 硬件支持
std::atomic<char> c;     // 1 字节，硬件支持

// 编译为单条 CPU 指令：
// LOCK ADD [a], 1
```

**大类型（>8 字节）：锁实现**

```cpp
struct Large {
    int data[100];
};

std::atomic<Large> large;  // 400 字节，太大，使用内部锁

// 实现方式（简化）：
template<typename T>
class atomic {
private:
    mutable std::mutex mtx;  // 内部互斥锁
    T value;
    
public:
    T load() const {
        std::lock_guard<std::mutex> lock(mtx);
        return value;
    }
    
    void store(T desired) {
        std::lock_guard<std::mutex> lock(mtx);
        value = desired;
    }
};
```

**检查是否无锁：**

```cpp
#include <atomic>

std::atomic<int> small;
std::atomic<std::string> large;

std::cout << std::boolalpha;
std::cout << small.is_lock_free() << std::endl;    // true（硬件支持）
std::cout << large.is_lock_free() << std::endl;    // false（使用锁）
```

#### 4.6 atomic vs mutex 性能对比

**性能差异原因：**

```cpp
// 方式1：使用 mutex（慢）
std::mutex mtx;
int counter = 0;

void increment_mutex() {
    std::lock_guard<std::mutex> lock(mtx);  // 系统调用，可能阻塞
    counter++;                               // 普通操作
    // 解锁：系统调用
}

// 方式2：使用 atomic（快）
std::atomic<int> counter(0);

void increment_atomic() {
    counter++;  // 单条 CPU 指令，无系统调用
    // 编译为：LOCK XADD [counter], 1
}
```

**性能对比：**

| 操作 | mutex | atomic | 性能比 |
|------|-------|--------|--------|
| **简单操作** | ~100ns | ~10ns | **10倍** |
| **系统调用开销** | 有 | 无 | - |
| **上下文切换** | 可能 | 无 | - |
| **缓存失效** | 多 | 少 | - |

#### 4.7 CAS 操作的实现细节

**compare_exchange_weak vs compare_exchange_strong：**

```cpp
std::atomic<int> counter(0);

// weak：可能虚假失败（spurious failure）
bool weak_cas(int& expected, int desired) {
    // 在某些架构（如 ARM）上，即使值匹配也可能失败
    // 需要循环重试
    do {
        expected = counter.load();
        if (expected != desired - 1) {
            return false;
        }
    } while (!counter.compare_exchange_weak(expected, desired));
    return true;
}

// strong：保证不虚假失败
bool strong_cas(int& expected, int desired) {
    expected = counter.load();
    // 如果失败，一定是值不匹配
    return counter.compare_exchange_strong(expected, desired);
}
```

**使用建议：**
- **循环中使用 weak**：性能更好，允许虚假失败
- **单次检查使用 strong**：逻辑更清晰

#### 4.8 完整示例：无锁栈实现

```cpp
#include <atomic>
#include <memory>

template<typename T>
class LockFreeStack {
private:
    struct Node {
        T data;
        Node* next;
        Node(const T& d) : data(d), next(nullptr) {}
    };
    
    std::atomic<Node*> head{nullptr};
    
public:
    void push(const T& item) {
        Node* new_node = new Node(item);
        Node* old_head;
        do {
            old_head = head.load();
            new_node->next = old_head;
        } while (!head.compare_exchange_weak(old_head, new_node));
        // CAS：如果 head == old_head，则设置为 new_node
    }
    
    bool pop(T& result) {
        Node* old_head;
        Node* new_head;
        do {
            old_head = head.load();
            if (old_head == nullptr) {
                return false;
            }
            new_head = old_head->next;
        } while (!head.compare_exchange_weak(old_head, new_head));
        
        result = old_head->data;
        delete old_head;
        return true;
    }
};
```

**关键点：**
- 使用 CAS 实现无锁操作
- 避免 ABA 问题（需要版本号或垃圾回收）
- 性能优于基于 mutex 的实现

#### 4.9 总结：atomic 实现原理

**核心要点：**

1. **硬件支持**：小类型使用 CPU 原子指令（LOCK 前缀）
2. **内存屏障**：自动插入内存屏障保证内存顺序
3. **缓存一致性**：通过 MESI 协议保证多核一致性
4. **锁降级**：大类型自动使用内部锁
5. **CAS 操作**：基于硬件支持的 Compare-And-Swap

**实现层次：**
```
C++ std::atomic
    ↓
编译器内置函数（__atomic_*）
    ↓
CPU 原子指令（LOCK XADD, CMPXCHG 等）
    ↓
硬件内存屏障（MFENCE, DMB 等）
    ↓
缓存一致性协议（MESI）
```

**记忆要点：**
- **atomic = CPU 原子指令 = 无锁编程**
- **小类型 = 硬件支持 = 单条指令**
- **大类型 = 内部锁 = 性能下降**
- **CAS = Compare-And-Swap = 无锁数据结构基础**

## 五、死锁（Deadlock）

### 1. 死锁示例

```cpp
#include <thread>
#include <mutex>
#include <iostream>

std::mutex mtx1, mtx2;

void thread1() {
    std::lock_guard<std::mutex> lock1(mtx1);
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    std::lock_guard<std::mutex> lock2(mtx2);  // 等待mtx2
    std::cout << "Thread 1" << std::endl;
}

void thread2() {
    std::lock_guard<std::mutex> lock2(mtx2);
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    std::lock_guard<std::mutex> lock1(mtx1);  // 等待mtx1
    std::cout << "Thread 2" << std::endl;
}

// 运行结果：死锁！两个线程互相等待
```

### 2. 避免死锁的方法

**方法1：统一加锁顺序**

```cpp
void thread1() {
    std::lock_guard<std::mutex> lock1(mtx1);  // 总是先锁mtx1
    std::lock_guard<std::mutex> lock2(mtx2);  // 再锁mtx2
}

void thread2() {
    std::lock_guard<std::mutex> lock1(mtx1);  // 同样的顺序
    std::lock_guard<std::mutex> lock2(mtx2);
}
```

**方法2：std::lock（同时加锁）**

```cpp
#include <mutex>

void safeLock() {
    std::lock(mtx1, mtx2);  // 同时加锁，避免死锁
    std::lock_guard<std::mutex> lock1(mtx1, std::adopt_lock);
    std::lock_guard<std::mutex> lock2(mtx2, std::adopt_lock);
    // adopt_lock：表示锁已经被获取，只需要管理解锁
}
```

**方法3：超时锁（std::try_lock_for）**

```cpp
#include <mutex>
#include <chrono>

void tryLock() {
    std::unique_lock<std::mutex> lock1(mtx1);
    
    // 尝试加锁，超时则放弃
    if (std::unique_lock<std::mutex> lock2(mtx2, std::chrono::milliseconds(100))) {
        // 成功获取锁
    } else {
        // 超时，放弃操作，避免死锁
    }
}
```

## 六、线程安全的数据结构

### 1. 线程安全的队列

```cpp
#include <queue>
#include <mutex>
#include <condition_variable>

template<typename T>
class ThreadSafeQueue {
private:
    std::queue<T> q;
    mutable std::mutex mtx;
    std::condition_variable cv;
    
public:
    void push(const T& item) {
        std::lock_guard<std::mutex> lock(mtx);
        q.push(item);
        cv.notify_one();
    }
    
    bool try_pop(T& item) {
        std::lock_guard<std::mutex> lock(mtx);
        if (q.empty()) {
            return false;
        }
        item = q.front();
        q.pop();
        return true;
    }
    
    void wait_and_pop(T& item) {
        std::unique_lock<std::mutex> lock(mtx);
        cv.wait(lock, [this]() { return !q.empty(); });
        item = q.front();
        q.pop();
    }
    
    bool empty() const {
        std::lock_guard<std::mutex> lock(mtx);
        return q.empty();
    }
    
    size_t size() const {
        std::lock_guard<std::mutex> lock(mtx);
        return q.size();
    }
};
```

### 2. 线程安全的单例模式

```cpp
#include <mutex>

class Singleton {
private:
    static std::mutex mtx;
    static Singleton* instance;
    
    Singleton() = default;
    Singleton(const Singleton&) = delete;
    Singleton& operator=(const Singleton&) = delete;
    
public:
    static Singleton* getInstance() {
        if (instance == nullptr) {  // 双重检查锁定
            std::lock_guard<std::mutex> lock(mtx);
            if (instance == nullptr) {
                instance = new Singleton();
            }
        }
        return instance;
    }
};

Singleton* Singleton::instance = nullptr;
std::mutex Singleton::mtx;

// C++11更好的方式：使用局部静态变量（线程安全）
class Singleton2 {
private:
    Singleton2() = default;
    
public:
    static Singleton2& getInstance() {
        static Singleton2 instance;  // C++11保证线程安全
        return instance;
    }
};
```

## 七、线程池

### 1. 简单的线程池实现

```cpp
#include <thread>
#include <vector>
#include <queue>
#include <mutex>
#include <condition_variable>
#include <functional>
#include <future>

class ThreadPool {
private:
    std::vector<std::thread> workers;
    std::queue<std::function<void()>> tasks;
    std::mutex mtx;
    std::condition_variable cv;
    bool stop;
    
public:
    ThreadPool(size_t numThreads) : stop(false) {
        for (size_t i = 0; i < numThreads; ++i) {
            workers.emplace_back([this]() {
                while (true) {
                    std::function<void()> task;
                    {
                        std::unique_lock<std::mutex> lock(mtx);
                        cv.wait(lock, [this]() { return stop || !tasks.empty(); });
                        
                        if (stop && tasks.empty()) {
                            return;
                        }
                        
                        task = tasks.front();
                        tasks.pop();
                    }
                    task();
                }
            });
        }
    }
    
    template<typename F, typename... Args>
    auto enqueue(F&& f, Args&&... args) -> std::future<typename std::result_of<F(Args...)>::type> {
        using return_type = typename std::result_of<F(Args...)>::type;
        
        auto task = std::make_shared<std::packaged_task<return_type()>>(
            std::bind(std::forward<F>(f), std::forward<Args>(args)...)
        );
        
        std::future<return_type> result = task->get_future();
        {
            std::unique_lock<std::mutex> lock(mtx);
            if (stop) {
                throw std::runtime_error("enqueue on stopped ThreadPool");
            }
            tasks.emplace([task]() { (*task)(); });
        }
        cv.notify_one();
        return result;
    }
    
    ~ThreadPool() {
        {
            std::unique_lock<std::mutex> lock(mtx);
            stop = true;
        }
        cv.notify_all();
        for (std::thread& worker : workers) {
            worker.join();
        }
    }
};

// 使用示例
int main() {
    ThreadPool pool(4);
    
    auto future = pool.enqueue([](int x) { return x * x; }, 10);
    std::cout << "Result: " << future.get() << std::endl;
    
    return 0;
}
```

## 八、常见面试问题

### Q1: mutex 和 atomic 的区别？

**答案：**
- **mutex**：互斥锁，用于保护临界区，性能开销较大
- **atomic**：原子操作，无锁编程，性能更好，但只能用于简单操作

**选择原则：**
- 简单操作（如计数器）→ 使用 `atomic`
- 复杂操作（如多行代码）→ 使用 `mutex`

### Q2: lock_guard 和 unique_lock 的区别？

**答案：**
- **lock_guard**：简单、高效，自动加锁/解锁，不支持手动操作
- **unique_lock**：更灵活，支持延迟加锁、手动解锁、条件变量

**使用建议：**
- 一般情况用 `lock_guard`
- 需要条件变量或手动控制时用 `unique_lock`

### Q3: 什么是虚假唤醒（Spurious Wakeup）？

**答案：**
- 条件变量的 `wait()` 可能在没有 `notify()` 的情况下返回
- **解决方法**：使用带 predicate 的 `wait()`

```cpp
// ✅ 正确：使用predicate
cv.wait(lock, []() { return condition; });

// ❌ 错误：可能虚假唤醒
cv.wait(lock);
```

### Q4: 如何避免死锁？

**答案：**
1. **统一加锁顺序**：所有线程按相同顺序加锁
2. **std::lock**：同时加多个锁
3. **超时锁**：使用 `try_lock_for` 设置超时
4. **避免嵌套锁**：尽量减少锁的嵌套

### Q5: 线程安全的标准库容器？

**答案：**
- **标准库容器都不是线程安全的**（除了 `std::atomic`）
- 需要手动加锁保护
- 或者使用第三方线程安全容器库

## 九、总结

### 核心要点

1. **线程创建**：`std::thread`，必须 `join()` 或 `detach()`
2. **互斥锁**：`std::mutex`，配合 `lock_guard` 或 `unique_lock` 使用
3. **条件变量**：`std::condition_variable`，用于线程间通信
4. **原子操作**：`std::atomic`，无锁编程
5. **死锁避免**：统一顺序、`std::lock`、超时锁

### 记忆要点

- **lock_guard = RAII = 自动管理锁**
- **unique_lock = 灵活 = 条件变量必需**
- **atomic = 无锁 = 性能更好**
- **条件变量 = 线程通信 = 必须配合互斥锁**
- **死锁 = 互相等待 = 统一顺序避免**

这就是C++多线程的完整面试总结！🎯

