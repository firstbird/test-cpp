# C++ volatile 关键字详解

## 一、volatile 的基本概念

### 定义
`volatile` 是 C++ 的一个类型修饰符，告诉编译器该变量可能被程序之外的因素修改，编译器不应该对该变量进行优化。

### 核心作用
- **防止编译器优化**：告诉编译器不要假设变量的值
- **强制内存访问**：每次访问都从内存读取，不从寄存器缓存读取
- **保证可见性**：在多线程或硬件访问场景中保证数据可见性

## 二、volatile 的语法

```cpp
volatile int x;              // volatile 变量
volatile int* ptr;           // 指向 volatile 的指针
int* volatile ptr2;          // volatile 指针（指针本身是volatile）
volatile int* volatile ptr3; // volatile 指针指向 volatile 数据

// 类成员
class MyClass {
    volatile int member;     // volatile 成员变量
};
```

## 三、volatile 的主要用途

### 1. 硬件寄存器访问

```cpp
// 硬件寄存器通常由硬件自动修改
volatile uint32_t* const GPIO_STATUS = (volatile uint32_t*)0x40000000;

void readGPIO() {
    // 每次读取都从硬件寄存器读取，不从缓存读取
    uint32_t status = *GPIO_STATUS;
    
    // 编译器不能优化为：
    // uint32_t status = cached_value;  // ❌ 错误优化
}
```

### 2. 信号处理程序

```cpp
volatile bool signal_received = false;

void signal_handler(int sig) {
    signal_received = true;  // 信号处理程序修改
}

int main() {
    signal(SIGINT, signal_handler);
    
    while (!signal_received) {  // 必须每次都检查，不能优化
        // 做其他工作
    }
    
    // 如果没有 volatile，编译器可能优化为：
    // if (!signal_received) {
    //     while (true) { ... }  // 死循环，因为假设值不变
    // }
}
```

### 3. 多线程共享变量（注意：volatile 不是线程安全的！）

```cpp
// ⚠️ 注意：volatile 不能保证线程安全！
volatile int shared_counter = 0;

void thread1() {
    for (int i = 0; i < 1000; i++) {
        shared_counter++;  // 不是原子操作！
    }
}

void thread2() {
    for (int i = 0; i < 1000; i++) {
        shared_counter++;  // 不是原子操作！
    }
}

// 问题：shared_counter++ 不是原子操作
// volatile 只保证可见性，不保证原子性
// 应该使用 std::atomic<int> 而不是 volatile int
```

### 4. 内存映射 I/O

```cpp
// 内存映射的硬件设备
volatile uint8_t* const UART_TX = (volatile uint8_t*)0x10000000;
volatile uint8_t* const UART_RX = (volatile uint8_t*)0x10000001;

void sendChar(char c) {
    *UART_TX = c;  // 写入硬件寄存器
}

char receiveChar() {
    return *UART_RX;  // 从硬件寄存器读取
}
```

## 四、volatile 与编译器优化

### 没有 volatile 的情况

```cpp
int flag = 0;

void waitForFlag() {
    while (flag == 0) {
        // 编译器可能优化为：
        // if (flag == 0) {
        //     while (true) { }  // 死循环！
        // }
        // 因为编译器假设 flag 在循环中不会改变
    }
}
```

### 使用 volatile 的情况

```cpp
volatile int flag = 0;

void waitForFlag() {
    while (flag == 0) {
        // 编译器必须每次都从内存读取 flag
        // 不能优化为死循环
    }
}
```

### 实际优化示例

```cpp
// 示例1：循环优化
volatile int counter = 0;

void increment() {
    for (int i = 0; i < 1000; i++) {
        counter++;  // 每次循环都从内存读取和写入
    }
    // 如果没有 volatile，编译器可能优化为：
    // counter += 1000;  // 只执行一次
}

// 示例2：寄存器缓存
volatile int* ptr = (volatile int*)0x1000;

int read() {
    int a = *ptr;  // 第一次读取
    int b = *ptr;  // 第二次读取
    return a + b;
    // 如果没有 volatile，编译器可能优化为：
    // int a = *ptr;
    // return a + a;  // 假设两次读取值相同
}
```

## 五、volatile 的限制和注意事项

### 1. volatile 不是线程安全的

```cpp
// ❌ 错误用法：volatile 不能保证线程安全
volatile int counter = 0;

void thread1() {
    counter++;  // 不是原子操作！
}

void thread2() {
    counter++;  // 不是原子操作！
}

// ✅ 正确用法：使用 std::atomic
#include <atomic>
std::atomic<int> counter(0);

void thread1() {
    counter++;  // 原子操作
}
```

### 2. volatile 不保证原子性

```cpp
volatile int64_t value = 0;

void write() {
    value = 0x1234567890ABCDEF;  // 64位写入可能不是原子的
    // 在32位系统上，可能需要两次写入
    // 其他线程可能看到中间状态
}

// ✅ 正确用法：使用 std::atomic
std::atomic<int64_t> value(0);
```

### 3. volatile 不保证顺序

```cpp
volatile int a = 0;
volatile int b = 0;

void thread1() {
    a = 1;  // 操作1
    b = 2;  // 操作2
    // volatile 不保证操作1在操作2之前完成
    // CPU 可能重排序
}

// ✅ 正确用法：使用内存屏障或 std::atomic
std::atomic<int> a(0);
std::atomic<int> b(0);

void thread1() {
    a.store(1, std::memory_order_release);
    b.store(2, std::memory_order_release);
}
```

### 4. volatile 与 const 的组合

```cpp
// const volatile：只读的硬件寄存器
const volatile uint32_t* const READ_ONLY_REG = (volatile uint32_t*)0x40000000;

void readRegister() {
    uint32_t value = *READ_ONLY_REG;  // 可以读取
    // *READ_ONLY_REG = 0;            // ❌ 错误：const 禁止写入
}
```

## 六、volatile 与 C++11 的 std::atomic

### 对比表

| 特性 | volatile | std::atomic |
|------|----------|-------------|
| **防止编译器优化** | ✅ | ✅ |
| **保证可见性** | ✅ | ✅ |
| **保证原子性** | ❌ | ✅ |
| **保证顺序** | ❌ | ✅ |
| **线程安全** | ❌ | ✅ |
| **性能** | 较低 | 较高（可优化） |
| **适用场景** | 硬件访问、信号处理 | 多线程编程 |

### 使用建议

```cpp
// ❌ 多线程场景：不要用 volatile
volatile int shared_data = 0;  // 不安全

// ✅ 多线程场景：使用 std::atomic
#include <atomic>
std::atomic<int> shared_data(0);  // 安全

// ✅ 硬件访问：使用 volatile
volatile uint32_t* const HW_REG = (volatile uint32_t*)0x1000;

// ✅ 信号处理：使用 volatile
volatile bool signal_flag = false;
```

## 七、实际应用示例

### 示例1：硬件定时器

```cpp
// 硬件定时器寄存器
volatile uint32_t* const TIMER_COUNT = (volatile uint32_t*)0x20000000;

uint32_t getTimerCount() {
    // 必须从硬件读取，不能缓存
    return *TIMER_COUNT;
}

void resetTimer() {
    *TIMER_COUNT = 0;  // 写入硬件寄存器
}
```

### 示例2：中断服务程序

```cpp
volatile bool interrupt_flag = false;
volatile int interrupt_data = 0;

// 中断服务程序（由硬件调用）
void interrupt_handler() {
    interrupt_flag = true;
    interrupt_data = readFromHardware();
}

// 主程序
void main_loop() {
    while (true) {
        if (interrupt_flag) {  // 必须每次都检查
            process(interrupt_data);
            interrupt_flag = false;
        }
        // 其他工作
    }
}
```

### 示例3：内存映射设备

```cpp
// 内存映射的显示缓冲区
volatile uint8_t* const VIDEO_BUFFER = (volatile uint8_t*)0xB8000;

void writeToScreen(int x, int y, char c) {
    int offset = y * 80 + x;
    VIDEO_BUFFER[offset] = c;  // 直接写入显存
}
```

## 八、volatile 的常见误区

### 误区1：volatile 可以用于线程同步

```cpp
// ❌ 错误理解
volatile bool ready = false;
volatile int data = 0;

void producer() {
    data = 42;
    ready = true;  // 不保证在其他线程中可见的顺序
}

void consumer() {
    while (!ready) { }  // 可能永远看不到 ready = true
    int value = data;   // 可能读取到旧值
}

// ✅ 正确做法
#include <atomic>
std::atomic<bool> ready(false);
std::atomic<int> data(0);

void producer() {
    data.store(42, std::memory_order_relaxed);
    ready.store(true, std::memory_order_release);
}

void consumer() {
    while (!ready.load(std::memory_order_acquire)) { }
    int value = data.load(std::memory_order_relaxed);
}
```

### 误区2：volatile 可以防止数据竞争

```cpp
// ❌ 错误：volatile 不能防止数据竞争
volatile int counter = 0;

void increment() {
    counter++;  // 不是原子操作，可能丢失更新
}

// ✅ 正确：使用 std::atomic
std::atomic<int> counter(0);

void increment() {
    counter++;  // 原子操作
}
```

### 误区3：volatile 可以保证顺序

```cpp
// ❌ 错误：volatile 不保证内存顺序
volatile int a = 0;
volatile int b = 0;

void thread1() {
    a = 1;
    b = 2;  // CPU 可能重排序，b 可能在 a 之前写入
}

// ✅ 正确：使用内存屏障
std::atomic<int> a(0);
std::atomic<int> b(0);

void thread1() {
    a.store(1, std::memory_order_relaxed);
    std::atomic_thread_fence(std::memory_order_release);
    b.store(2, std::memory_order_relaxed);
}
```

## 九、volatile 的最佳实践

### 1. 何时使用 volatile

✅ **应该使用 volatile：**
- 硬件寄存器访问
- 内存映射 I/O
- 信号处理程序中的标志
- 被外部程序修改的变量（如调试器）
- 嵌入式系统中的特殊内存区域

❌ **不应该使用 volatile：**
- 多线程同步（使用 std::atomic）
- 线程安全（使用 mutex、atomic）
- 性能优化（volatile 会降低性能）

### 2. 代码示例

```cpp
// ✅ 正确：硬件访问
volatile uint32_t* const GPIO_REG = (volatile uint32_t*)0x40000000;

// ✅ 正确：信号处理
volatile sig_atomic_t signal_flag = 0;

// ❌ 错误：多线程共享
// volatile int shared_counter = 0;  // 不安全

// ✅ 正确：多线程共享
std::atomic<int> shared_counter(0);

// ✅ 正确：只读硬件寄存器
const volatile uint32_t* const STATUS_REG = (volatile uint32_t*)0x50000000;
```

## 十、总结

### volatile 的核心要点

1. **作用**：防止编译器优化，强制从内存读取
2. **适用场景**：硬件访问、信号处理、内存映射 I/O
3. **不适用场景**：多线程同步、线程安全
4. **替代方案**：多线程场景使用 `std::atomic`

### 记忆口诀

- **volatile = 易变的**（值可能被外部改变）
- **volatile ≠ 线程安全**（只保证可见性，不保证原子性）
- **硬件用 volatile，线程用 atomic**

### 关键区别

| 场景 | 使用 |
|------|------|
| 硬件寄存器 | `volatile` |
| 信号处理 | `volatile` |
| 多线程共享 | `std::atomic` |
| 线程同步 | `std::mutex` + `std::atomic` |

**记住：volatile 是给编译器看的，不是给 CPU 看的！** 🎯

