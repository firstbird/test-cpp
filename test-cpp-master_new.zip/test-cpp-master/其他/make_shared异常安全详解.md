# make_shared vs shared_ptr(new T) 异常安全详解

## 问题

为什么 `std::shared_ptr<int> p4(new int(100));` 可能内存泄漏？

## 核心理解

### 异常安全问题

**`shared_ptr(new T)` 的问题：**
- `new` 和 `shared_ptr` 构造是**两个独立的操作**
- 如果 `new` 成功但 `shared_ptr` 构造失败，内存会泄漏

**`make_shared` 的优势：**
- `new` 和 `shared_ptr` 构造是**原子操作**
- 如果失败，不会泄漏内存

## 详细分析

### shared_ptr(new T) 的问题

```cpp
std::shared_ptr<int> p4(new int(100));
```

**执行过程：**
```
步骤1：new int(100)
  - 分配内存
  - 构造对象
  - 返回指针

步骤2：shared_ptr 构造
  - 创建控制块
  - 设置引用计数
  - 如果这里抛出异常...
```

**问题场景：**

```cpp
void problematic() {
    // 假设 shared_ptr 构造过程中抛出异常
    std::shared_ptr<int> p4(new int(100));
    // 如果 shared_ptr 构造失败（抛出异常）：
    // 1. new int(100) 已经分配了内存
    // 2. 但 shared_ptr 还没有接管
    // 3. 内存泄漏！❌
}
```

### 实际异常场景

虽然 `shared_ptr` 的构造本身不太可能失败，但在**函数调用链**中可能出现：

```cpp
// 场景1：函数参数求值顺序
void func(std::shared_ptr<int> p1, std::shared_ptr<int> p2);

func(std::shared_ptr<int>(new int(1)), 
     std::shared_ptr<int>(new int(2)));
// 问题：new 和 shared_ptr 构造的顺序不确定
// 如果第一个 new 成功，第二个 new 抛出异常
// 第一个 new 的内存可能泄漏
```

**更准确的例子：**

```cpp
// 场景2：自定义删除器可能抛出异常
auto deleter = [](int* p) {
    // 如果这里抛出异常...
    delete p;
};

// 如果 shared_ptr 构造过程中 deleter 相关操作失败
std::shared_ptr<int> p(new int(100), deleter);
// new 成功，但 shared_ptr 构造失败
// 内存泄漏
```

## make_shared 的优势

### 异常安全

```cpp
auto p = std::make_shared<int>(100);
```

**执行过程：**
```
步骤1：make_shared 内部
  - 一次性分配内存（对象 + 控制块）
  - 构造对象
  - 创建 shared_ptr
  - 如果任何步骤失败，已分配的内存会被正确清理
```

**优势：**
- **原子操作**：`new` 和 `shared_ptr` 构造是原子的
- **异常安全**：如果失败，不会泄漏内存
- **性能优化**：可能一次分配（对象 + 控制块）

## 完整对比

### 方式1：shared_ptr(new T) - 可能内存泄漏

```cpp
std::shared_ptr<int> p(new int(100));
```

**问题：**
1. `new` 和 `shared_ptr` 构造是两个操作
2. 如果 `new` 成功但 `shared_ptr` 构造失败，内存泄漏
3. 需要两次内存分配（对象 + 控制块）

### 方式2：make_shared - 异常安全

```cpp
auto p = std::make_shared<int>(100);
```

**优势：**
1. `new` 和 `shared_ptr` 构造是原子操作
2. 异常安全，不会泄漏内存
3. 可能一次分配（对象 + 控制块），性能更好

## 实际示例

### 示例1：异常安全问题

```cpp
#include <memory>
#include <iostream>
#include <stdexcept>

// 模拟可能抛出异常的场景
class Resource {
public:
    Resource(int id) : id_(id) {
        if (id == 0) {
            throw std::runtime_error("Invalid ID");
        }
        std::cout << "Resource " << id_ << " created" << std::endl;
    }
    ~Resource() {
        std::cout << "Resource " << id_ << " destroyed" << std::endl;
    }
private:
    int id_;
};

void testSharedPtrNew() {
    try {
        // ❌ 可能内存泄漏
        std::shared_ptr<Resource> p(new Resource(0));
        // 如果 Resource 构造抛出异常：
        // new 已经分配了内存，但 shared_ptr 还没接管
        // 内存泄漏！
    } catch (const std::exception& e) {
        std::cout << "Exception: " << e.what() << std::endl;
        // 内存可能泄漏
    }
}

void testMakeShared() {
    try {
        // ✅ 异常安全
        auto p = std::make_shared<Resource>(0);
        // 如果 Resource 构造抛出异常：
        // make_shared 会正确清理，不会泄漏
    } catch (const std::exception& e) {
        std::cout << "Exception: " << e.what() << std::endl;
        // 不会内存泄漏
    }
}
```

### 示例2：函数参数求值顺序

```cpp
void func(std::shared_ptr<int> p1, std::shared_ptr<int> p2) {
    // ...
}

void test() {
    // ❌ 可能内存泄漏
    func(std::shared_ptr<int>(new int(1)), 
         std::shared_ptr<int>(new int(2)));
    // 问题：参数求值顺序不确定
    // 如果第一个 new 成功，第二个 new 抛出异常
    // 第一个 new 的内存可能泄漏
    
    // ✅ 异常安全
    func(std::make_shared<int>(1), 
         std::make_shared<int>(2));
    // make_shared 是异常安全的
}
```

## 更准确的说明

### unique_ptr 的情况

```cpp
std::unique_ptr<int> p3(new int(42));
```

**实际上，`unique_ptr` 不太容易内存泄漏：**
- `unique_ptr` 的构造是简单的指针赋值
- 不太可能抛出异常
- 但使用 `make_unique` 仍然更好（一致性、异常安全）

### shared_ptr 的情况

```cpp
std::shared_ptr<int> p4(new int(100));
```

**主要问题：**
1. **异常安全**：如果 `shared_ptr` 构造失败，内存泄漏
2. **性能**：需要两次内存分配（对象 + 控制块）
3. **代码一致性**：与 `make_shared` 不一致

## 内存分配对比

### shared_ptr(new T) - 两次分配

```
分配1：new int(100)
  ┌─────────┐
  │  对象    │
  └─────────┘

分配2：shared_ptr 控制块
  ┌─────────┐
  │控制块   │
  └─────────┘
```

### make_shared - 可能一次分配

```
一次分配：对象 + 控制块
  ┌─────────┬─────────┐
  │  对象    │ 控制块   │
  └─────────┴─────────┘
  
优势：
- 减少内存分配次数
- 提高缓存局部性
- 可能提高性能
```

## 总结

### 回答你的问题

**Q: 为什么 `std::shared_ptr<int> p4(new int(100));` 可能内存泄漏？**

**A: 因为 `new` 和 `shared_ptr` 构造是两个独立的操作。如果 `new` 成功但 `shared_ptr` 构造失败（抛出异常），`new` 分配的内存会泄漏。**

### 关键理解

1. **异常安全问题**
   - `shared_ptr(new T)`：两个操作，可能泄漏
   - `make_shared`：原子操作，异常安全

2. **性能问题**
   - `shared_ptr(new T)`：两次分配
   - `make_shared`：可能一次分配

3. **代码一致性**
   - 使用 `make_shared` 和 `make_unique` 更一致

### 记忆要点

- **`shared_ptr(new T)` = 两个操作 = 可能内存泄漏 = 性能差**
- **`make_shared` = 原子操作 = 异常安全 = 性能好**
- **优先使用 `make_shared` 和 `make_unique`**

这就是为什么可能内存泄漏的原因！🎯

