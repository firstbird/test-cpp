# C++ 基础语法与 STL 容器速查

---

## 一、基础语法速记

### 1. 类型与声明

| 写法 | 含义 |
|------|------|
| `int a;` | 默认未初始化（局部） |
| `int a = 0;` / `int a{};` | 初始化 |
| `auto x = expr;` | 类型推导 |
| `const int c = 1;` | 常量，不可改 |
| `int* p;` | 指针，存地址 |
| `int& r = a;` | 引用，别名，必须绑定对象 |
| `const int& cr = a;` | 常引用，只读别名 |
| `int arr[5];` | C 数组，固定长度（局部默认未初始化） |
| `int arr[5]{};` / `int arr[5] = {};` | C 数组，全部元素零初始化 |
| `int arr[5] = {1, 2};` | C 数组，前两项赋值，其余元素补 0 |
| `int arr[] = {1, 2, 3};` | C 数组，长度由初始化列表推导 |
| `std::array<int, 5> a{};` | `std::array` 固定长度（更像容器：有 `.size()`、可拷贝） |

- **指针**：`*p` 解引用，`&x` 取地址，`p->mem` 等价 `(*p).mem`
- **引用**：声明时绑定，不能改绑；函数参数用引用可避免拷贝、可修改实参

### 2. 控制流

```cpp
// if-else
if (cond) { } else if (cond) { } else { }

// for
for (int i = 0; i < n; ++i) { }
for (const auto& x : container) { }   // 范围 for，只读
for (auto& x : container) { }        // 可修改

// while
while (cond) { }
do { } while (cond);

// switch（整型/枚举）
switch (x) {
    case 1: ...; break;
    default: ...;
}
```

### 3. 函数

```cpp
// 声明 / 定义
返回类型 函数名(参数列表);

// 常用形式
void f(int a, int b = 0);           // 默认参数
void g(const std::vector<int>& v);   // 常引用，只读不拷贝
void h(int& r);                      // 引用，可修改实参
int  k(int x, int y) { return x+y; } // 返回值拷贝
```

- **重载**：同名函数，参数类型或个数不同
- **重载与默认参数**：注意二义性，少混用

### 4. 类与结构体

```cpp
class C {
public:
    C();                    // 默认构造
    C(int x);               // 带参构造
    C(const C& other);      // 拷贝构造
    C& operator=(const C&); // 拷贝赋值
    ~C();                   // 析构

    void f() const;         // 不修改成员
    int getX() const { return x_; }
private:
    int x_;
};

struct S { int a; int b; }; // 默认 public，常当数据聚合用
```

- **explicit**：`explicit C(int x);` 禁止隐式转换
- **成员初始化列表**：`C(int a) : x_(a) {}`，优先用

### 5. 内存与智能指针（速记）

| 写法 | 含义 |
|------|------|
| `new T` / `new T(args)` | 堆分配，返回 `T*`，需 `delete` |
| `delete p;` | 释放单个对象 |
| `std::unique_ptr<T> p(new T);` | 独占所有权，移动语义 |
| `std::shared_ptr<T> p = std::make_shared<T>(args);` | 共享所有权，引用计数 |
| `std::make_shared<T>(args)` | 推荐构造 shared_ptr |

### 6. 常用关键字

- **const**：常量/只读；`const 成员函数` 承诺不改成员
- **static**：静态存储；类内 static 成员属于类不属对象
- **inline**：建议内联（函数/变量）
- **namespace**：`namespace N { }`，使用 `N::name` 或 `using N::name;`

---

## 二、STL 顺序容器

### vector（动态数组）

| 操作 | API | 说明 |
|------|-----|------|
| 构造 | `vector<T> v;` `vector<T> v(n);` `vector<T> v(n, val);` | 空 / n 个默认值 / n 个 val |
| 大小 | `v.size()` `v.empty()` | 元素个数 / 是否为空 |
| 访问 | `v[i]` `v.at(i)` `v.front()` `v.back()` | 下标（不检查）/ 带检查 / 首 / 尾 |
| 修改 | `v.push_back(x)` `v.pop_back()` | 尾插 / 尾删 |
| 修改 | `v.insert(it, x)` `v.erase(it)` `v.clear()` | 在迭代器处插/删/清空 |
| 其他 | `v.reserve(n)` `v.resize(n)` | 预分配容量 / 改 size |

- **迭代器**：`v.begin()` / `v.end()`，`auto it = v.begin();`
- 尾插摊还 O(1)，中间 insert/erase 为 O(n)

### deque（双端队列）

| 操作 | API |
|------|-----|
| 两端 | `push_back(x)` `push_front(x)` `pop_back()` `pop_front()` |
| 访问 | `front()` `back()` `operator[]` |
| 其他 | 与 vector 类似的 `size()` `empty()` `insert` `erase` `clear()` |

### list（双向链表）

| 操作 | API |
|------|-----|
| 两端 | `push_back(x)` `push_front(x)` `pop_back()` `pop_front()` |
| 插入删除 | `insert(it, x)` `erase(it)` `remove(val)` 删除所有等于 val |
| 其他 | `size()` `empty()` `front()` `back()` `clear()` |
| 合并/翻转 | `merge(other)` `reverse()` `sort()` |

- 任意位置 insert/erase 为 O(1)（已持有迭代器时），不支持 `[]`

---

## 三、STL 关联容器

### set / multiset（有序集合，红黑树）

| 操作 | API | 说明 |
|------|-----|------|
| 构造 | `set<T> s;` `set<T> s(beg, end);` | 默认升序 |
| 插入 | `s.insert(x)` `s.insert(it, x)` | 返回 pair<it, bool> / it |
| 查找 | `s.find(x)` `s.count(x)` | 迭代器 / 个数（set 0 或 1） |
| 边界 | `s.lower_bound(x)` `s.upper_bound(x)` | ≥x 首个 / >x 首个 |
| 删除 | `s.erase(x)` `s.erase(it)` `s.erase(beg, end)` | 按值 / 按迭代器 / 区间 |
| 其他 | `s.size()` `s.empty()` `s.clear()` | |

- **multiset**：允许多个相同键，`count(x)` 可 >1
- 迭代器：`s.begin()` ~ `s.end()` 为有序

### map / multimap（有序键值对）

| 操作 | API | 说明 |
|------|-----|------|
| 构造 | `map<K,V> m;` | 键有序 |
| 访问 | `m[k]` `m.at(k)` | [] 无则插入；at 无则抛异常 |
| 插入 | `m.insert({k,v})` `m[k]=v` | insert 不覆盖；[] 会覆盖 |
| 查找 | `m.find(k)` `m.count(k)` | 迭代器 / 0 或 1 |
| 删除 | `m.erase(k)` `m.erase(it)` | |
| 其他 | `m.size()` `m.empty()` `m.clear()` | |

- 迭代器指向 `pair<const K, V>`，如 `it->first`、`it->second`
- **multimap**：一键多值，无 `operator[]`

### unordered_set / unordered_map（哈希表）

| 操作 | API |
|------|-----|
| 构造 | `unordered_set<T> s;` `unordered_map<K,V> m;` |
| 插入 | `s.insert(x)` `m[k]=v` `m.insert({k,v})` |
| 查找 | `s.find(x)` `s.count(x)` `m.find(k)` `m.count(k)` |
| 删除 | `s.erase(x)` `m.erase(k)` |
| 其他 | `size()` `empty()` `clear()` |

- 无序，平均 O(1) 查找；键类型需有 `hash` 与 `==`
- 无 `lower_bound`/`upper_bound`

---

## 四、STL 适配器容器

### queue（队列，FIFO）

| 操作 | API |
|------|-----|
| 入队/出队 | `push(x)` `pop()` |
| 访问 | `front()` `back()` |
| 其他 | `size()` `empty()` |

- 默认底层 `deque`；无迭代器，只能两端操作

### stack（栈，LIFO）

| 操作 | API |
|------|-----|
| 入栈/出栈 | `push(x)` `pop()` |
| 访问 | `top()` |
| 其他 | `size()` `empty()` |

### priority_queue（堆/优先队列）

| 操作 | API |
|------|-----|
| 入队/出队 | `push(x)` `pop()` |
| 访问 | `top()` 取最大（默认） |
| 其他 | `size()` `empty()` |

- 默认大顶堆：`priority_queue<int> pq;`
- 小顶堆：`priority_queue<int, vector<int>, greater<int>> pq;`
- 自定义比较：`priority_queue<T, vector<T>, Cmp> pq;`

---

## 五、string（字符串）

| 操作 | API |
|------|-----|
| 构造 | `string s;` `string s("hello");` `string s(n, 'c');` |
| 大小 | `s.size()` / `s.length()` `s.empty()` |
| 访问 | `s[i]` `s.at(i)` `s.front()` `s.back()` |
| 拼接 | `s += "x"` `s.append("x")` `s + "x"` 产生新串 |
| 子串 | `s.substr(pos, len)` 从 pos 取 len 个（len 可省到结尾） |
| 查找 | `s.find("ab")` `s.find('c', pos)` 从 pos 找，返回下标或 npos |
| 比较 | `s1 == s2` `s1.compare(s2)` |
| 修改 | `s.insert(pos, "x")` `s.erase(pos, len)` `s.replace(pos, len, "x")` `s.clear()` |

- `std::string::npos` 表示未找到，常为最大 size_t

---

## 六、迭代器与算法（速记）

- **五种迭代器**：input / output / forward / bidirectional / random_access  
  vector/deque 支持随机访问，list 双向，set/map 双向，unordered 前向。
- **常用算法**（头文件 `<algorithm>`）：
  - `sort(beg, end)` / `sort(beg, end, cmp)` 排序
  - `reverse(beg, end)` 翻转
  - `find(beg, end, val)` 找第一个 val
  - `lower_bound(beg, end, val)` / `upper_bound(beg, end, val)` 下/上界
  - `max(a,b)` `min(a,b)` `swap(a,b)`
  - `next_permutation(beg, end)` 下一个排列

---

## 七、常用头文件

```cpp
#include <iostream>   // cin, cout, endl
#include <vector>
#include <deque>
#include <list>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <queue>       // queue, priority_queue
#include <stack>
#include <string>
#include <algorithm>
#include <utility>     // pair, move, swap
#include <functional>  // less, greater
```

---

按「类型 → 容器 → 增删查」顺序记：先确定用顺序还是关联、要不要有序，再选 vector/deque/list/set/map/unordered_*，然后查上表对应 API 即可。
