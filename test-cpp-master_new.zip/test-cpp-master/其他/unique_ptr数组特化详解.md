# unique_ptr 数组特化详解

## 问题

为什么 `std::unique_ptr<int[]>` 可以直接使用 `arr[0]`？

## 核心理解

### unique_ptr 的两种特化

**1. 非数组版本 `unique_ptr<T>`**
- 用于单个对象
- 提供 `operator*` 和 `operator->`
- **没有 `operator[]`**
- 使用 `delete` 释放

**2. 数组版本 `unique_ptr<T[]>`**
- 用于数组
- 提供 `operator[]`
- **没有 `operator*` 和 `operator->`**
- 使用 `delete[]` 释放

## 详细分析

### 非数组版本 unique_ptr<T>

```cpp
std::unique_ptr<int> p(new int(42));

// ✅ 可以使用
*p = 100;        // operator*
int* raw = p.get();  // get() 返回原始指针

// ❌ 不能使用
// p[0] = 100;   // 编译错误！没有 operator[]
```

**原因：**
- `unique_ptr<T>` 是为单个对象设计的
- 只提供 `operator*` 和 `operator->`
- 不提供 `operator[]`

### 数组版本 unique_ptr<T[]>

```cpp
std::unique_ptr<int[]> arr(new int[10]);

// ✅ 可以使用
arr[0] = 1;      // operator[]
arr[1] = 2;

// ❌ 不能使用
// *arr = 1;     // 编译错误！没有 operator*
// arr->xxx;     // 编译错误！没有 operator->
```

**原因：**
- `unique_ptr<T[]>` 是为数组设计的
- 提供 `operator[]` 用于数组访问
- 不提供 `operator*` 和 `operator->`

## 标准库实现原理

### 模板特化

```cpp
// 非数组版本
template<typename T, typename Deleter = std::default_delete<T>>
class unique_ptr {
public:
    T& operator*() const;      // ✅ 有
    T* operator->() const;     // ✅ 有
    // operator[] 不存在         // ❌ 没有
};

// 数组版本特化
template<typename T, typename Deleter>
class unique_ptr<T[], Deleter> {
public:
    T& operator[](size_t index) const;  // ✅ 有
    // operator* 不存在                  // ❌ 没有
    // operator-> 不存在                 // ❌ 没有
};
```

## 完整对比

### 对比表

| 特性 | unique_ptr<T> | unique_ptr<T[]> |
|------|--------------|-----------------|
| **用途** | 单个对象 | 数组 |
| **operator*** | ✅ 有 | ❌ 无 |
| **operator->** | ✅ 有 | ❌ 无 |
| **operator[]** | ❌ 无 | ✅ 有 |
| **释放方式** | `delete` | `delete[]` |
| **删除器默认类型** | `std::default_delete<T>` | `std::default_delete<T[]>` |

## 代码示例

### 示例1：非数组版本

```cpp
#include <memory>
#include <iostream>

void singleObject() {
    std::unique_ptr<int> p = std::make_unique<int>(42);
    
    // ✅ 正确用法
    std::cout << *p << std::endl;      // 42
    std::cout << p.get() << std::endl; // 地址
    
    // ❌ 错误用法
    // std::cout << p[0] << std::endl;  // 编译错误！
}
```

### 示例2：数组版本

```cpp
#include <memory>
#include <iostream>

void arrayObject() {
    std::unique_ptr<int[]> arr(new int[10]);
    
    // ✅ 正确用法
    arr[0] = 1;
    arr[1] = 2;
    std::cout << arr[0] << std::endl;  // 1
    
    // ❌ 错误用法
    // std::cout << *arr << std::endl;  // 编译错误！
    // arr->xxx;                        // 编译错误！
}
```

### 示例3：使用 get() 访问数组

```cpp
void arrayAccess() {
    std::unique_ptr<int[]> arr(new int[10]);
    
    // 方式1：使用 operator[]
    arr[0] = 1;
    arr[1] = 2;
    
    // 方式2：使用 get() 获取原始指针
    int* raw = arr.get();
    raw[0] = 10;
    raw[1] = 20;
    
    std::cout << arr[0] << std::endl;  // 10
    std::cout << arr[1] << std::endl;  // 20
}
```

## 为什么这样设计？

### 设计原因

1. **类型安全**
   - 数组和单个对象是不同的类型
   - 通过模板特化区分，避免误用

2. **接口清晰**
   - 数组用 `[]`，对象用 `*` 和 `->`
   - 符合C++的惯用法

3. **自动选择删除器**
   - `unique_ptr<T>` 使用 `delete`
   - `unique_ptr<T[]>` 使用 `delete[]`
   - 避免内存管理错误

## 常见错误

### 错误1：对数组使用非数组版本

```cpp
// ❌ 错误：会导致内存泄漏
std::unique_ptr<int> arr(new int[10]);
// 问题：使用 delete 而不是 delete[]，导致未定义行为

// ✅ 正确
std::unique_ptr<int[]> arr(new int[10]);
```

### 错误2：对数组使用 operator*

```cpp
std::unique_ptr<int[]> arr(new int[10]);

// ❌ 错误
// *arr = 1;  // 编译错误！

// ✅ 正确
arr[0] = 1;
```

### 错误3：对单个对象使用 operator[]

```cpp
std::unique_ptr<int> p = std::make_unique<int>(42);

// ❌ 错误
// p[0] = 100;  // 编译错误！

// ✅ 正确
*p = 100;
```

## 最佳实践

### 1. 使用 make_unique（C++14）

```cpp
// ✅ 推荐：单个对象
auto p = std::make_unique<int>(42);

// ✅ 推荐：数组（C++14支持）
auto arr = std::make_unique<int[]>(10);
arr[0] = 1;
```

### 2. 明确类型

```cpp
// ✅ 明确表示是数组
std::unique_ptr<int[]> arr(new int[10]);

// ❌ 不推荐：容易混淆
std::unique_ptr<int> arr(new int[10]);  // 错误！应该用 int[]
```

### 3. 使用范围for（C++20）

```cpp
// C++20 支持
auto arr = std::make_unique<int[]>(10);
for (auto& val : arr) {  // ✅ C++20支持
    val = 0;
}
```

## 总结

### 回答你的问题

**Q: 为什么 `std::unique_ptr<int[]>` 可以直接使用 `arr[0]`？**

**A: 因为 `unique_ptr<T[]>` 是数组特化版本，提供了 `operator[]`！**

### 关键理解

1. **`unique_ptr<T>`**：单个对象，有 `operator*` 和 `operator->`，没有 `operator[]`
2. **`unique_ptr<T[]>`**：数组，有 `operator[]`，没有 `operator*` 和 `operator->`
3. **模板特化**：通过模板特化实现不同的接口
4. **自动选择删除器**：数组版本自动使用 `delete[]`

### 记忆要点

- **`unique_ptr<T>` = 对象 = `*p` 和 `p->` = `delete`**
- **`unique_ptr<T[]>` = 数组 = `arr[i]` = `delete[]`**
- **类型安全**：通过模板特化区分，避免误用

这就是 `unique_ptr` 数组特化的完整解析！🎯

