# weak_ptr 原理详解

## 一、weak_ptr 的核心原理

### 1. 什么是 weak_ptr？

**weak_ptr** 是一个**弱引用**智能指针，它：
- **不增加引用计数**
- **不拥有资源的所有权**
- **可以观察资源是否存在**
- **需要转换为 shared_ptr 才能访问资源**

### 2. 引用计数机制

**shared_ptr 的引用计数：**
- 每个 `shared_ptr` 都维护一个**控制块**（control block）
- 控制块包含：
  - **强引用计数**（shared count）：`shared_ptr` 的数量
  - **弱引用计数**（weak count）：`weak_ptr` 的数量
  - **原始指针**：指向实际对象

## 二、循环引用问题

### 问题场景

```cpp
struct Node {
    std::shared_ptr<Node> next;
    int value;
    
    Node(int v) : value(v) {}
    ~Node() {
        std::cout << "Node " << value << " destroyed" << std::endl;
    }
};

void circularReference() {
    auto n1 = std::make_shared<Node>(1);
    auto n2 = std::make_shared<Node>(2);
    
    n1->next = n2;  // n2的引用计数 = 2
    n2->next = n1;  // n1的引用计数 = 2
    
    // 离开作用域时：
    // n1的引用计数 = 2 - 1 = 1（n2->next还持有）
    // n2的引用计数 = 2 - 1 = 1（n1->next还持有）
    // 结果：两个对象都不会被释放！内存泄漏！
}
```

### 循环引用的图示

```
初始状态：
┌─────────────┐         ┌─────────────┐
│   Node 1    │         │   Node 2    │
│  value: 1   │         │  value: 2   │
│             │         │             │
│  ref_count: │         │  ref_count: │
│     1       │         │     1       │
└─────────────┘         └─────────────┘
      ▲                       ▲
      │                       │
      │                       │
   [n1]                    [n2]

建立循环引用后：
┌─────────────┐         ┌─────────────┐
│   Node 1    │────────>│   Node 2    │
│  value: 1   │         │  value: 2   │
│             │<────────│             │
│  ref_count: │         │  ref_count: │
│     2       │         │     2       │
└─────────────┘         └─────────────┘
      ▲                       ▲
      │                       │
      │                       │
   [n1]                    [n2]
   (栈上)                  (栈上)

离开作用域后（n1和n2被销毁）：
┌─────────────┐         ┌─────────────┐
│   Node 1    │────────>│   Node 2    │
│  value: 1   │         │  value: 2   │
│             │<────────│             │
│  ref_count: │         │  ref_count: │
│     1       │         │     1       │
└─────────────┘         └─────────────┘
      ▲                       ▲
      │                       │
      │                       │
    (已销毁)                (已销毁)
    
❌ 问题：两个对象互相引用，引用计数都是1，永远不会被释放！
```

## 三、weak_ptr 如何解决循环引用？

### 解决方案

**使用 weak_ptr 打破循环：**

```cpp
struct Node {
    std::shared_ptr<Node> next;
    std::weak_ptr<Node> prev;  // ✅ 使用weak_ptr
    int value;
    
    Node(int v) : value(v) {}
    ~Node() {
        std::cout << "Node " << value << " destroyed" << std::endl;
    }
};

void solveCircularReference() {
    auto n1 = std::make_shared<Node>(1);
    auto n2 = std::make_shared<Node>(2);
    
    n1->next = n2;      // n2的引用计数 = 2
    n2->prev = n1;      // n1的引用计数 = 1（weak_ptr不增加计数）
    
    // 离开作用域时：
    // n1的引用计数 = 1 - 1 = 0 ✅ 可以释放
    // n2的引用计数 = 2 - 1 = 1（n1->next还持有）
    // 但n1被释放后，n1->next也被释放
    // n2的引用计数 = 1 - 1 = 0 ✅ 可以释放
}
```

### 使用 weak_ptr 的图示

```
初始状态：
┌─────────────┐         ┌─────────────┐
│   Node 1    │         │   Node 2    │
│  value: 1   │         │  value: 2   │
│             │         │             │
│  ref_count: │         │  ref_count: │
│     1       │         │     1       │
└─────────────┘         └─────────────┘
      ▲                       ▲
      │                       │
      │                       │
   [n1]                    [n2]

建立连接后（使用weak_ptr）：
┌─────────────┐         ┌─────────────┐
│   Node 1    │────────>│   Node 2    │
│  value: 1   │         │  value: 2   │
│             │<·······│             │
│  ref_count: │         │  ref_count: │
│     1       │         │     2       │
└─────────────┘         └─────────────┘
      ▲                       ▲
      │                       │
      │                       │
   [n1]                    [n2]
   (栈上)                  (栈上)
   
   实线箭头：shared_ptr（增加引用计数）
   虚线箭头：weak_ptr（不增加引用计数）

离开作用域后（n1被销毁）：
┌─────────────┐         ┌─────────────┐
│   Node 1    │         │   Node 2    │
│  value: 1   │         │  value: 2   │
│             │         │             │
│  ref_count: │         │  ref_count: │
│     0       │         │     1       │
└─────────────┘         └─────────────┘
      ▲                       ▲
      │                       │
      │                       │
    (已销毁)              [n1->next]
                         (Node1的成员)
                         
✅ Node 1 引用计数为0，被释放
✅ Node 1 被释放后，n1->next也被释放
✅ Node 2 引用计数变为0，也被释放
```

## 四、weak_ptr 的内部实现原理

### 控制块结构

```
┌─────────────────────────────────────┐
│         Control Block                │
├─────────────────────────────────────┤
│  shared_count: 2  (强引用计数)       │
│  weak_count: 1    (弱引用计数)       │
│  raw_ptr: ──────> [实际对象]        │
└─────────────────────────────────────┘
         ▲              ▲
         │              │
    [shared_ptr]   [weak_ptr]
    (增加shared_count) (不增加shared_count，只增加weak_count)
```

### 关键机制

**1. 弱引用计数（weak_count）**
- `weak_ptr` 不增加 `shared_count`
- 但会增加 `weak_count`
- `weak_count` 用于管理控制块的生命周期

**2. 控制块的生命周期**
- 当 `shared_count = 0` 时，**对象被释放**
- 当 `shared_count = 0` 且 `weak_count = 0` 时，**控制块被释放**

**3. 对象访问**
- `weak_ptr` 不能直接访问对象
- 需要调用 `lock()` 转换为 `shared_ptr`
- 如果对象已被释放，`lock()` 返回空的 `shared_ptr`

## 五、详细代码示例

### 示例1：循环引用问题

```cpp
#include <memory>
#include <iostream>

struct Node {
    std::shared_ptr<Node> next;
    int value;
    
    Node(int v) : value(v) {
        std::cout << "Node " << value << " created" << std::endl;
    }
    ~Node() {
        std::cout << "Node " << value << " destroyed" << std::endl;
    }
};

void demonstrateCircularReference() {
    std::cout << "=== 循环引用问题 ===" << std::endl;
    auto n1 = std::make_shared<Node>(1);
    auto n2 = std::make_shared<Node>(2);
    
    std::cout << "n1 use_count: " << n1.use_count() << std::endl;  // 1
    std::cout << "n2 use_count: " << n2.use_count() << std::endl;  // 1
    
    n1->next = n2;
    std::cout << "After n1->next = n2:" << std::endl;
    std::cout << "n1 use_count: " << n1.use_count() << std::endl;  // 1
    std::cout << "n2 use_count: " << n2.use_count() << std::endl;  // 2
    
    n2->next = n1;  // ❌ 循环引用
    std::cout << "After n2->next = n1:" << std::endl;
    std::cout << "n1 use_count: " << n1.use_count() << std::endl;  // 2
    std::cout << "n2 use_count: " << n2.use_count() << std::endl;  // 2
    
    // 离开作用域时，n1和n2被销毁
    // 但引用计数都是1，对象不会被释放
    // ❌ 内存泄漏！
}
```

**输出：**
```
=== 循环引用问题 ===
Node 1 created
Node 2 created
n1 use_count: 1
n2 use_count: 1
After n1->next = n2:
n1 use_count: 1
n2 use_count: 2
After n2->next = n1:
n1 use_count: 2
n2 use_count: 2
// ❌ 离开作用域时，没有输出 "destroyed"，内存泄漏！
```

### 示例2：使用 weak_ptr 解决

```cpp
struct NodeFixed {
    std::shared_ptr<NodeFixed> next;
    std::weak_ptr<NodeFixed> prev;  // ✅ 使用weak_ptr
    int value;
    
    NodeFixed(int v) : value(v) {
        std::cout << "Node " << value << " created" << std::endl;
    }
    ~NodeFixed() {
        std::cout << "Node " << value << " destroyed" << std::endl;
    }
};

void solveWithWeakPtr() {
    std::cout << "\n=== 使用weak_ptr解决 ===" << std::endl;
    auto n1 = std::make_shared<NodeFixed>(1);
    auto n2 = std::make_shared<NodeFixed>(2);
    
    std::cout << "n1 use_count: " << n1.use_count() << std::endl;  // 1
    std::cout << "n2 use_count: " << n2.use_count() << std::endl;  // 1
    
    n1->next = n2;
    std::cout << "After n1->next = n2:" << std::endl;
    std::cout << "n1 use_count: " << n1.use_count() << std::endl;  // 1
    std::cout << "n2 use_count: " << n2.use_count() << std::endl;  // 2
    
    n2->prev = n1;  // ✅ 使用weak_ptr，不增加引用计数
    std::cout << "After n2->prev = n1 (weak_ptr):" << std::endl;
    std::cout << "n1 use_count: " << n1.use_count() << std::endl;  // 1 ✅
    std::cout << "n2 use_count: " << n2.use_count() << std::endl;  // 2
    
    // 离开作用域时：
    // n1引用计数 = 1 - 1 = 0 ✅ 释放
    // n1释放后，n1->next也被释放
    // n2引用计数 = 2 - 1 = 0 ✅ 释放
}
```

**输出：**
```
=== 使用weak_ptr解决 ===
Node 1 created
Node 2 created
n1 use_count: 1
n2 use_count: 1
After n1->next = n2:
n1 use_count: 1
n2 use_count: 2
After n2->prev = n1 (weak_ptr):
n1 use_count: 1
n2 use_count: 2
Node 1 destroyed  ✅
Node 2 destroyed  ✅
```

### 示例3：weak_ptr 的使用

```cpp
void weakPtrUsage() {
    std::cout << "\n=== weak_ptr使用示例 ===" << std::endl;
    
    std::shared_ptr<int> sp = std::make_shared<int>(42);
    std::weak_ptr<int> wp = sp;
    
    std::cout << "sp use_count: " << sp.use_count() << std::endl;  // 1
    std::cout << "wp expired: " << wp.expired() << std::endl;     // false
    
    // 使用lock()访问资源
    if (auto locked = wp.lock()) {
        std::cout << "Value: " << *locked << std::endl;  // 42
        std::cout << "sp use_count: " << sp.use_count() << std::endl;  // 2
    }
    
    sp.reset();  // 释放资源
    
    std::cout << "After sp.reset():" << std::endl;
    std::cout << "wp expired: " << wp.expired() << std::endl;  // true
    
    if (auto locked = wp.lock()) {
        // 不会执行，因为资源已释放
        std::cout << "This won't print" << std::endl;
    } else {
        std::cout << "Resource expired" << std::endl;
    }
}
```

## 六、weak_ptr 的关键方法

### 1. lock()

```cpp
std::shared_ptr<T> lock() const noexcept;
```

**作用：**
- 将 `weak_ptr` 转换为 `shared_ptr`
- 如果资源还存在，返回有效的 `shared_ptr`
- 如果资源已释放，返回空的 `shared_ptr`

**示例：**
```cpp
std::weak_ptr<int> wp = sp;
if (auto locked = wp.lock()) {
    // 资源存在，可以使用
    *locked = 100;
} else {
    // 资源已释放
}
```

### 2. expired()

```cpp
bool expired() const noexcept;
```

**作用：**
- 检查资源是否已释放
- 返回 `true` 表示资源已释放
- 返回 `false` 表示资源还存在

**示例：**
```cpp
if (wp.expired()) {
    // 资源已释放
} else {
    // 资源还存在
}
```

### 3. use_count()

```cpp
long use_count() const noexcept;
```

**作用：**
- 返回 `shared_ptr` 的引用计数
- 注意：在多线程环境中可能不准确

## 七、完整图示总结

### 循环引用问题图示

```
┌─────────────────────────────────────────┐
│         循环引用导致内存泄漏              │
└─────────────────────────────────────────┘

初始：
  n1 ──> Node1 (ref=1)
  n2 ──> Node2 (ref=1)

建立连接：
  n1 ──> Node1 (ref=2) <────┐
         │                  │
         │ next             │ next
         ▼                  │
  n2 ──> Node2 (ref=2) ─────┘

离开作用域：
  (n1销毁) Node1 (ref=1) <────┐
         │                    │
         │ next               │ next
         ▼                    │
  (n2销毁) Node2 (ref=1) ─────┘

❌ 两个对象互相引用，永远不会被释放！
```

### weak_ptr 解决方案图示

```
┌─────────────────────────────────────────┐
│      weak_ptr打破循环引用                │
└─────────────────────────────────────────┘

初始：
  n1 ──> Node1 (ref=1)
  n2 ──> Node2 (ref=1)

建立连接（使用weak_ptr）：
  n1 ──> Node1 (ref=1) ──────┐
         │                    │
         │ next (shared_ptr)  │ prev (weak_ptr)
         ▼                    │
  n2 ──> Node2 (ref=2) <──────┘
         (虚线表示weak_ptr，不增加计数)

离开作用域：
  (n1销毁) Node1 (ref=0) ✅ 释放
         │
         │ next也被释放
         ▼
  (n2销毁) Node2 (ref=1->0) ✅ 释放

✅ 循环被打破，对象可以正确释放！
```

## 八、总结

### weak_ptr 的核心原理

1. **不增加引用计数**
   - `weak_ptr` 不拥有资源所有权
   - 不增加 `shared_count`，只增加 `weak_count`

2. **可以观察资源**
   - 可以检查资源是否存在
   - 需要转换为 `shared_ptr` 才能访问

3. **打破循环引用**
   - 将循环中的某个 `shared_ptr` 改为 `weak_ptr`
   - 打破循环，允许对象被正确释放

### 关键理解

- **shared_ptr** = 强引用 = 增加引用计数 = 拥有所有权
- **weak_ptr** = 弱引用 = 不增加引用计数 = 不拥有所有权
- **循环引用** = 互相持有 `shared_ptr` = 内存泄漏
- **解决方案** = 使用 `weak_ptr` 打破循环 = 正确释放

### 记忆要点

- **weak_ptr = 弱引用 = 不增加计数 = 打破循环**
- **lock() = 转换为shared_ptr = 访问资源**
- **expired() = 检查资源是否存在**

这就是 weak_ptr 的完整原理解析！🎯

