# C++ 类相关面试总结

## 一、继承（Inheritance）

### 1. 继承方式

**三种继承方式：**

```cpp
class Base {
public:
    int public_member;
protected:
    int protected_member;
private:
    int private_member;
};

// 公有继承
class PublicDerived : public Base {
    // public_member: public
    // protected_member: protected
    // private_member: 不可访问
};

// 保护继承
class ProtectedDerived : protected Base {
    // public_member: protected
    // protected_member: protected
    // private_member: 不可访问
};

// 私有继承
class PrivateDerived : private Base {
    // public_member: private
    // protected_member: private
    // private_member: 不可访问
};
```

**记忆要点：**
- **public继承**：保持原有访问权限（最常用）
- **protected继承**：public变为protected
- **private继承**：所有成员变为private

### 2. 继承中的构造函数和析构函数

```cpp
class Base {
public:
    Base() {
        std::cout << "Base constructor" << std::endl;
    }
    ~Base() {
        std::cout << "Base destructor" << std::endl;
    }
};

class Derived : public Base {
public:
    Derived() {
        std::cout << "Derived constructor" << std::endl;
    }
    ~Derived() {
        std::cout << "Derived destructor" << std::endl;
    }
};

// 执行顺序：
// Base constructor
// Derived constructor
// Derived destructor
// Base destructor
```

**关键点：**
- 构造顺序：**基类 → 派生类**
- 析构顺序：**派生类 → 基类**

### 3. 多重继承

```cpp
class Base1 {
public:
    void func1() {}
};

class Base2 {
public:
    void func2() {}
};

class Derived : public Base1, public Base2 {
    // 继承自Base1和Base2
};

// 使用
Derived d;
d.func1();  // 来自Base1
d.func2();  // 来自Base2
```

**问题：菱形继承（Diamond Problem）**

```cpp
class A {
public:
    int value;
};

class B : public A {};
class C : public A {};

class D : public B, public C {
    // 问题：D有两个A的副本
    // d.value;  // ❌ 歧义：不知道是B::value还是C::value
};
```

**解决方案：虚继承（Virtual Inheritance）**

```cpp
class A {
public:
    int value;
};

class B : public virtual A {};  // 虚继承
class C : public virtual A {};  // 虚继承

class D : public B, public C {
    // ✅ 现在只有一个A的副本
    // d.value;  // ✅ 没有歧义
};
```

### 虚继承的原理和作用详解

#### 1. 问题根源：菱形继承的内存布局

**普通继承的内存布局：**

```cpp
class A {
public:
    int a_value;
};

class B : public A {
public:
    int b_value;
};

class C : public A {
public:
    int c_value;
};

class D : public B, public C {
public:
    int d_value;
};
```

**D对象的内存布局（普通继承）：**
```
D对象:
  [B部分]
    [A部分]
      a_value  ← A的副本1
    b_value
  [C部分]
    [A部分]
      a_value  ← A的副本2（重复！）
    c_value
  d_value
```

**问题：**
- D对象包含**两个A的副本**（一个来自B，一个来自C）
- 访问`d.a_value`时产生歧义：不知道是B::A::a_value还是C::A::a_value
- 浪费内存空间

#### 2. 虚继承的解决方案

**虚继承的内存布局：**

```cpp
class A {
public:
    int a_value;
};

class B : public virtual A {  // 虚继承
public:
    int b_value;
};

class C : public virtual A {  // 虚继承
public:
    int c_value;
};

class D : public B, public C {
public:
    int d_value;
};
```

**D对象的内存布局（虚继承）：**
```
D对象:
  [B部分]
    vptr_B      ← 指向虚基类表的指针
    b_value
  [C部分]
    vptr_C      ← 指向虚基类表的指针
    c_value
  d_value
  [A部分]       ← 共享的A部分（只有一份！）
    a_value
```

**关键点：**
- A部分被**共享**，只有一份副本
- B和C通过**虚基类表（vbtable）**来定位共享的A部分
- 访问`d.a_value`时没有歧义，因为只有一个A的副本

#### 3. 虚基类表（Virtual Base Table）原理

**虚基类表结构：**

```cpp
// 伪代码表示
struct D {
    // B部分
    void* vptr_B;        // 指向B的虚基类表
    int b_value;
    
    // C部分
    void* vptr_C;        // 指向C的虚基类表
    int c_value;
    
    int d_value;
    
    // 共享的A部分（在对象末尾）
    int a_value;
};

// B的虚基类表
vbtable_B:
  [0] offset_to_A = sizeof(B) + sizeof(C) + sizeof(int)  // A相对于B的偏移
```

**访问机制：**

```cpp
D d;
d.a_value = 10;  // 如何访问？

// 编译器生成的代码（伪代码）
// 1. 通过vptr_B找到虚基类表
// 2. 从虚基类表中获取A的偏移量
// 3. 计算A的实际地址：&d + offset_to_A
// 4. 访问a_value
```

#### 4. 虚继承的代价

**性能代价：**
- **额外的间接访问**：需要通过虚基类表查找共享基类
- **内存开销**：每个虚继承的类都需要一个虚基类表指针
- **构造/析构复杂度**：最底层的派生类负责构造/析构虚基类

**内存对比：**

```cpp
// 普通继承（菱形继承）
sizeof(D) = sizeof(B) + sizeof(C) + sizeof(int)
          = (sizeof(A) + sizeof(int)) + (sizeof(A) + sizeof(int)) + sizeof(int)
          = 2 * sizeof(A) + 3 * sizeof(int)  // A被存储两次

// 虚继承
sizeof(D) = sizeof(B) + sizeof(C) + sizeof(int) + sizeof(A)
          = (sizeof(vptr) + sizeof(int)) + (sizeof(vptr) + sizeof(int)) 
            + sizeof(int) + sizeof(A)
          = 2 * sizeof(vptr) + sizeof(A) + 3 * sizeof(int)  // A只存储一次
```

#### 5. 虚继承的构造顺序

```cpp
class A {
public:
    A() { std::cout << "A constructor" << std::endl; }
};

class B : public virtual A {
public:
    B() { std::cout << "B constructor" << std::endl; }
};

class C : public virtual A {
public:
    C() { std::cout << "C constructor" << std::endl; }
};

class D : public B, public C {
public:
    D() { std::cout << "D constructor" << std::endl; }
};

// 创建D对象
D d;
// 输出顺序：
// A constructor  ← 虚基类最先构造（由最底层派生类D负责）
// B constructor
// C constructor
// D constructor
```

**关键规则：**
- **虚基类由最底层的派生类直接构造**
- 构造顺序：虚基类 → 非虚基类（按继承顺序） → 派生类本身

#### 6. 何时使用虚继承

**适用场景：**
1. **解决菱形继承问题**：当继承层次中存在菱形结构时
2. **接口继承**：多个类需要共享同一个接口基类

**示例：接口继承**

```cpp
// 接口类
class IStream {
public:
    virtual void read() = 0;
    virtual void write() = 0;
};

// 输入流
class InputStream : public virtual IStream {
public:
    void read() override { /* ... */ }
};

// 输出流
class OutputStream : public virtual IStream {
public:
    void write() override { /* ... */ }
};

// 输入输出流（同时继承InputStream和OutputStream）
class IOStream : public InputStream, public OutputStream {
    // ✅ 只有一个IStream副本，可以同时实现read和write
};
```

**不适用场景：**
- 简单的单继承：不需要虚继承
- 性能敏感的场景：虚继承有额外开销
- 没有菱形继承问题：普通继承即可

#### 7. 完整示例对比

```cpp
#include <iostream>

// ========== 普通继承（有问题）==========
class A1 {
public:
    int value = 10;
};

class B1 : public A1 {};
class C1 : public A1 {};

class D1 : public B1, public C1 {
    // 问题：有两个A1的副本
    // d1.value;  // ❌ 编译错误：歧义
    // 需要使用：d1.B1::value 或 d1.C1::value
};

// ========== 虚继承（解决问题）==========
class A2 {
public:
    int value = 10;
};

class B2 : public virtual A2 {};
class C2 : public virtual A2 {};

class D2 : public B2, public C2 {
    // ✅ 只有一个A2的副本
    // d2.value;  // ✅ 没有歧义
};

int main() {
    D1 d1;
    // std::cout << d1.value << std::endl;  // ❌ 编译错误
    
    // 必须明确指定路径
    std::cout << d1.B1::value << std::endl;  // 10
    std::cout << d1.C1::value << std::endl;  // 10
    
    D2 d2;
    std::cout << d2.value << std::endl;  // ✅ 10（只有一个副本）
    
    // 验证只有一个A2副本
    std::cout << &d2.B2::value << std::endl;  // 地址1
    std::cout << &d2.C2::value << std::endl;  // 地址1（相同！）
    
    return 0;
}
```

#### 8. 总结

**虚继承的核心要点：**

1. **作用**：解决菱形继承问题，确保共享基类只有一份副本
2. **原理**：通过虚基类表（vbtable）实现间接访问共享基类
3. **代价**：额外的内存开销（虚基类表指针）和性能开销（间接访问）
4. **构造顺序**：虚基类由最底层派生类直接构造
5. **使用场景**：菱形继承、接口继承

**记忆要点：**
- **虚继承 = 共享基类 = 解决菱形继承**
- **虚基类表 = 间接访问 = 性能代价**
- **最底层派生类 = 负责构造虚基类**

## 二、虚函数（Virtual Functions）

### 1. 虚函数的基本概念

```cpp
class Base {
public:
    virtual void func() {  // 虚函数
        std::cout << "Base::func()" << std::endl;
    }
    
    void nonVirtual() {  // 非虚函数
        std::cout << "Base::nonVirtual()" << std::endl;
    }
};

class Derived : public Base {
public:
    void func() override {  // 重写虚函数
        std::cout << "Derived::func()" << std::endl;
    }
    
    void nonVirtual() {  // 隐藏基类函数
        std::cout << "Derived::nonVirtual()" << std::endl;
    }
};

// 使用
Base* ptr = new Derived();
ptr->func();         // Derived::func() ✅ 多态
ptr->nonVirtual();   // Base::nonVirtual() ❌ 非多态
```

### 2. 纯虚函数和抽象类

```cpp
class AbstractBase {
public:
    virtual void pureVirtual() = 0;  // 纯虚函数
    virtual ~AbstractBase() = default;  // 虚析构函数
};

class Concrete : public AbstractBase {
public:
    void pureVirtual() override {
        std::cout << "Concrete::pureVirtual()" << std::endl;
    }
};

// AbstractBase obj;  // ❌ 不能实例化抽象类
Concrete obj;  // ✅ 可以实例化
```

**关键点：**
- 纯虚函数：`= 0`，必须在派生类中实现
- 抽象类：包含纯虚函数的类，不能实例化
- 接口：所有函数都是纯虚函数的类

### 3. 虚析构函数

```cpp
class Base {
public:
    virtual ~Base() {  // ✅ 虚析构函数
        std::cout << "Base destructor" << std::endl;
    }
};

class Derived : public Base {
public:
    ~Derived() {
        std::cout << "Derived destructor" << std::endl;
    }
};

// 使用
Base* ptr = new Derived();
delete ptr;  // ✅ 正确调用Derived和Base的析构函数

// 如果没有虚析构函数：
// ❌ 只调用Base的析构函数，Derived的析构函数不会被调用
// 导致内存泄漏！
```

**关键点：**
- **基类必须有虚析构函数**，否则通过基类指针删除派生类对象会导致未定义行为
- 如果类有虚函数，析构函数也应该是虚的

### 4. 虚函数表（vtable）

```cpp
class Base {
public:
    virtual void func1() {}
    virtual void func2() {}
};

class Derived : public Base {
public:
    void func1() override {}
    // func2 继承自Base
};
```

**vtable结构：**
```
Base vtable:
  [0] Base::func1
  [1] Base::func2

Derived vtable:
  [0] Derived::func1  // 重写
  [1] Base::func2      // 继承
```

**关键理解：**
- 每个有虚函数的类都有一个vtable
- 对象包含一个指向vtable的指针（vptr）
- 通过vptr实现多态

### 5. override 和 final

```cpp
class Base {
public:
    virtual void func() {}
    virtual void finalFunc() {}
};

class Derived : public Base {
public:
    void func() override {  // ✅ 明确表示重写
        // ...
    }
    
    // void func2() override {}  // ❌ 编译错误：基类没有func2
    
    void finalFunc() final {  // ✅ final：禁止进一步重写
        // ...
    }
};

class FinalDerived : public Derived {
    // void finalFunc() {}  // ❌ 编译错误：final禁止重写
};
```

**关键点：**
- `override`：明确表示重写虚函数，如果基类没有对应虚函数则编译错误
- `final`：禁止进一步重写（用于类或函数）

## 三、模板（Templates）

### 1. 函数模板

```cpp
// 基本模板
template<typename T>
T max(T a, T b) {
    return a > b ? a : b;
}

// 使用
int m1 = max(3, 5);           // T = int
double m2 = max(3.5, 2.1);    // T = double

// 多个模板参数
template<typename T, typename U>
auto add(T a, U b) -> decltype(a + b) {
    return a + b;
}

// 使用
auto result = add(3, 4.5);  // T = int, U = double
```

#### 尾置返回类型（Trailing Return Type）语法详解

**`->` 语法说明：**

`auto func(...) -> ReturnType` 是C++11引入的**尾置返回类型**语法，其中 `->` 用于指定函数的返回类型。

**为什么需要尾置返回类型？**

在某些情况下，返回类型依赖于参数，但参数名在函数声明时还未定义，无法在函数名前指定返回类型。

**示例1：依赖参数的返回类型**

```cpp
// ❌ 错误：无法在函数名前使用 a 和 b
template<typename T, typename U>
decltype(a + b) add(T a, U b) {  // a 和 b 还未定义
    return a + b;
}

// ✅ 正确：使用尾置返回类型
template<typename T, typename U>
auto add(T a, U b) -> decltype(a + b) {  // a 和 b 已定义
    return a + b;
}
```

**示例2：复杂返回类型**

```cpp
// 返回指向数组的指针
int arr[10];

// ❌ 传统写法（复杂且容易出错）
int (*getArray())[10] {
    return &arr;
}

// ✅ 尾置返回类型（清晰）
auto getArray() -> int(*)[10] {
    return &arr;
}
```

**示例3：lambda表达式**

```cpp
// lambda表达式的返回类型
auto lambda = [](int x, int y) -> int {
    return x + y;
};

// 或者让编译器推导
auto lambda2 = [](int x, int y) {  // 自动推导返回类型
    return x + y;
};
```

**对比：前置返回类型 vs 尾置返回类型**

```cpp
// 方式1：前置返回类型（传统）
template<typename T>
T max(T a, T b) {
    return a > b ? a : b;
}

// 方式2：尾置返回类型（C++11）
template<typename T>
auto max(T a, T b) -> T {
    return a > b ? a : b;
}

// 方式3：自动推导（C++14，最简单）
template<typename T>
auto max(T a, T b) {  // 自动推导返回类型
    return a > b ? a : b;
}
```

**decltype 的作用**

`decltype(expression)` 用于获取表达式的类型，常用于：
1. 尾置返回类型中推导返回类型
2. 类型别名
3. 变量声明

```cpp
int x = 10;
double y = 3.14;

// decltype 获取表达式类型
decltype(x + y) result = x + y;  // result 的类型是 double

// 在模板中使用
template<typename T, typename U>
auto multiply(T a, U b) -> decltype(a * b) {
    return a * b;
}
```

**完整示例：尾置返回类型的实际应用**

```cpp
#include <iostream>
#include <vector>

// 示例1：返回迭代器类型
template<typename Container>
auto begin(Container& c) -> decltype(c.begin()) {
    return c.begin();
}

// 示例2：返回引用类型
template<typename T>
auto getRef(T& t) -> decltype(t) {  // 返回 T&
    return t;
}

// 示例3：条件返回类型
template<typename T>
auto process(T value) -> decltype(value > 0 ? value : -value) {
    return value > 0 ? value : -value;
}

int main() {
    std::vector<int> vec = {1, 2, 3};
    auto it = begin(vec);  // 自动推导为 std::vector<int>::iterator
    
    int x = 42;
    auto& ref = getRef(x);  // ref 是 int&
    ref = 100;  // 修改 x
    
    std::cout << x << std::endl;  // 输出：100
    
    return 0;
}
```

**关键要点总结：**

1. **`->` 语法**：C++11的尾置返回类型语法
2. **使用场景**：返回类型依赖参数、复杂返回类型、lambda表达式
3. **优势**：代码更清晰，特别是对于复杂返回类型
4. **C++14改进**：可以直接使用 `auto` 让编译器自动推导（不需要 `->`）

**记忆要点：**
- **`auto func() -> Type` = 尾置返回类型 = C++11**
- **`decltype(expr)` = 获取表达式类型 = 常用于尾置返回类型**
- **C++14后可以直接用 `auto` 自动推导**

### 2. 类模板

```cpp
template<typename T>
class Stack {
private:
    std::vector<T> data;
    
public:
    void push(const T& item) {
        data.push_back(item);
    }
    
    T pop() {
        T item = data.back();
        data.pop_back();
        return item;
    }
    
    bool empty() const {
        return data.empty();
    }
};

// 使用
Stack<int> intStack;
Stack<std::string> stringStack;
```

### 3. 模板特化

#### 模板特化的基本概念

**模板特化（Template Specialization）**：为模板的特定类型参数提供专门的实现，覆盖通用模板。

**重要理解：特化是可选的，不是必须的！**

```cpp
// 通用模板（主模板）
template<typename T>
class TypeInfo {
public:
    static const char* name() {
        return "unknown";
    }
};

// 特化（可选）
template<>
class TypeInfo<int> {
public:
    static const char* name() {
        return "int";
    }
};

template<>
class TypeInfo<double> {
public:
    static const char* name() {
        return "double";
    }
};

// 使用
std::cout << TypeInfo<int>::name() << std::endl;     // "int"（使用特化版本）
std::cout << TypeInfo<double>::name() << std::endl; // "double"（使用特化版本）
std::cout << TypeInfo<char>::name() << std::endl;   // "unknown"（使用通用模板）
```

#### 没有特化也能使用

**关键点：没有特化时，使用通用模板！**

```cpp
// 只有通用模板，没有特化
template<typename T>
class MyClass {
public:
    void func() {
        std::cout << "Generic template" << std::endl;
    }
};

// ✅ 完全可以使用，不需要特化
MyClass<int> obj1;      // 使用通用模板
MyClass<double> obj2;   // 使用通用模板
MyClass<std::string> obj3;  // 使用通用模板

obj1.func();  // 输出：Generic template
obj2.func();  // 输出：Generic template
obj3.func();  // 输出：Generic template
```

#### 特化的作用：为特定类型提供优化或特殊实现

**示例1：性能优化**

```cpp
// 通用模板：使用通用算法
template<typename T>
void sort(T* arr, int size) {
    // 通用排序算法（如快速排序）
    std::cout << "Generic sort" << std::endl;
}

// 特化：为int类型提供优化实现
template<>
void sort<int>(int* arr, int size) {
    // 针对int的特殊优化算法（如计数排序）
    std::cout << "Optimized int sort" << std::endl;
}

// 使用
double arr1[10];
sort(arr1, 10);  // 使用通用模板

int arr2[10];
sort(arr2, 10);  // 使用特化版本（更高效）
```

**示例2：处理特殊类型**

```cpp
// 通用模板：指针解引用
template<typename T>
void print(T value) {
    std::cout << value << std::endl;
}

// 特化：处理指针类型
template<typename T>
void print<T*>(T* ptr) {
    if (ptr) {
        std::cout << "Pointer: " << *ptr << std::endl;
    } else {
        std::cout << "Null pointer" << std::endl;
    }
}

// 使用
int x = 42;
print(x);    // 使用通用模板：输出 42
print(&x);   // 使用特化版本：输出 Pointer: 42
```

**示例3：类型信息**

```cpp
// 通用模板：默认实现
template<typename T>
class TypeInfo {
public:
    static const char* name() {
        return "unknown";
    }
    
    static size_t size() {
        return sizeof(T);
    }
};

// 特化：为特定类型提供准确信息
template<>
class TypeInfo<int> {
public:
    static const char* name() {
        return "int";
    }
    
    static size_t size() {
        return sizeof(int);
    }
};

// 使用
std::cout << TypeInfo<int>::name() << std::endl;      // "int"（特化）
std::cout << TypeInfo<char>::name() << std::endl;     // "unknown"（通用模板）
```

#### 特化的优先级

**编译器选择规则：**
1. **优先选择特化版本**（如果存在）
2. **否则使用通用模板**

```cpp
template<typename T>
void func(T t) {
    std::cout << "Generic" << std::endl;
}

template<>
void func<int>(int t) {
    std::cout << "Specialized for int" << std::endl;
}

// 使用
func(10);        // 输出：Specialized for int（使用特化）
func(3.14);      // 输出：Generic（使用通用模板）
func("hello");   // 输出：Generic（使用通用模板）
```

#### 函数模板特化 vs 函数重载

**注意：函数模板特化不如函数重载常用！**

```cpp
// 方式1：函数模板特化
template<typename T>
void process(T value) {
    std::cout << "Generic" << std::endl;
}

template<>
void process<int>(int value) {
    std::cout << "Specialized for int" << std::endl;
}

// 方式2：函数重载（更推荐）
template<typename T>
void process2(T value) {
    std::cout << "Generic" << std::endl;
}

void process2(int value) {  // 函数重载
    std::cout << "Overloaded for int" << std::endl;
}

// 使用
process(10);   // 特化版本
process2(10);  // 重载版本（更清晰）
```

#### 类模板特化（更常用）

**类模板特化比函数模板特化更常用：**

```cpp
// 通用模板
template<typename T>
class Container {
public:
    void add(const T& item) {
        std::cout << "Generic container" << std::endl;
    }
};

// 全特化：所有模板参数都指定
template<>
class Container<int> {
public:
    void add(const int& item) {
        std::cout << "Optimized int container" << std::endl;
    }
};

// 偏特化：部分模板参数指定（只适用于类模板）
template<typename T>
class Container<T*> {  // 针对指针类型的偏特化
public:
    void add(T* item) {
        std::cout << "Pointer container" << std::endl;
    }
};

// 使用
Container<double> c1;    // 通用模板
Container<int> c2;        // 全特化版本
Container<int*> c3;       // 偏特化版本（指针）
```

#### 完整示例：对比有无特化

```cpp
#include <iostream>
#include <string>

// ========== 场景1：没有特化 ==========
template<typename T>
void print1(T value) {
    std::cout << "Value: " << value << std::endl;
}

// ✅ 没有特化也能正常使用
print1(10);           // 输出：Value: 10
print1(3.14);         // 输出：Value: 3.14
print1("hello");      // 输出：Value: hello

// ========== 场景2：有特化 ==========
template<typename T>
void print2(T value) {
    std::cout << "Generic: " << value << std::endl;
}

template<>
void print2<int>(int value) {
    std::cout << "Specialized int: " << value << std::endl;
}

// 使用
print2(10);           // 输出：Specialized int: 10（特化版本）
print2(3.14);         // 输出：Generic: 3.14（通用模板）
print2("hello");      // 输出：Generic: hello（通用模板）

// ========== 场景3：类模板特化 ==========
template<typename T>
class Calculator {
public:
    T add(T a, T b) {
        return a + b;
    }
};

// 特化：为字符串提供特殊实现
template<>
class Calculator<std::string> {
public:
    std::string add(const std::string& a, const std::string& b) {
        return a + " + " + b;  // 字符串拼接的特殊格式
    }
};

// 使用
Calculator<int> calc1;
std::cout << calc1.add(3, 4) << std::endl;  // 输出：7（通用模板）

Calculator<std::string> calc2;
std::cout << calc2.add("hello", "world") << std::endl;  
// 输出：hello + world（特化版本）
```

#### 总结

**模板特化的核心要点：**

1. **特化是可选的**：没有特化时，使用通用模板
2. **特化的作用**：为特定类型提供优化或特殊实现
3. **优先级**：特化版本优先于通用模板
4. **使用场景**：
   - 性能优化（为特定类型提供高效实现）
   - 特殊处理（处理指针、数组等特殊类型）
   - 类型信息（提供准确的类型名称、大小等）

**记忆要点：**
- **特化 = 可选 = 为特定类型提供特殊实现**
- **没有特化 = 使用通用模板 = 完全正常**
- **特化优先级 > 通用模板**
- **类模板特化 > 函数模板特化（更常用）**

### 4. 模板参数

```cpp
// 类型参数
template<typename T>
class Container {};

// 非类型参数
template<int N>
class Array {
    int data[N];
};

// 使用
Array<10> arr;  // N = 10

// 模板模板参数
template<template<typename> class Container, typename T>
class Wrapper {
    Container<T> data;
};

// 使用
Wrapper<std::vector, int> w;  // Container = std::vector, T = int
```

### 5. SFINAE（Substitution Failure Is Not An Error）

```cpp
#include <type_traits>

// 使用SFINAE进行类型萃取
template<typename T>
typename std::enable_if<std::is_integral<T>::value, T>::type
process(T value) {
    return value * 2;
}

template<typename T>
typename std::enable_if<std::is_floating_point<T>::value, T>::type
process(T value) {
    return value * 1.5;
}

// 使用
int i = process(10);        // 调用第一个版本
double d = process(3.14);   // 调用第二个版本
```

### 6. 可变参数模板（Variadic Templates）

```cpp
// 递归终止
void print() {
    std::cout << std::endl;
}

// 递归展开
template<typename T, typename... Args>
void print(T first, Args... args) {
    std::cout << first << " ";
    print(args...);  // 递归调用
}

// 使用
print(1, 2.5, "hello", 'c');  // 输出：1 2.5 hello c
```

## 四、访问控制

### 1. 访问修饰符

```cpp
class MyClass {
public:
    int public_member;      // 任何地方都可以访问
    
protected:
    int protected_member;   // 类内和派生类可以访问
    
private:
    int private_member;     // 只有类内可以访问
};
```

### 2. friend 关键字

```cpp
class MyClass {
private:
    int private_data;
    
    friend class FriendClass;  // 友元类
    friend void friendFunction(MyClass& obj);  // 友元函数
};

class FriendClass {
public:
    void access(MyClass& obj) {
        obj.private_data = 100;  // ✅ 可以访问私有成员
    }
};

void friendFunction(MyClass& obj) {
    obj.private_data = 200;  // ✅ 可以访问私有成员
}
```

## 五、构造函数和析构函数

### 1. 默认构造函数

```cpp
class MyClass {
public:
    MyClass() = default;  // 使用编译器生成的默认构造函数
    // 或
    MyClass() {
        // 自定义默认构造函数
    }
};
```

### 2. 拷贝构造函数和拷贝赋值

```cpp
class MyClass {
public:
    // 拷贝构造函数
    MyClass(const MyClass& other) {
        // 深拷贝
    }
    
    // 拷贝赋值
    MyClass& operator=(const MyClass& other) {
        if (this != &other) {
            // 深拷贝
        }
        return *this;
    }
    
    // 删除拷贝（C++11）
    MyClass(const MyClass&) = delete;
    MyClass& operator=(const MyClass&) = delete;
};
```

### 3. 移动构造函数和移动赋值

```cpp
class MyClass {
public:
    // 移动构造函数
    MyClass(MyClass&& other) noexcept {
        // 转移资源
        data_ = other.data_;
        other.data_ = nullptr;
    }
    
    // 移动赋值
    MyClass& operator=(MyClass&& other) noexcept {
        if (this != &other) {
            // 释放当前资源
            delete data_;
            // 转移资源
            data_ = other.data_;
            other.data_ = nullptr;
        }
        return *this;
    }
    
private:
    int* data_;
};
```

### 4. 委托构造函数（C++11）

```cpp
class MyClass {
public:
    MyClass(int a, int b, int c) 
        : a_(a), b_(b), c_(c) {}
    
    MyClass(int a) : MyClass(a, 0, 0) {}  // 委托给上面的构造函数
    MyClass() : MyClass(0, 0, 0) {}        // 委托给上面的构造函数
    
private:
    int a_, b_, c_;
};
```

## 六、运算符重载

### 1. 基本运算符重载

```cpp
class Complex {
public:
    Complex(double r, double i) : real(r), imag(i) {}
    
    // 运算符重载
    Complex operator+(const Complex& other) const {
        return Complex(real + other.real, imag + other.imag);
    }
    
    Complex& operator+=(const Complex& other) {
        real += other.real;
        imag += other.imag;
        return *this;
    }
    
    // 输出运算符（必须是友元或全局函数）
    friend std::ostream& operator<<(std::ostream& os, const Complex& c) {
        os << c.real << "+" << c.imag << "i";
        return os;
    }
    
private:
    double real, imag;
};
```

### 2. 特殊运算符

```cpp
class MyClass {
public:
    // 下标运算符
    int& operator[](int index) {
        return data_[index];
    }
    
    // 函数调用运算符（仿函数）
    int operator()(int a, int b) {
        return a + b;
    }
    
    // 类型转换运算符
    operator int() const {
        return value_;
    }
    
private:
    int data_[10];
    int value_;
};
```

## 七、static 成员

### 1. static 成员变量

```cpp
class MyClass {
public:
    static int count;  // 声明
    
    MyClass() {
        count++;  // 所有对象共享
    }
};

int MyClass::count = 0;  // 定义（必须在类外）

// 使用
MyClass::count = 10;  // 通过类名访问
MyClass obj;
obj.count = 20;  // 通过对象访问（不推荐）
```

### 2. static 成员函数

```cpp
class MyClass {
public:
    static int getCount() {
        return count;  // 只能访问static成员
    }
    
private:
    static int count;
};

// 使用
int c = MyClass::getCount();  // 通过类名调用
```

## 八、const 成员函数

```cpp
class MyClass {
public:
    void nonConstFunc() {
        // 可以修改成员变量
        value_ = 100;
    }
    
    void constFunc() const {
        // 不能修改成员变量
        // value_ = 100;  // ❌ 编译错误
        std::cout << value_ << std::endl;  // ✅ 可以读取
    }
    
    // const重载
    int getValue() const {
        return value_;  // const对象调用
    }
    
    int& getValue() {
        return value_;  // 非const对象调用
    }
    
private:
    mutable int mutable_value_;  // mutable：const函数中也可以修改
    int value_;
};
```

## 九、常见面试问题

### Q1: 虚函数和纯虚函数的区别？

**答案：**
- **虚函数**：有默认实现，派生类可以选择重写
- **纯虚函数**：没有实现（`= 0`），派生类必须实现

### Q2: 为什么基类析构函数应该是虚函数？

**答案：**
- 如果基类析构函数不是虚函数，通过基类指针删除派生类对象时，只会调用基类析构函数
- 导致派生类析构函数不被调用，可能内存泄漏

### Q3: 模板特化和偏特化的区别？

**答案：**
- **全特化**：所有模板参数都指定
- **偏特化**：部分模板参数指定（只适用于类模板）

### Q4: override 关键字的作用？

**答案：**
- 明确表示重写虚函数
- 如果基类没有对应虚函数，编译错误
- 提高代码可读性和安全性

### Q5: 继承和组合的区别？

**答案：**
- **继承（is-a）**：派生类是基类的一种
- **组合（has-a）**：类包含另一个类的对象

```cpp
// 继承
class Car : public Vehicle {};  // Car is a Vehicle

// 组合
class Car {
    Engine engine_;  // Car has an Engine
};
```

## 十、完整示例

### 示例1：继承和多态

```cpp
#include <iostream>
#include <memory>
#include <vector>

class Shape {
public:
    virtual double area() const = 0;  // 纯虚函数
    virtual ~Shape() = default;      // 虚析构函数
};

class Circle : public Shape {
private:
    double radius_;
    
public:
    Circle(double r) : radius_(r) {}
    
    double area() const override {
        return 3.14159 * radius_ * radius_;
    }
};

class Rectangle : public Shape {
private:
    double width_, height_;
    
public:
    Rectangle(double w, double h) : width_(w), height_(h) {}
    
    double area() const override {
        return width_ * height_;
    }
};

int main() {
    std::vector<std::unique_ptr<Shape>> shapes;
    shapes.push_back(std::make_unique<Circle>(5.0));
    shapes.push_back(std::make_unique<Rectangle>(4.0, 6.0));
    
    for (const auto& shape : shapes) {
        std::cout << "Area: " << shape->area() << std::endl;
    }
    
    return 0;
}
```

### 示例2：模板类

```cpp
#include <iostream>
#include <vector>

template<typename T>
class Stack {
private:
    std::vector<T> data_;
    
public:
    void push(const T& item) {
        data_.push_back(item);
    }
    
    T pop() {
        T item = data_.back();
        data_.pop_back();
        return item;
    }
    
    bool empty() const {
        return data_.empty();
    }
    
    size_t size() const {
        return data_.size();
    }
};

int main() {
    Stack<int> intStack;
    intStack.push(1);
    intStack.push(2);
    intStack.push(3);
    
    while (!intStack.empty()) {
        std::cout << intStack.pop() << " ";
    }
    
    return 0;
}
```

## 十一、总结

### 核心要点

1. **继承**：public继承最常用，注意构造/析构顺序
2. **虚函数**：实现多态，基类析构函数必须是虚函数
3. **模板**：代码复用，编译时多态
4. **访问控制**：public/protected/private，friend关键字
5. **构造函数**：默认/拷贝/移动，委托构造函数
6. **运算符重载**：自定义类型行为

### 记忆要点

- **public继承 = is-a关系 = 最常用**
- **虚函数 = 多态 = 运行时绑定**
- **模板 = 代码复用 = 编译时多态**
- **虚析构函数 = 必须 = 避免内存泄漏**

这就是C++类相关知识的完整面试总结！🎯

