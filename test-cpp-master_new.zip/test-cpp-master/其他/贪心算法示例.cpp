#include <iostream>
#include <vector>
#include <algorithm>
#include <climits>
using namespace std;

/**
 * 贪心算法经典示例
 */

// ========== 示例1：活动选择问题 ==========

struct Activity {
    int start, end;
};

bool activityCmp(const Activity& a, const Activity& b) {
    return a.end < b.end;  // 按结束时间排序
}

vector<Activity> selectActivities(vector<Activity>& activities) {
    sort(activities.begin(), activities.end(), activityCmp);
    
    vector<Activity> result;
    result.push_back(activities[0]);
    int lastEnd = activities[0].end;
    
    for (int i = 1; i < activities.size(); i++) {
        if (activities[i].start >= lastEnd) {
            result.push_back(activities[i]);
            lastEnd = activities[i].end;
        }
    }
    
    return result;
}

// ========== 示例2：找零问题（贪心，注意：不一定最优） ==========

vector<int> coinChangeGreedy(int amount, vector<int>& coins) {
    sort(coins.rbegin(), coins.rend());  // 从大到小排序
    
    vector<int> result;
    for (int coin : coins) {
        while (amount >= coin) {
            result.push_back(coin);
            amount -= coin;
        }
    }
    
    return result;
}

// ========== 示例3：跳跃游戏 ==========

bool canJump(vector<int>& nums) {
    int maxReach = 0;
    
    for (int i = 0; i < nums.size(); i++) {
        if (i > maxReach) {
            return false;  // 无法到达当前位置
        }
        maxReach = max(maxReach, i + nums[i]);
    }
    
    return true;
}

// ========== 示例4：合并区间 ==========

vector<vector<int>> mergeIntervals(vector<vector<int>>& intervals) {
    sort(intervals.begin(), intervals.end());
    
    vector<vector<int>> result;
    result.push_back(intervals[0]);
    
    for (int i = 1; i < intervals.size(); i++) {
        if (intervals[i][0] <= result.back()[1]) {
            // 重叠：合并
            result.back()[1] = max(result.back()[1], intervals[i][1]);
        } else {
            // 不重叠：添加新区间
            result.push_back(intervals[i]);
        }
    }
    
    return result;
}

// ========== 示例5：分发糖果 ==========

int candy(vector<int>& ratings) {
    int n = ratings.size();
    vector<int> candies(n, 1);
    
    // 从左到右：处理右邻居
    for (int i = 1; i < n; i++) {
        if (ratings[i] > ratings[i - 1]) {
            candies[i] = candies[i - 1] + 1;
        }
    }
    
    // 从右到左：处理左邻居
    for (int i = n - 2; i >= 0; i--) {
        if (ratings[i] > ratings[i + 1]) {
            candies[i] = max(candies[i], candies[i + 1] + 1);
        }
    }
    
    int sum = 0;
    for (int c : candies) {
        sum += c;
    }
    return sum;
}

// ========== 示例6：买卖股票的最佳时机（简单版） ==========

int maxProfit(vector<int>& prices) {
    int profit = 0;
    
    for (int i = 1; i < prices.size(); i++) {
        if (prices[i] > prices[i - 1]) {
            // 贪心：只要今天比昨天高就卖
            profit += prices[i] - prices[i - 1];
        }
    }
    
    return profit;
}

int main() {
    cout << "=== 贪心算法示例 ===" << endl;
    
    // 示例1：活动选择
    cout << "\n1. 活动选择问题：" << endl;
    vector<Activity> activities = {
        {1, 4}, {3, 5}, {0, 6}, {5, 7}, {8, 9}, {5, 9}
    };
    vector<Activity> selected = selectActivities(activities);
    cout << "选择的活动数量: " << selected.size() << endl;
    for (auto& a : selected) {
        cout << "[" << a.start << ", " << a.end << "] ";
    }
    cout << endl;
    
    // 示例2：找零
    cout << "\n2. 找零问题（贪心）：" << endl;
    vector<int> coins = {1, 5, 10, 25};
    int amount = 67;
    vector<int> change = coinChangeGreedy(amount, coins);
    cout << "找零 " << amount << " 需要: ";
    for (int c : change) {
        cout << c << " ";
    }
    cout << "共 " << change.size() << " 个硬币" << endl;
    
    // 示例3：跳跃游戏
    cout << "\n3. 跳跃游戏：" << endl;
    vector<int> nums1 = {2, 3, 1, 1, 4};
    vector<int> nums2 = {3, 2, 1, 0, 4};
    cout << "nums1 能否到达: " << (canJump(nums1) ? "是" : "否") << endl;
    cout << "nums2 能否到达: " << (canJump(nums2) ? "是" : "否") << endl;
    
    // 示例4：合并区间
    cout << "\n4. 合并区间：" << endl;
    vector<vector<int>> intervals = {{1,3}, {2,6}, {8,10}, {15,18}};
    vector<vector<int>> merged = mergeIntervals(intervals);
    cout << "合并后的区间: ";
    for (auto& interval : merged) {
        cout << "[" << interval[0] << "," << interval[1] << "] ";
    }
    cout << endl;
    
    // 示例5：分发糖果
    cout << "\n5. 分发糖果：" << endl;
    vector<int> ratings = {1, 0, 2};
    cout << "最少需要糖果: " << candy(ratings) << endl;
    
    // 示例6：买卖股票
    cout << "\n6. 买卖股票最佳时机：" << endl;
    vector<int> prices = {7, 1, 5, 3, 6, 4};
    cout << "最大利润: " << maxProfit(prices) << endl;
    
    return 0;
}

