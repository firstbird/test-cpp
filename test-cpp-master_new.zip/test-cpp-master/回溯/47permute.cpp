#include <vector>
#include <algorithm>

using namespace std;
class Solution {
    vector<int> vis;
    
    public:
        vector<vector<int>> permuteUnique(vector<int>& nums) {
            vector<vector<int>> ans;
            vector<int> perm;
            vis.resize(nums.size());
            sort(nums.begin(), nums.end());
            dfs(nums, ans, 0, perm);
            return ans;
        }
        void dfs(vector<int>& nums, vector<vector<int>>& ans, int idx, vector<int>& perm)     {
            if (idx == nums.size()) {
                ans.emplace_back(perm);
                return;
            }
            for (int i = 0; i < (int)nums.size(); ++i) {
                //“在同一层里，相同的数只让排在最前面的那个被选，后面的都跳过。”
                if (vis[i] || (i > 0 && nums[i] == nums[i - 1] && !vis[i - 1])) {
                    continue;
                }
                perm.emplace_back(nums[i]);
                vis[i] = 1;
                dfs(nums, ans, idx + 1, perm);
                vis[i] = 0;
                perm.pop_back();
            }
        }
    

    };