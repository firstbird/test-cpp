#include <atomic>
#include <thread>
#include <vector>
#include <iostream>
#include <cassert>
using namespace std;

/**
 * 原子操作和内存序 (Memory Ordering) 示例
 */

// 1. 基本的原子操作
atomic<int> counter(0);

void increment_counter(int times) {
    for (int i = 0; i < times; i++) {
        counter.fetch_add(1, memory_order_relaxed);
    }
}

// 2. Compare-And-Swap (CAS) 操作
atomic<int> value(0);

bool compare_and_swap(int expected, int desired) {
    return value.compare_exchange_weak(expected, desired);
}

// 3. 内存序示例
atomic<bool> flag(false);
atomic<int> data(0);

// 生产者：使用release语义
void producer() {
    data.store(42, memory_order_relaxed);
    flag.store(true, memory_order_release); // release: 之前的所有操作对acquire可见
}

// 消费者：使用acquire语义
void consumer() {
    while (!flag.load(memory_order_acquire)) { // acquire: 能看到release之前的所有操作
        // 忙等待
    }
    assert(data.load(memory_order_relaxed) == 42);
}

// 4. 顺序一致性 (Sequential Consistency) - 默认最强保证
atomic<int> x(0), y(0);
atomic<int> r1(0), r2(0);

void thread1() {
    x.store(1, memory_order_seq_cst); // 顺序一致性
    r1 = y.load(memory_order_seq_cst);
}

void thread2() {
    y.store(1, memory_order_seq_cst);
    r2 = x.load(memory_order_seq_cst);
}

// 5. 原子指针
atomic<int*> ptr(nullptr);

void set_pointer(int* p) {
    ptr.store(p, memory_order_release);
}

int* get_pointer() {
    return ptr.load(memory_order_acquire);
}

// 6. 原子标志 (atomic_flag) - 唯一保证lock-free的类型
atomic_flag lock_flag = ATOMIC_FLAG_INIT;

void spin_lock() {
    while (lock_flag.test_and_set(memory_order_acquire)) {
        // 自旋等待
    }
}

void spin_unlock() {
    lock_flag.clear(memory_order_release);
}

// 7. 双重检查锁定模式 (Double-Checked Locking)
class Singleton {
private:
    static atomic<Singleton*> instance;
    static mutex mtx;
    
    Singleton() = default;
    
public:
    static Singleton* getInstance() {
        Singleton* tmp = instance.load(memory_order_acquire);
        if (tmp == nullptr) {
            lock_guard<mutex> lock(mtx);
            tmp = instance.load(memory_order_relaxed);
            if (tmp == nullptr) {
                tmp = new Singleton();
                instance.store(tmp, memory_order_release);
            }
        }
        return tmp;
    }
};

atomic<Singleton*> Singleton::instance(nullptr);
mutex Singleton::mtx;

int main() {
    cout << "=== Atomic Operations Demo ===" << endl;
    
    // 1. 基本原子操作
    cout << "\n1. Basic atomic operations:" << endl;
    vector<thread> threads;
    for (int i = 0; i < 4; i++) {
        threads.emplace_back(increment_counter, 1000);
    }
    
    for (auto& t : threads) {
        t.join();
    }
    
    cout << "Counter value: " << counter.load() << " (expected: 4000)" << endl;
    
    // 2. CAS操作
    cout << "\n2. Compare-And-Swap:" << endl;
    value.store(10);
    bool success = compare_and_swap(10, 20);
    cout << "CAS(10, 20): " << (success ? "Success" : "Failed") << endl;
    cout << "Value after CAS: " << value.load() << endl;
    
    // 3. 内存序
    cout << "\n3. Memory ordering:" << endl;
    thread prod(producer);
    thread cons(consumer);
    prod.join();
    cons.join();
    cout << "Memory ordering test passed!" << endl;
    
    // 4. 顺序一致性
    cout << "\n4. Sequential consistency:" << endl;
    for (int i = 0; i < 1000; i++) {
        x.store(0);
        y.store(0);
        r1.store(0);
        r2.store(0);
        
        thread t1(thread1);
        thread t2(thread2);
        t1.join();
        t2.join();
        
        // 顺序一致性保证：r1和r2不能同时为0
        assert(!(r1.load() == 0 && r2.load() == 0));
    }
    cout << "Sequential consistency test passed!" << endl;
    
    // 5. 自旋锁
    cout << "\n5. Spin lock:" << endl;
    spin_lock();
    cout << "Lock acquired" << endl;
    spin_unlock();
    cout << "Lock released" << endl;
    
    return 0;
}

