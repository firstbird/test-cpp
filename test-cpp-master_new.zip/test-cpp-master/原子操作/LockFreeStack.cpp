#include <atomic>
#include <memory>
#include <iostream>
#include <thread>
#include <vector>
using namespace std;

/**
 * Lock-free Stack 实现
 * 使用原子操作和CAS (Compare-And-Swap) 实现无锁栈
 */

template<typename T>
class LockFreeStack {
private:
    struct Node {
        shared_ptr<T> data;
        Node* next;
        
        Node(const T& d) : data(make_shared<T>(d)), next(nullptr) {}
    };
    
    atomic<Node*> head_;
    
public:
    LockFreeStack() : head_(nullptr) {}
    
    ~LockFreeStack() {
        // 简单清理，实际应该更仔细处理
        while (Node* old_head = head_.load()) {
            head_.store(old_head->next);
            delete old_head;
        }
    }
    
    void push(const T& data) {
        Node* new_node = new Node(data);
        Node* old_head = head_.load();
        
        do {
            old_head = head_.load();
            new_node->next = old_head;
        } while (!head_.compare_exchange_weak(old_head, new_node));
        // compare_exchange_weak: 如果head_ == old_head，则head_ = new_node
        // 否则，old_head = head_（更新为当前值）
    }
    
    bool pop(T& result) {
        Node* old_head = head_.load();
        
        do {
            if (old_head == nullptr) {
                return false;
            }
        } while (!head_.compare_exchange_weak(old_head, old_head->next));
        
        result = *(old_head->data);
        delete old_head;
        return true;
    }
    
    bool empty() const {
        return head_.load() == nullptr;
    }
};

// 测试代码
void producer(LockFreeStack<int>& stack, int id, int count) {
    for (int i = 0; i < count; i++) {
        stack.push(id * 1000 + i);
        this_thread::sleep_for(chrono::milliseconds(1));
    }
}

void consumer(LockFreeStack<int>& stack, int& sum) {
    int value;
    int local_sum = 0;
    int count = 0;
    
    while (count < 50) { // 每个消费者处理50个元素
        if (stack.pop(value)) {
            local_sum += value;
            count++;
        } else {
            this_thread::sleep_for(chrono::milliseconds(1));
        }
    }
    
    sum = local_sum;
}

int main() {
    LockFreeStack<int> stack;
    vector<thread> threads;
    vector<int> sums(4, 0);
    
    // 创建2个生产者线程
    for (int i = 0; i < 2; i++) {
        threads.emplace_back(producer, ref(stack), i, 100);
    }
    
    // 创建4个消费者线程
    for (int i = 0; i < 4; i++) {
        threads.emplace_back(consumer, ref(stack), ref(sums[i]));
    }
    
    // 等待所有线程完成
    for (auto& t : threads) {
        t.join();
    }
    
    int total_sum = 0;
    for (int s : sums) {
        total_sum += s;
    }
    
    cout << "Total sum from consumers: " << total_sum << endl;
    cout << "Stack empty: " << (stack.empty() ? "Yes" : "No") << endl;
    
    return 0;
}

