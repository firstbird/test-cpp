#include <string>
#include <vector>
using namespace std;

/**
 * LeetCode 28: 实现 strStr()
 * 实现 strStr() 函数。
 * 给你两个字符串 haystack 和 needle ，请你在 haystack 字符串中找出 needle 字符串出现的第一个位置（下标从 0 开始）。
 * 如果不存在，则返回  -1 。
 * 
 * 使用KMP算法实现
 */
class Solution {
public:
    int strStr(string haystack, string needle) {
        if (needle.empty()) {
            return 0;
        }
        
        int n = haystack.size();
        int m = needle.size();
        
        // 构建next数组（前缀函数）
        vector<int> next = buildNext(needle);
        
        int j = 0; // needle的指针
        for (int i = 0; i < n; i++) {
            // 不匹配时，回退j
            while (j > 0 && haystack[i] != needle[j]) {
                j = next[j - 1];
            }
            
            // 匹配时，移动j
            if (haystack[i] == needle[j]) {
                j++;
            }
            
            // 完全匹配
            if (j == m) {
                return i - m + 1;
            }
        }
        
        return -1;
    }
    
private:
    // 构建next数组（前缀函数）
    // next[i] 表示 needle[0:i] 的最长相等前后缀的长度
    vector<int> buildNext(const string& pattern) {
        int m = pattern.size();
        vector<int> next(m, 0);
        
        int j = 0; // 前缀末尾位置
        for (int i = 1; i < m; i++) {
            // 不匹配时，回退j
            while (j > 0 && pattern[i] != pattern[j]) {
                j = next[j - 1];
            }
            
            // 匹配时，j前进
            if (pattern[i] == pattern[j]) {
                j++;
            }
            
            next[i] = j;
        }
        
        return next;
    }
};

