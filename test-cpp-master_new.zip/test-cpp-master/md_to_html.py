#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Markdown to HTML converter
"""
import sys
import os

def markdown_to_html(md_file, html_file):
    """Convert markdown file to HTML"""
    # Read markdown file
    with open(md_file, 'r', encoding='utf-8') as f:
        md_content = f.read()
    
    # Simple markdown to HTML conversion
    html_content = md_content
    
    # Headers
    html_content = html_content.replace('# ', '<h1>').replace('\n# ', '</h1>\n<h1>')
    html_content = html_content.replace('## ', '<h2>').replace('\n## ', '</h2>\n<h2>')
    html_content = html_content.replace('### ', '<h3>').replace('\n### ', '</h3>\n<h3>')
    html_content = html_content.replace('#### ', '<h4>').replace('\n#### ', '</h4>\n<h4>')
    
    # Bold
    import re
    html_content = re.sub(r'\*\*(.*?)\*\*', r'<strong>\1</strong>', html_content)
    html_content = re.sub(r'\*(.*?)\*', r'<em>\1</em>', html_content)
    
    # Lists
    lines = html_content.split('\n')
    in_list = False
    html_lines = []
    for line in lines:
        if line.strip().startswith('- '):
            if not in_list:
                html_lines.append('<ul>')
                in_list = True
            html_lines.append(f'<li>{line.strip()[2:]}</li>')
        else:
            if in_list:
                html_lines.append('</ul>')
                in_list = False
            if line.strip() and not line.strip().startswith('<'):
                html_lines.append(f'<p>{line}</p>')
            else:
                html_lines.append(line)
    if in_list:
        html_lines.append('</ul>')
    html_content = '\n'.join(html_lines)
    
    # Tables
    html_content = re.sub(r'\|(.*?)\|', r'<td>\1</td>', html_content)
    html_content = html_content.replace('---', '<hr>')
    
    # Wrap in HTML structure
    full_html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body {{
            font-family: "PingFang SC", "Microsoft YaHei", "SimSun", Arial, sans-serif;
            line-height: 1.6;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }}
        h1 {{ color: #333; border-bottom: 2px solid #333; padding-bottom: 10px; }}
        h2 {{ color: #555; margin-top: 30px; border-bottom: 1px solid #ddd; padding-bottom: 5px; }}
        h3 {{ color: #666; margin-top: 20px; }}
        h4 {{ color: #777; }}
        table {{ border-collapse: collapse; width: 100%; margin: 20px 0; }}
        th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; vertical-align: middle; }}
        th {{ background-color: #f2f2f2; }}
        td[valign="center"] {{ vertical-align: middle; }}
        td[valign="top"] {{ vertical-align: top; }}
        td[valign="bottom"] {{ vertical-align: bottom; }}
        ul, ol {{ margin: 10px 0; padding-left: 30px; }}
        code {{ background-color: #f4f4f4; padding: 2px 4px; border-radius: 3px; }}
        hr {{ border: none; border-top: 1px solid #ddd; margin: 20px 0; }}
    </style>
</head>
<body>
{html_content}
</body>
</html>"""
    
    with open(html_file, 'w', encoding='utf-8') as f:
        f.write(full_html)
    
    print(f"成功将 {md_file} 转换为 {html_file}")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("用法: python3 md_to_html.py <input.md> <output.html>")
        sys.exit(1)
    
    md_file = sys.argv[1]
    html_file = sys.argv[2]
    
    if not os.path.exists(md_file):
        print(f"错误: 文件 {md_file} 不存在")
        sys.exit(1)
    
    markdown_to_html(md_file, html_file)

